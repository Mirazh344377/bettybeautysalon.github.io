<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 2,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 4,
  'name' => 'Interior Design',
  'slug' => 'interior-design',
  'term_group' => 0,
  'taxonomy' => 'portfolio-category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 5,
  'name' => 'Planning',
  'slug' => 'planning',
  'term_group' => 0,
  'taxonomy' => 'portfolio-category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 6,
  'name' => 'Furniture',
  'slug' => 'furniture',
  'term_group' => 0,
  'taxonomy' => 'portfolio-category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 72,
  'post_date' => '2021-02-06 03:10:57',
  'post_date_gmt' => '2021-02-06 03:10:57',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>About</h1> <p>Founded in 2000, the goal of Interior Design Co is to create a sophisticated and authentic environments.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/about-banner-hero-1160x455.jpg" width="1160" height="455" title="about-banner-hero" alt="about-banner-hero" srcset="https://themify.me/demo/themes/ultra-interior/files/2021/02/about-banner-hero-1160x455.jpg 1160w, https://themify.me/demo/themes/ultra-interior/files/2021/02/about-banner-hero-600x236.jpg 600w, https://themify.me/demo/themes/ultra-interior/files/2021/02/about-banner-hero-768x302.jpg 768w, https://themify.me/demo/themes/ultra-interior/files/2021/02/about-banner-hero.jpg 1120w" sizes="(max-width: 1160px) 100vw, 1160px" />
<p>We are a team of creative and forward-thinking individuals whose goal is to make each client\'s vision a reality. We partner and collaborate with a architects, planners, designers, landscapers, etc to ensure success in each process throughout the duration of the project.</p>
<p>It is our practice to be with our clients every step of the way - from creating the blueprints, the designing, the budget to "putting everything together". We ensure that we deliver exceptional spaces, while adhering to client\'s affordability and timeline. We ensure that our approach aligns with our client\'s objectives.</p>
<h2>Our Philosophy</h2>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/services-architecture-360x230.jpg" width="360" height="230" title="Our Mission" alt="To create a space that is a unique representation of you or your business. Our goal is to have our thoughtful interiors provoke good emotions."> <h3> Our Mission </h3> To create a space that is a unique representation of you or your business. Our goal is to have our thoughtful interiors provoke good emotions.
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/services-interior-360x230.jpg" width="360" height="230" title="Our Vision" alt="To become a single professional service for all your needs - from the planning, landscaping, architecture to interior design."> <h3> Our Vision </h3> To become a single professional service for all your needs - from the planning, landscaping, architecture to interior design.
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/services-planning-360x230.jpg" width="360" height="230" title="Our Values" alt="Our values is a reflection of our humble beginnings. Our cllents will always come first and our goal is to achieve their objectives."> <h3> Our Values </h3> Our values is a reflection of our humble beginnings. Our cllents will always come first and our goal is to achieve their objectives.
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/house-icon-90x89.png" width="90" height="89" title="house-icon" alt="house-icon">
<h3>1721</h3> <p>Home renovations</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/sold-icon-90x89.png" width="90" height="89" title="sold-icon" alt="sold-icon">
<h3>274</h3> <p>House re-modelling</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/rent-icon-90x89.png" width="90" height="89" title="rent-icon" alt="rent-icon">
<h3>840</h3> <p>Commercial rentals</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/people-icon-90x89.png" width="90" height="89" title="people-icon" alt="people-icon">
<h3>2145</h3> <p>Happy clients</p>
<h2>What Client Said</h2>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/connor-360x500.jpg" width="360" height="500" title="connor" alt="connor"> 
 Working with interior Design Co., was a dream come true. We worked closely with the whole team to plan, design and execute our hotel project. They ensured that we all work collaboratively to make our vision come true. They stayed with our project from conceptualization to completion and way beyond. Thank you to the whole team of Interior Design Co. Our hotel is currently being rated as one of the most desired place to stay for 2021. <img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/vanessa-360x500.jpg" width="360" height="500" title="vanessa" alt="vanessa"> 
 I could not stop staring at our newly renovated home! I contacted Interior Design Co. to design our dream home after so many disappointments with other companies, and I sure did not regret my decision. They were with me through the nitty-gritty side of things delivering the highest quality of work while ensuring that they adhere to the budget and the timeline. <img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/rhonda-360x500.jpg" width="360" height="500" title="rhonda" alt="rhonda"> 
 They definitely live up to their reputation as one of the best in the industry. They have worked with many of my projects and have gone above and beyond with their service and their quality of work. They always take the time to understand their client\'s vision, business objectives and market opportunities, and they combine these with their expertise in the industry and the broader market to ensure that their design is current and fresh.
<h2>Our Newsletter</h2> 
 
 <form name="tb_optin" method="post" action="https://themify.me/demo/themes/ultra-interior/wp-admin/admin-ajax.php" data-success="s2" > <input type="hidden" name="action" value="tb_optin_subscribe" /> <input type="hidden" name="tb_optin_redirect" value="" /> <input type="hidden" name="tb_optin_provider" value="mailchimp" />
 <input type="hidden" name="tb_optin_mailchimp_list" value="0f2a95e5de" /> <input type="hidden" name="tb_optin_fname" value="John" /> <input type="hidden" name="tb_optin_lname" value="Doe" /> <label> Email <input type="email" name="tb_optin_email" required="required" placeholder="Enter your email" /> </label> 
 <button> Subscribe </button> </form> <p>Success!</p><!--/themify_builder_static-->',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2021-03-27 04:06:37',
  'post_modified_gmt' => '2021-03-27 04:06:37',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?page_id=72',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"lf4k31\\",\\"cols\\":[{\\"element_id\\":\\"79zg33\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"icgc671\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>About<\\\\/h1>\\\\n<p>Founded in 2000, the goal of Interior Design Co is to create a sophisticated and authentic environments.<\\\\/p>\\"}}],\\"styling\\":{\\"background_color\\":\\"#ffffff\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"padding_top\\":\\"2\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"2\\",\\"padding_opp_top\\":\\"1\\"}},{\\"element_id\\":\\"o8et258\\",\\"cols\\":[{\\"element_id\\":\\"cnvm260\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"fi30915\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":\\"1\\",\\"width_image\\":\\"1160\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/about-banner-hero-1160x455.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\"}}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_top\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_bottom\\":false}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"hide_anchor\\":false}},{\\"element_id\\":\\"8i5v343\\",\\"cols\\":[{\\"element_id\\":\\"u19s344\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"kswe894\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>We are a team of creative and forward-thinking individuals whose goal is to make each client\\\'s vision a reality. We partner and collaborate with a architects, planners, designers, landscapers, etc to ensure success in each process throughout the duration of the project.<\\\\/p>\\",\\"margin_right_unit\\":\\"%\\",\\"margin_opp_left\\":false,\\"margin_right\\":\\"20\\",\\"margin_opp_top\\":false}}]},{\\"element_id\\":\\"mnff210\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"yn5q848\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>It is our practice to be with our clients every step of the way - from creating the blueprints, the designing, the budget to \\\\\\"putting everything together\\\\\\". We ensure that we deliver exceptional spaces, while adhering to client\\\'s affordability and timeline. We ensure that our approach aligns with our client\\\'s objectives.<\\\\/p>\\"}}]}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_top\\":\\"2\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"2\\",\\"padding_opp_top\\":\\"1\\",\\"breakpoint_tablet\\":{\\"padding_top\\":5,\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":5,\\"padding_bottom_unit\\":\\"%\\"},\\"breakpoint_tablet_landscape\\":{\\"padding_top\\":6,\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":6,\\"padding_bottom_unit\\":\\"%\\"},\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"m9eg88\\",\\"cols\\":[{\\"element_id\\":\\"3gu988\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"0nu871\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Philosophy<\\\\/h2>\\",\\"bl_m\\":\\"normal\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"40\\",\\"margin_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"25\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"},\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\"}},{\\"element_id\\":\\"5io590\\",\\"cols\\":[{\\"element_id\\":\\"mqrv90\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"h3l090\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/services-architecture-360x230.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"caption_image\\":\\"To create a space that is a unique representation of you or your business. Our goal is to have our thoughtful interiors provoke good emotions.\\",\\"title_image\\":\\"Our Mission\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_opp_top\\":false,\\"title_margin_opp_left\\":false,\\"title_margin_bottom\\":\\"20\\",\\"title_margin_opp_top\\":false,\\"title_margin_top\\":\\"20\\",\\"height_image\\":\\"230\\",\\"width_image\\":\\"360\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\"}}]},{\\"element_id\\":\\"19x091\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"455y91\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/services-interior-360x230.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"caption_image\\":\\"To become a single professional service for all your needs - from the planning, landscaping, architecture to interior design. \\",\\"title_image\\":\\"Our Vision\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_opp_top\\":false,\\"title_margin_opp_left\\":false,\\"title_margin_bottom\\":\\"20\\",\\"title_margin_opp_top\\":false,\\"title_margin_top\\":\\"20\\",\\"height_image\\":\\"230\\",\\"width_image\\":\\"360\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\"}}]},{\\"element_id\\":\\"12vx91\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"5hts92\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/services-planning-360x230.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"caption_image\\":\\"Our values is a reflection of our humble beginnings. Our cllents will always come first and our goal is to achieve their objectives.\\",\\"title_image\\":\\"Our Values\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_opp_top\\":false,\\"title_margin_opp_left\\":false,\\"title_margin_bottom\\":\\"20\\",\\"title_margin_opp_top\\":false,\\"title_margin_top\\":\\"20\\",\\"height_image\\":\\"230\\",\\"width_image\\":\\"360\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\"}}]}],\\"col_tablet_landscape\\":\\"column3-1\\",\\"col_tablet\\":\\"column3-1\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"styling\\":{\\"text_align\\":\\"center\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"2\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"6\\"}},{\\"element_id\\":\\"fb0m488\\",\\"cols\\":[{\\"element_id\\":\\"iccb489\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"iv01161\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"89\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"90\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/house-icon-90x89.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"nry8109\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>1721<\\\\/h3>\\\\n<p>Home renovations<\\\\/p>\\",\\"font_color_type\\":\\"font_color_solid\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_bottom\\":\\"0\\",\\"font_weight_h3\\":\\"bold\\",\\"line_height_h3_unit\\":\\"px\\",\\"line_height_h3\\":\\"-3\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"60\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}]},{\\"element_id\\":\\"ou9c845\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"0j9m847\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"89\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"90\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/sold-icon-90x89.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"i6ku848\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>274<\\\\/h3>\\\\n<p>House re-modelling<\\\\/p>\\",\\"font_color_type\\":\\"font_color_solid\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_bottom\\":\\"0\\",\\"font_weight_h3\\":\\"bold\\",\\"line_height_h3_unit\\":\\"px\\",\\"line_height_h3\\":\\"-3\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"60\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}]},{\\"element_id\\":\\"owsj740\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"vb40741\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"89\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"90\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/rent-icon-90x89.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"a4j0741\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>840<\\\\/h3>\\\\n<p>Commercial rentals<\\\\/p>\\",\\"font_color_type\\":\\"font_color_solid\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_bottom\\":\\"0\\",\\"font_weight_h3\\":\\"bold\\",\\"line_height_h3_unit\\":\\"px\\",\\"line_height_h3\\":\\"-3\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"60\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}]},{\\"element_id\\":\\"50w7669\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"mp13670\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"89\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"90\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/people-icon-90x89.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"cl1k670\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>2145<\\\\/h3>\\\\n<p>Happy clients<\\\\/p>\\",\\"font_color_type\\":\\"font_color_solid\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_bottom\\":\\"0\\",\\"font_weight_h3\\":\\"bold\\",\\"line_height_h3_unit\\":\\"px\\",\\"line_height_h3\\":\\"-3\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"60\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}]}],\\"col_tablet\\":\\"column4-1\\",\\"styling\\":{\\"padding_top\\":6,\\"hide_anchor\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":6,\\"padding_opp_top\\":\\"1\\",\\"cover_color\\":\\"#000000_0.65\\",\\"cover_color-type\\":\\"color\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/banner-interior-stats.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"font_color\\":\\"#ffffff\\",\\"text_align\\":\\"center\\"}},{\\"element_id\\":\\"vi8x732\\",\\"cols\\":[{\\"element_id\\":\\"w3to733\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"zsc189\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>What Client Said<\\\\/h2>\\",\\"bl_m\\":\\"normal\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"40\\",\\"margin_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"25\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"3\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"3\\",\\"breakpoint_mobile\\":{\\"padding_top\\":\\"8\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"4\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false},\\"breakpoint_tablet\\":{\\"padding_top\\":\\"8\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false},\\"breakpoint_tablet_landscape\\":{\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"3\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}}},{\\"element_id\\":\\"8tre540\\",\\"cols\\":[{\\"element_id\\":\\"3e2l541\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"slider\\",\\"element_id\\":\\"pnx5821\\",\\"mod_settings\\":{\\"posts_per_page_slider\\":\\"4\\",\\"display_slider\\":\\"none\\",\\"img_w_slider\\":\\"360\\",\\"img_h_slider\\":\\"500\\",\\"horizontal\\":\\"no\\",\\"visible_opt_slider\\":\\"1\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"play_pause_control\\":\\"no\\",\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"no\\",\\"wrap_slider\\":\\"yes\\",\\"auto_scroll_opt_slider\\":\\"off\\",\\"post_type\\":\\"post\\",\\"hide_post_date\\":\\"yes\\",\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":\\"vertical\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"0\\",\\"tab_visible_opt_slider\\":\\"0\\",\\"effect_slider\\":\\"scroll\\",\\"img_fullwidth_slider\\":false,\\"layout_slider\\":\\"slider-agency\\",\\"img_content_slider\\":[{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/connor.jpg\\",\\"img_caption_slider\\":\\"Working with interior Design Co., was a dream come true. We worked closely with the whole team to plan, design and execute our hotel project. They ensured that we all work collaboratively to make our vision come true. They stayed with our project from conceptualization to completion and way beyond. Thank you to the whole team of Interior Design Co. Our hotel is currently being rated as one of the most desired place to stay for 2021.\\"},{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/vanessa.jpg\\",\\"img_caption_slider\\":\\"I could not stop staring at our newly renovated home! I contacted Interior Design Co. to design our dream home after so many disappointments with other companies, and I sure did not regret my decision. They were with me through the nitty-gritty side of things delivering the highest quality of work while ensuring that they adhere to the budget and the timeline.\\"},{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/rhonda.jpg\\",\\"img_caption_slider\\":\\"They definitely live up to their reputation as one of the best in the industry. They have worked with many of my projects and have gone above and beyond with their service and their quality of work. They always take the time to understand their client\\\'s vision, business objectives and market opportunities, and they combine these with their expertise in the industry and the broader market to ensure that their design is current and fresh. \\"}],\\"open_link_new_tab_slider\\":\\"no\\",\\"unlink_feat_img_slider\\":\\"no\\",\\"hide_feat_img_slider\\":\\"no\\",\\"unlink_post_title_slider\\":\\"no\\",\\"hide_post_title_slider\\":\\"no\\",\\"orderby_slider\\":\\"date\\",\\"order_slider\\":\\"desc\\",\\"blog_category_slider\\":\\"0|single\\",\\"taxonomy\\":\\"category\\",\\"layout_display_slider\\":\\"image\\",\\"portfolio_category_slider\\":\\"0|single\\"}}]}]},{\\"element_id\\":\\"c7zl503\\",\\"cols\\":[{\\"element_id\\":\\"r93y503\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"layout-part\\",\\"element_id\\":\\"lsaq802\\",\\"mod_settings\\":{\\"selected_layout_part\\":\\"newsletter\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"padding_top\\":\\"4\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_opp_bottom\\":false}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 114,
  'post_date' => '2021-02-06 13:32:42',
  'post_date_gmt' => '2021-02-06 13:32:42',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Contact</h1> <p>Are you ready to partner with us? Send us an email or call us to talk about your upcoming project.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/contact-us-banner-1160x455.jpg" width="1160" height="455" title="contact-us-banner" alt="contact-us-banner" srcset="https://themify.me/demo/themes/ultra-interior/files/2021/02/contact-us-banner-1160x455.jpg 1160w, https://themify.me/demo/themes/ultra-interior/files/2021/02/contact-us-banner-600x236.jpg 600w, https://themify.me/demo/themes/ultra-interior/files/2021/02/contact-us-banner-768x302.jpg 768w, https://themify.me/demo/themes/ultra-interior/files/2021/02/contact-us-banner.jpg 1120w" sizes="(max-width: 1160px) 100vw, 1160px" />
<em><svg aria-hidden="true"><use href="#tf-ti-mobile"></use></svg></em>
<h3>Call Us</h3> <p>+1 0123-1230</p>
<em><svg aria-hidden="true"><use href="#tf-ti-location-pin"></use></svg></em>
<h3>Address</h3> <p>13897 New England,  Sydney</p>
<em><svg aria-hidden="true"><use href="#tf-ti-email"></use></svg></em>
<h3>Have any questions?</h3> <p>support@ultra-interior.com</p>
<h2>Career Opportunities</h2> <p>Here at Interior Design Co., we always welcome creative and forward-thinking design professionals. Please feel free to send us a message or forward your resume to careers@ultra-interior.com</p>
<form action="https://themify.me/demo/themes/ultra-interior/wp-admin/admin-ajax.php" class="builder-contact" id="tb_qbje890-form" method="post" data-post-id="0" data-element-id="qbje890" data-orig-id="" > <label for="tb_qbje890-contact-name">Name *</label> <input type="text" name="contact-name" placeholder="" id="tb_qbje890-contact-name" value="" required> <label for="tb_qbje890-contact-email">Email *</label> <input type="text" name="contact-email" placeholder="" id="tb_qbje890-contact-email" value="" required> <label for="tb_qbje890-contact-subject">Subject *</label> <input type="text" name="contact-subject" placeholder="" id="tb_qbje890-contact-subject" value="" required> <label for="tb_qbje890-contact-message">Message *</label> <textarea name="contact-message" placeholder="" id="tb_qbje890-contact-message" required></textarea> <button type="submit">Send</button> </form><!--/themify_builder_static-->',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2022-01-07 10:53:54',
  'post_modified_gmt' => '2022-01-07 10:53:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?page_id=114',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"80x4806\\",\\"cols\\":[{\\"element_id\\":\\"mry7807\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"bblf807\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Contact<\\\\/h1>\\\\n<p>Are you ready to partner with us? Send us an email or call us to talk about your upcoming project.<\\\\/p>\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-type\\":\\"image\\"}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"padding_top\\":\\"2\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"2\\",\\"padding_opp_top\\":\\"1\\"}},{\\"element_id\\":\\"d5nn798\\",\\"cols\\":[{\\"element_id\\":\\"s42r799\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"gqdb424\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":\\"1\\",\\"width_image\\":\\"1160\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/contact-us-banner-1160x455.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}}}}],\\"styling\\":{\\"padding_opp_top\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"gutter\\":\\"gutter-none\\"},{\\"element_id\\":\\"1mt8399\\",\\"cols\\":[{\\"element_id\\":\\"45jh400\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"j9uz401\\",\\"cols\\":[{\\"element_id\\":\\"jnu9402\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"ew01440\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-mobile\\",\\"icon_color_bg\\":\\"black\\",\\"hide_label\\":false,\\"link_options\\":\\"regular\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"squared\\",\\"icon_size\\":\\"normal\\",\\"font_color_icon\\":\\"#c5a47e\\",\\"background_color_icon\\":\\"#000000\\",\\"custom_parallax_scroll_zindex\\":\\"3\\",\\"margin_left\\":\\"25\\",\\"margin_bottom\\":\\"-25\\",\\"f_s_i\\":\\"35\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"59pr978\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Call Us<\\\\/h3>\\\\n<p>+1 0123-1230<\\\\/p>\\",\\"custom_parallax_scroll_zindex\\":\\"1\\",\\"b_sh_color\\":\\"#ebebeb\\",\\"b_sh_spread\\":\\"5\\",\\"b_sh_blur\\":\\"10\\",\\"b_sh_vOffset\\":\\"1\\",\\"b_sh_hOffset\\":\\"1\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"15\\",\\"padding_right\\":\\"10\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"15\\"}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"9sm3561\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"ci01909\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-location-pin\\",\\"icon_color_bg\\":\\"black\\",\\"hide_label\\":false,\\"link_options\\":\\"regular\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"squared\\",\\"icon_size\\":\\"normal\\",\\"font_color_icon\\":\\"#c5a47e\\",\\"background_color_icon\\":\\"#000000\\",\\"custom_parallax_scroll_zindex\\":\\"3\\",\\"margin_left\\":\\"25\\",\\"margin_bottom\\":\\"-25\\",\\"f_s_i\\":\\"35\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"1v3c563\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Address<\\\\/h3>\\\\n<p>13897 New England,  Sydney<\\\\/p>\\",\\"custom_parallax_scroll_zindex\\":\\"1\\",\\"b_sh_color\\":\\"#ebebeb\\",\\"b_sh_spread\\":\\"5\\",\\"b_sh_blur\\":\\"10\\",\\"b_sh_vOffset\\":\\"1\\",\\"b_sh_hOffset\\":\\"1\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"15\\",\\"padding_right\\":\\"10\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"15\\"}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"hjdx538\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"fjht795\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-email\\",\\"icon_color_bg\\":\\"black\\",\\"hide_label\\":false,\\"link_options\\":\\"regular\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"squared\\",\\"icon_size\\":\\"normal\\",\\"font_color_icon\\":\\"#c5a47e\\",\\"background_color_icon\\":\\"#000000\\",\\"custom_parallax_scroll_zindex\\":\\"3\\",\\"margin_left\\":\\"25\\",\\"margin_bottom\\":\\"-25\\",\\"f_s_i\\":\\"35\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"5pa5539\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Have any questions?<\\\\/h3>\\\\n<p>support@ultra-interior.com<\\\\/p>\\",\\"custom_parallax_scroll_zindex\\":\\"1\\",\\"b_sh_color\\":\\"#ebebeb\\",\\"b_sh_spread\\":\\"5\\",\\"b_sh_blur\\":\\"10\\",\\"b_sh_vOffset\\":\\"1\\",\\"b_sh_hOffset\\":\\"1\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"15\\",\\"padding_right\\":\\"10\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"15\\"}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"styling\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}]}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":8,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\"}},{\\"element_id\\":\\"6cpl33\\",\\"cols\\":[{\\"element_id\\":\\"e7i534\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"6xo4853\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Career Opportunities<\\\\/h2>\\\\n<p>Here at Interior Design Co., we always welcome creative and forward-thinking design professionals. Please feel free to send us a message or forward your resume to careers@ultra-interior.com<\\\\/p>\\",\\"bl_m\\":\\"normal\\",\\"margin_bottom\\":\\"50\\",\\"font_color_type\\":\\"font_color_solid\\",\\"text_align\\":\\"center\\",\\"breakpoint_mobile\\":{\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"},\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-type\\":\\"image\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":\\"1\\"}},{\\"element_id\\":\\"n1o0994\\",\\"cols\\":[{\\"element_id\\":\\"llv2995\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"qbje890\\",\\"mod_settings\\":{\\"field_name_label\\":\\"Name\\",\\"field_email_label\\":\\"Email\\",\\"field_subject_label\\":\\"Subject\\",\\"field_message_label\\":\\"Message\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_sendcopy_subject\\":\\"COPY:\\",\\"field_send_label\\":\\"Send\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"field_name_require\\":\\"yes\\",\\"field_email_require\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_email_active\\":\\"yes\\",\\"field_subject_active\\":\\"yes\\",\\"field_subject_require\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_extra\\":\\"{ \\\\\\"fields\\\\\\": [] }\\",\\"field_order\\":\\"{}\\",\\"field_optin_label\\":\\"Subscribe to my newsletter.\\",\\"field_optin_active\\":false,\\"mailchimp_list\\":\\"0f2a95e5de\\",\\"provider\\":\\"mailchimp\\",\\"field_sendcopy_active\\":false,\\"field_captcha_active\\":false,\\"include_name_mail\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"user_role\\":\\"admin\\",\\"send_to_admins\\":false,\\"layout_contact\\":\\"style1\\"}}],\\"styling\\":{\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_right\\":\\"5\\",\\"padding_left\\":\\"5\\"}},{\\"element_id\\":\\"ho7w996\\",\\"grid_class\\":\\"col2-1\\",\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/map-contact.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"gutter\\":\\"gutter-none\\"}]}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 6,
  'post_date' => '2021-02-05 03:37:37',
  'post_date_gmt' => '2021-02-05 03:37:37',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Interior Design Co.</h1> <p>Learn why our company is rated the Top Interior Designer in Canada and why industry leaders choose us for all their interior needs!</p>
<a href="https://themify.me/" > View our work <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/interior-gery-living-room-629x367.jpg" width="629" height="367" title="interior-gery-living-room" alt="interior-gery-living-room" srcset="https://themify.me/demo/themes/ultra-interior/files/2021/02/interior-gery-living-room.jpg 629w, https://themify.me/demo/themes/ultra-interior/files/2021/02/interior-gery-living-room-600x350.jpg 600w" sizes="(max-width: 629px) 100vw, 629px" />
<h2>Putting your interior needs first</h2> <p>Working very closely with our clients to ensure that we design and create an inspiring, joyful and comfortable space. Our goal is to make sure that every design is a reflection of you and your unique personality. Your needs will always come first so we can make your vision into reality.</p>
<a href="https://themify.me/" > Learn more <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> </a>
<h2>Services</h2>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/services-architecture-360x230.jpg" width="360" height="230" title="Architecture" alt="Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they."> <h3> Architecture </h3> Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they.
<a href="https://themify.me/"> <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> Learn more </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/services-interior-360x230.jpg" width="360" height="230" title="Interiors" alt="Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they."> <h3> Interiors </h3> Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they.
<a href="https://themify.me/"> <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> Learn more </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/services-planning-360x230.jpg" width="360" height="230" title="Planning" alt="Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they."> <h3> Planning </h3> Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they.
<a href="https://themify.me/"> <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> Learn more </a>
<h2>Our Story</h2> <p>What started as a passion project, curating design spaces for a small group of clients, we have slowly made our mark on the city of Toronto. It is always our passion to pursue fresh and modern inspiration for all our designs. We create them in a collaborative environment, with our clients and our team of designers and architects. Our focus is not only on delivering compelling designs but also in using the highest quality of materials available.</p>
<a href="https://themify.me/" > Learn more <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> </a>
<a href="https://www.youtube.com/watch?v=pLTAc2HyXCM&#038;ab_channel=TheLocalProject" data-zoom-config="800px|550px" > <svg aria-label="Open" role="img"><use href="#tf-ti-search"></use></svg> <img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/interior-concept-video-571x593.jpg" width="571" height="593" title="interior-concept-video" alt="interior-concept-video"> </a>
<h2>Concept &amp; Details</h2> <p>Our team put in hours of market research when creating each design. We pride ourselves in our outstanding services by exquisitely moving through each stages of design, carefully planning and finding the most elegant and budget-friendly solutions for our clients. We keep all our designs current with a timeless feel, all the while ensuring that we achieve and align with our client\'s vision and their objectives.</p>
<a href="https://themify.me/" > Learn more <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/pricing-architecture-131x102.png" width="131" height="102" title="Architecture" alt="Architecture"> <h3> Architecture </h3>
<h3>$150</h3> <p>For an hourly fee, we start the design stage by partnering with architects and developers to draw out your project plan.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/pricing-interior-131x102.png" width="131" height="102" title="Interiors" alt="Interiors"> <h3> Interiors </h3>
<h3>$130</h3> <p>Our team of designers will work with you to curate the most unique and beautiful pieces in creating your perfect space.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/pricing-planing-131x102.png" width="131" height="102" title="Planning" alt="Planning"> <h3> Planning </h3>
<h3>$1250</h3> <p>Our planning process is very extensive. This final stage of design finds you the most efficient and elegant solution.</p>
<h2>Our Newsletter</h2> 
 
 <form name="tb_optin" method="post" action="https://themify.me/demo/themes/ultra-interior/wp-admin/admin-ajax.php" data-success="s2" > <input type="hidden" name="action" value="tb_optin_subscribe" /> <input type="hidden" name="tb_optin_redirect" value="" /> <input type="hidden" name="tb_optin_provider" value="mailchimp" />
 <input type="hidden" name="tb_optin_mailchimp_list" value="0f2a95e5de" /> <input type="hidden" name="tb_optin_fname" value="John" /> <input type="hidden" name="tb_optin_lname" value="Doe" /> <label> Email <input type="email" name="tb_optin_email" required="required" placeholder="Enter your email" /> </label> 
 <button> Subscribe </button> </form> <p>Success!</p><!--/themify_builder_static-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2021-03-27 04:05:45',
  'post_modified_gmt' => '2021-03-27 04:05:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?page_id=6',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    'header_wrap' => 'transparent',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"4bxb997\\",\\"cols\\":[{\\"element_id\\":\\"wkk9999\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"u23n964\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Interior Design Co.<\\\\/h1>\\\\n<p>Learn why our company is rated the Top Interior Designer in Canada and why industry leaders choose us for all their interior needs!<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"k5uv476\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View our work\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_alignment\\":\\"right\\",\\"button_color_bg\\":\\"tb_default_color\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_transform\\":\\"uppercase\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"link_color\\":\\"#000000\\",\\"b_p\\":\\"50,50\\",\\"b_r\\":\\"repeat\\",\\"button_background_color\\":\\"#ffffff\\",\\"b_i-circle-radial\\":false,\\"b_i-gradient-angle\\":\\"180\\",\\"b_i-gradient-type\\":\\"linear\\",\\"b_i-type\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\"}}]},{\\"element_id\\":\\"dw7g941\\",\\"grid_class\\":\\"col3-1\\"}],\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/banner-hero-homepage.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_top\\":\\"184\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"335\\",\\"padding_opp_top\\":false,\\"font_color\\":\\"#ffffff\\",\\"zi\\":\\"1\\",\\"breakpoint_mobile\\":{\\"padding_top\\":108,\\"padding_top_unit\\":\\"px\\",\\"padding_bottom\\":163,\\"padding_bottom_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"padding_top\\":\\"108\\",\\"padding_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_bottom\\":\\"219\\",\\"padding_opp_bottom\\":false},\\"breakpoint_tablet_landscape\\":{\\"padding_top\\":147,\\"padding_top_unit\\":\\"px\\",\\"padding_bottom\\":200,\\"padding_bottom_unit\\":\\"px\\"}}},{\\"element_id\\":\\"kdd068\\",\\"cols\\":[{\\"element_id\\":\\"8hk269\\",\\"grid_class\\":\\"col4-1\\",\\"grid_width\\":12.53999999999999914734871708787977695465087890625},{\\"element_id\\":\\"yx9m943\\",\\"grid_class\\":\\"col4-3\\",\\"modules\\":[{\\"element_id\\":\\"3mut511\\",\\"cols\\":[{\\"element_id\\":\\"qosw513\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"fchj422\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"367\\",\\"auto_fullwidth\\":\\"1\\",\\"width_image\\":\\"629\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/interior-gery-living-room.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"-10\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"-10\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"-10\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}}}],\\"grid_width\\":46.63000000000000255795384873636066913604736328125},{\\"element_id\\":\\"pcwb514\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"85vp255\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Putting your interior needs first<\\\\/h2>\\\\n<p>Working very closely with our clients to ensure that we design and create an inspiring, joyful and comfortable space. Our goal is to make sure that every design is a reflection of you and your unique personality. Your needs will always come first so we can make your vision into reality.<\\\\/p>\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"h1_margin_bottom_unit\\":\\"px\\",\\"h1_margin_top_unit\\":\\"px\\",\\"t_shh1_blur_unit\\":\\"px\\",\\"t_shh1_vShadow_unit\\":\\"px\\",\\"t_shh1_hShadow_unit\\":\\"px\\",\\"letter_spacing_h1_unit\\":\\"px\\",\\"line_height_h1_unit\\":\\"px\\",\\"font_size_h1_unit\\":\\"px\\",\\"font_gradient_color_h1-circle-radial\\":false,\\"font_gradient_color_h1-gradient-angle\\":\\"180\\",\\"font_gradient_color_h1-gradient-type\\":\\"linear\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\"},\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"isgt944\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Learn more\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_alignment\\":\\"right\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_transform\\":\\"uppercase\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}],\\"grid_width\\":53.36999999999999744204615126363933086395263671875,\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_right\\":\\"60\\",\\"padding_opp_top\\":false,\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet\\":\\"column-full\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"2\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"7\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"grid_width\\":84.2600000000000051159076974727213382720947265625,\\"styling\\":{\\"background_color\\":\\"#ffffff\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"padding_top\\":\\"0\\",\\"hide_anchor\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"8\\",\\"padding_opp_top\\":false,\\"zi\\":\\"3\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":\\"-10\\"}},{\\"element_id\\":\\"g830119\\",\\"cols\\":[{\\"element_id\\":\\"x3o8120\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"gjpj576\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Services<\\\\/h2>\\",\\"bl_m\\":\\"normal\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"40\\",\\"margin_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"25\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}}},{\\"element_id\\":\\"fu2r183\\",\\"cols\\":[{\\"element_id\\":\\"eh5m184\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"nhu7359\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/services-architecture-360x230.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"caption_image\\":\\"Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they.\\",\\"title_image\\":\\"Architecture\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_opp_top\\":false,\\"title_margin_opp_left\\":false,\\"title_margin_bottom\\":\\"20\\",\\"title_margin_opp_top\\":false,\\"title_margin_top\\":\\"20\\",\\"height_image\\":\\"230\\",\\"width_image\\":\\"360\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"6x1i735\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Learn more\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}]},{\\"element_id\\":\\"6f11524\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"g60h526\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/services-interior-360x230.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"caption_image\\":\\"Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they.\\",\\"title_image\\":\\"Interiors\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_opp_top\\":false,\\"title_margin_opp_left\\":false,\\"title_margin_bottom\\":\\"20\\",\\"title_margin_opp_top\\":false,\\"title_margin_top\\":\\"20\\",\\"height_image\\":\\"230\\",\\"width_image\\":\\"360\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"5exl342\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Learn more\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}],\\"styling\\":{\\"text_align\\":\\"center\\"}},{\\"element_id\\":\\"pohc217\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3a88217\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/services-planning-360x230.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"caption_image\\":\\"Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they.\\",\\"title_image\\":\\"Planning\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_opp_top\\":false,\\"title_margin_opp_left\\":false,\\"title_margin_bottom\\":\\"20\\",\\"title_margin_opp_top\\":false,\\"title_margin_top\\":\\"20\\",\\"height_image\\":\\"230\\",\\"width_image\\":\\"360\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"sdvf526\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Learn more\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}]}],\\"col_tablet_landscape\\":\\"column3-1\\",\\"col_tablet\\":\\"column3-1\\",\\"styling\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_top\\":\\"30\\",\\"background_color\\":\\"#f9f9f9\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}]}],\\"styling\\":{\\"text_align\\":\\"center\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"8\\",\\"padding_opp_top\\":false,\\"padding_opp_bottom\\":false,\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"lzn8546\\",\\"cols\\":[{\\"element_id\\":\\"wfbv548\\",\\"grid_class\\":\\"col-full\\"}],\\"styling\\":{\\"padding_top\\":14,\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":14,\\"padding_opp_top\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/banner-our-story.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"zi\\":\\"1\\"}},{\\"element_id\\":\\"zqr7313\\",\\"cols\\":[{\\"element_id\\":\\"977m315\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"v0dh442\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Story<\\\\/h2>\\\\n<p>What started as a passion project, curating design spaces for a small group of clients, we have slowly made our mark on the city of Toronto. It is always our passion to pursue fresh and modern inspiration for all our designs. We create them in a collaborative environment, with our clients and our team of designers and architects. Our focus is not only on delivering compelling designs but also in using the highest quality of materials available.<\\\\/p>\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"l95y100\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Learn more\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_alignment\\":\\"right\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_transform\\":\\"uppercase\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}],\\"styling\\":{\\"background_color\\":\\"#ffffff\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"5\\",\\"padding_left\\":\\"5\\",\\"padding_bottom\\":\\"5\\",\\"padding_right\\":\\"5\\"}}],\\"styling\\":{\\"zi\\":\\"3\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":-11}},{\\"element_id\\":\\"erl6747\\",\\"cols\\":[{\\"element_id\\":\\"929s749\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3kp2597\\",\\"mod_settings\\":{\\"image_zoom_icon\\":\\"zoom\\",\\"param_image\\":\\"lightbox\\",\\"height_image\\":\\"593\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"571\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/interior-concept-video-571x593.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_height\\":\\"550\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_width\\":\\"800\\",\\"link_image\\":\\"https:\\\\/\\\\/www.youtube.com\\\\/watch?v=pLTAc2HyXCM&ab_channel=TheLocalProject\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}}}],\\"styling\\":{\\"text_align\\":\\"right\\"}},{\\"element_id\\":\\"jtp4247\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"3kuy928\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Concept &amp; Details<\\\\/h2>\\\\n<p>Our team put in hours of market research when creating each design. We pride ourselves in our outstanding services by exquisitely moving through each stages of design, carefully planning and finding the most elegant and budget-friendly solutions for our clients. We keep all our designs current with a timeless feel, all the while ensuring that we achieve and align with our client\\\'s vision and their objectives.<\\\\/p>\\",\\"breakpoint_mobile\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"},\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"kslk941\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Learn more\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_alignment\\":\\"right\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_transform\\":\\"uppercase\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column-full\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"margin-top\\":27}},{\\"element_id\\":\\"uivo681\\",\\"cols\\":[{\\"element_id\\":\\"gqfa683\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"kazg257\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/pricing-architecture.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"title_image\\":\\"Architecture\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_opp_bottom\\":false,\\"height_image\\":\\"102\\",\\"width_image\\":\\"131\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"rehf61\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>$150<\\\\/h3>\\\\n<p>For an hourly fee, we start the design stage by partnering with architects and developers to draw out your project plan.<\\\\/p>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"50\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}],\\"styling\\":{\\"cover_color_hover\\":\\"#000000\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color\\":\\"#f9f9f9\\",\\"cover_color-type\\":\\"color\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"3\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"3\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_right\\":\\"5\\",\\"text_align\\":\\"center\\",\\"f_c_h\\":\\"#ffffff\\",\\"margin-top_opp_top\\":false}},{\\"element_id\\":\\"xyff221\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"bpg8222\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/pricing-interior.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"title_image\\":\\"Interiors\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_opp_bottom\\":false,\\"height_image\\":\\"102\\",\\"width_image\\":\\"131\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"a4u2725\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>$130<\\\\/h3>\\\\n<p>Our team of designers will work with you to curate the most unique and beautiful pieces in creating your perfect space.<\\\\/p>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"50\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}],\\"styling\\":{\\"cover_color_hover\\":\\"#000000\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color\\":\\"#f9f9f9\\",\\"cover_color-type\\":\\"color\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"3\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"3\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_right\\":\\"5\\",\\"text_align\\":\\"center\\",\\"f_c_h\\":\\"#ffffff\\"}},{\\"element_id\\":\\"6p36917\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"9lm9917\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/pricing-planing.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"title_image\\":\\"Planning\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_opp_bottom\\":false,\\"height_image\\":\\"102\\",\\"width_image\\":\\"131\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"fd6k404\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>$1250<\\\\/h3>\\\\n<p>Our planning process is very extensive. This final stage of design finds you the most efficient and elegant solution.<\\\\/p>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"50\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}],\\"styling\\":{\\"cover_color_hover\\":\\"#000000\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color\\":\\"#f9f9f9\\",\\"cover_color-type\\":\\"color\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"3\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"3\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_right\\":\\"5\\",\\"text_align\\":\\"center\\",\\"f_c_h\\":\\"#ffffff\\"}}],\\"col_tablet_landscape\\":\\"column3-1\\",\\"styling\\":{\\"padding_top\\":\\"8\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"4\\",\\"padding_opp_top\\":false}},{\\"element_id\\":\\"brch820\\",\\"cols\\":[{\\"element_id\\":\\"u3jz821\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"layout-part\\",\\"element_id\\":\\"zt5t97\\",\\"mod_settings\\":{\\"selected_layout_part\\":\\"newsletter\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"padding_top\\":\\"4\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 171,
  'post_date' => '2021-02-10 07:27:05',
  'post_date_gmt' => '2021-02-10 07:27:05',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Our Team</h1> <p>We are a team of planners, creatives and forward-thinking individuals.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/living-room-design-1160x497.jpg" width="1160" height="497" title="living-room-design" alt="living-room-design" srcset="https://themify.me/demo/themes/ultra-interior/files/2021/02/living-room-design-1160x497.jpg 1160w, https://themify.me/demo/themes/ultra-interior/files/2021/02/living-room-design-600x257.jpg 600w, https://themify.me/demo/themes/ultra-interior/files/2021/02/living-room-design-768x329.jpg 768w, https://themify.me/demo/themes/ultra-interior/files/2021/02/living-room-design.jpg 1400w" sizes="(max-width: 1160px) 100vw, 1160px" />
<p>Meet the faces of Interior Design Co., whose work ethic, and commitment to our clients is what make us one of the best in the industry. We set out to create environments and spaces that fill a purpose and deliver exceptional design, with curated pieces to target specific tastes and objectives.</p>
<h3>Managements</h3>

<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/john-375x500.jpg" width="375" height="500" title="John Rutherford" alt="Director"> <h3> John Rutherford </h3> Director
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/juergen-375x500.jpg" width="375" height="500" title="Richard Duncan" alt="Director"> <h3> Richard Duncan </h3> Director
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/vanessa-375x500.jpg" width="375" height="500" title="Vanessa Thomson" alt="Director"> <h3> Vanessa Thomson </h3> Director

<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/lucas-375x500.jpg" width="375" height="500" title="Lucas Underwood" alt="Manager"> <h3> Lucas Underwood </h3> Manager
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/connor-375x500.jpg" width="375" height="500" title="Connor Hodges" alt="Manager"> <h3> Connor Hodges </h3> Manager
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/kyla-lee-375x500.jpg" width="375" height="500" title="Kyla Lee" alt="Manager"> <h3> Kyla Lee </h3> Manager
<h3>Project Managers</h3>


<h3>Designers</h3>

<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/Emily-375x500.jpg" width="375" height="500" title="Emily Cornish" alt="Designer"> <h3> Emily Cornish </h3> Designer
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/kevin-375x500.jpg" width="375" height="500" title="Kevin MacDonald" alt="Designer"> <h3> Kevin MacDonald </h3> Designer
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/rebbeca-liu-375x500.jpg" width="375" height="500" title="John Rutherford" alt="Designer"> <h3> John Rutherford </h3> Designer

<h2>Our Newsletter</h2> 
 
 <form name="tb_optin" method="post" action="https://themify.me/demo/themes/ultra-interior/wp-admin/admin-ajax.php" data-success="s2" > <input type="hidden" name="action" value="tb_optin_subscribe" /> <input type="hidden" name="tb_optin_redirect" value="" /> <input type="hidden" name="tb_optin_provider" value="mailchimp" />
 <input type="hidden" name="tb_optin_mailchimp_list" value="0f2a95e5de" /> <input type="hidden" name="tb_optin_fname" value="John" /> <input type="hidden" name="tb_optin_lname" value="Doe" /> <label> Email <input type="email" name="tb_optin_email" required="required" placeholder="Enter your email" /> </label> 
 <button> Subscribe </button> </form> <p>Success!</p><!--/themify_builder_static-->',
  'post_title' => 'Our Team',
  'post_excerpt' => '',
  'post_name' => 'our-team',
  'post_modified' => '2021-03-27 04:08:42',
  'post_modified_gmt' => '2021-03-27 04:08:42',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?page_id=171',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"ocrc682\\",\\"cols\\":[{\\"element_id\\":\\"xu2x684\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"pb2d684\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Our Team<\\\\/h1>\\\\n<p>We are a team of planners, creatives and forward-thinking individuals.<\\\\/p>\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\"}}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"padding_top\\":\\"2\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"2\\",\\"padding_opp_top\\":\\"1\\",\\"breakpoint_mobile\\":{\\"padding_top\\":6,\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":6,\\"padding_bottom_unit\\":\\"%\\"},\\"breakpoint_tablet\\":{\\"padding_top\\":6,\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":6,\\"padding_bottom_unit\\":\\"%\\"}}},{\\"element_id\\":\\"u04550\\",\\"cols\\":[{\\"element_id\\":\\"s1zd50\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"vixe51\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/living-room-design-1160x497.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_speed\\":\\"1\\",\\"v_dir\\":\\"up\\"}}},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"width_image\\":\\"1160\\"}}]}],\\"styling\\":{\\"hide_anchor\\":false}},{\\"element_id\\":\\"39nb710\\",\\"cols\\":[{\\"element_id\\":\\"8yer711\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"wz4u644\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Meet the faces of Interior Design Co., whose work ethic, and commitment to our clients is what make us one of the best in the industry. We set out to create environments and spaces that fill a purpose and deliver exceptional design, with curated pieces to target specific tastes and objectives.<\\\\/p>\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\"}}]}],\\"styling\\":{\\"padding_top\\":\\"2\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"2\\",\\"padding_opp_top\\":\\"1\\",\\"breakpoint_tablet\\":{\\"padding_top\\":5,\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":5,\\"padding_bottom_unit\\":\\"%\\"}}},{\\"element_id\\":\\"3wtt487\\",\\"cols\\":[{\\"element_id\\":\\"nw2t488\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ypjb489\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Managements<\\\\/h3>\\",\\"text_align\\":\\"right\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_align\\":\\"center\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}},{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"cn4n489\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"4\\",\\"color_divider\\":\\"#c5a47e\\",\\"divider_width\\":\\"150\\",\\"divider_type\\":\\"fullwidth\\",\\"bottom_margin_divider\\":\\"20\\",\\"style_divider\\":\\"solid\\"}}]},{\\"element_id\\":\\"bhjo489\\",\\"grid_class\\":\\"col4-3\\",\\"modules\\":[{\\"element_id\\":\\"pdai489\\",\\"cols\\":[{\\"element_id\\":\\"f3dt490\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"l8a9490\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"John Rutherford\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/john-375x500.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-card-layout\\",\\"width_image\\":\\"375\\",\\"caption_image\\":\\"Director\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"font_color_caption\\":\\"#000000\\",\\"c_b_c\\":\\"#ffffff\\",\\"font_color_title\\":\\"#000000\\",\\"c_sh_h_inset\\":false,\\"c_sh_h_color\\":\\"#000000_0.09\\",\\"c_sh_h_spread_unit\\":\\"px\\",\\"c_sh_h_spread\\":\\"5\\",\\"c_sh_h_blur_unit\\":\\"px\\",\\"c_sh_h_blur\\":\\"15\\",\\"c_sh_h_vOffset_unit\\":\\"px\\",\\"c_sh_h_vOffset\\":\\"5\\",\\"c_sh_h_hOffset_unit\\":\\"px\\",\\"c_sh_h_hOffset\\":\\"5\\",\\"c_sh_inset\\":false,\\"c_p_opp_left\\":false,\\"c_p_bottom\\":\\"20\\",\\"c_p_opp_top\\":\\"1\\",\\"c_p_top\\":\\"20\\",\\"font_size_title_unit\\":\\"px\\",\\"font_size_title\\":\\"22\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}]},{\\"element_id\\":\\"9si9490\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"8l5k700\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Richard\\\\tDuncan\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/juergen-375x500.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-card-layout\\",\\"width_image\\":\\"375\\",\\"caption_image\\":\\"Director\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"font_color_caption\\":\\"#000000\\",\\"c_b_c\\":\\"#ffffff\\",\\"font_color_title\\":\\"#000000\\",\\"c_sh_h_inset\\":false,\\"c_sh_h_color\\":\\"#000000_0.09\\",\\"c_sh_h_spread_unit\\":\\"px\\",\\"c_sh_h_spread\\":\\"5\\",\\"c_sh_h_blur_unit\\":\\"px\\",\\"c_sh_h_blur\\":\\"15\\",\\"c_sh_h_vOffset_unit\\":\\"px\\",\\"c_sh_h_vOffset\\":\\"5\\",\\"c_sh_h_hOffset_unit\\":\\"px\\",\\"c_sh_h_hOffset\\":\\"5\\",\\"c_sh_inset\\":false,\\"c_p_opp_left\\":false,\\"c_p_bottom\\":\\"20\\",\\"c_p_opp_top\\":\\"1\\",\\"c_p_top\\":\\"20\\",\\"font_size_title_unit\\":\\"px\\",\\"font_size_title\\":\\"22\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}]},{\\"element_id\\":\\"0vg9491\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ki4s80\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Vanessa\\\\tThomson\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/vanessa-375x500.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-card-layout\\",\\"width_image\\":\\"375\\",\\"caption_image\\":\\"Director\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"font_color_caption\\":\\"#000000\\",\\"c_b_c\\":\\"#ffffff\\",\\"font_color_title\\":\\"#000000\\",\\"c_sh_h_inset\\":false,\\"c_sh_h_color\\":\\"#000000_0.09\\",\\"c_sh_h_spread_unit\\":\\"px\\",\\"c_sh_h_spread\\":\\"5\\",\\"c_sh_h_blur_unit\\":\\"px\\",\\"c_sh_h_blur\\":\\"15\\",\\"c_sh_h_vOffset_unit\\":\\"px\\",\\"c_sh_h_vOffset\\":\\"5\\",\\"c_sh_h_hOffset_unit\\":\\"px\\",\\"c_sh_h_hOffset\\":\\"5\\",\\"c_sh_inset\\":false,\\"c_p_opp_left\\":false,\\"c_p_bottom\\":\\"20\\",\\"c_p_opp_top\\":\\"1\\",\\"c_p_top\\":\\"20\\",\\"font_size_title_unit\\":\\"px\\",\\"font_size_title\\":\\"22\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}]}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column3-1\\",\\"col_tablet\\":\\"column3-1\\",\\"col_mobile\\":\\"column-full\\"},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ptrf491\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]}],\\"col_tablet_landscape\\":\\"column4-1-4-3\\",\\"col_tablet\\":\\"column4-1-4-3\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"2\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"2\\",\\"breakpoint_mobile\\":{\\"padding_top\\":\\"4\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"0\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}}},{\\"element_id\\":\\"lg4n857\\",\\"cols\\":[{\\"element_id\\":\\"94ud857\\",\\"grid_class\\":\\"col4-3\\",\\"modules\\":[{\\"element_id\\":\\"lnzb858\\",\\"cols\\":[{\\"element_id\\":\\"kq0i858\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ye6v950\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Lucas Underwood\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/lucas-375x500.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-card-layout\\",\\"width_image\\":\\"375\\",\\"caption_image\\":\\"Manager\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"font_color_caption\\":\\"#000000\\",\\"c_b_c\\":\\"#ffffff\\",\\"font_color_title\\":\\"#000000\\",\\"c_sh_h_inset\\":false,\\"c_sh_h_color\\":\\"#000000_0.09\\",\\"c_sh_h_spread_unit\\":\\"px\\",\\"c_sh_h_spread\\":\\"5\\",\\"c_sh_h_blur_unit\\":\\"px\\",\\"c_sh_h_blur\\":\\"15\\",\\"c_sh_h_vOffset_unit\\":\\"px\\",\\"c_sh_h_vOffset\\":\\"5\\",\\"c_sh_h_hOffset_unit\\":\\"px\\",\\"c_sh_h_hOffset\\":\\"5\\",\\"c_sh_inset\\":false,\\"c_p_opp_left\\":false,\\"c_p_bottom\\":\\"20\\",\\"c_p_opp_top\\":\\"1\\",\\"c_p_top\\":\\"20\\",\\"font_size_title_unit\\":\\"px\\",\\"font_size_title\\":\\"22\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}]},{\\"element_id\\":\\"fwru859\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"se1r751\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Connor Hodges\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/connor-375x500.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-card-layout\\",\\"width_image\\":\\"375\\",\\"caption_image\\":\\"Manager\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"font_color_caption\\":\\"#000000\\",\\"c_b_c\\":\\"#ffffff\\",\\"font_color_title\\":\\"#000000\\",\\"c_sh_h_inset\\":false,\\"c_sh_h_color\\":\\"#000000_0.09\\",\\"c_sh_h_spread_unit\\":\\"px\\",\\"c_sh_h_spread\\":\\"5\\",\\"c_sh_h_blur_unit\\":\\"px\\",\\"c_sh_h_blur\\":\\"15\\",\\"c_sh_h_vOffset_unit\\":\\"px\\",\\"c_sh_h_vOffset\\":\\"5\\",\\"c_sh_h_hOffset_unit\\":\\"px\\",\\"c_sh_h_hOffset\\":\\"5\\",\\"c_sh_inset\\":false,\\"c_p_opp_left\\":false,\\"c_p_bottom\\":\\"20\\",\\"c_p_opp_top\\":\\"1\\",\\"c_p_top\\":\\"20\\",\\"font_size_title_unit\\":\\"px\\",\\"font_size_title\\":\\"22\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}]},{\\"element_id\\":\\"j8j8859\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"rf3g962\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Kyla Lee\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/kyla-lee-375x500.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-card-layout\\",\\"width_image\\":\\"375\\",\\"caption_image\\":\\"Manager\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"font_color_caption\\":\\"#000000\\",\\"c_b_c\\":\\"#ffffff\\",\\"font_color_title\\":\\"#000000\\",\\"c_sh_h_inset\\":false,\\"c_sh_h_color\\":\\"#000000_0.09\\",\\"c_sh_h_spread_unit\\":\\"px\\",\\"c_sh_h_spread\\":\\"5\\",\\"c_sh_h_blur_unit\\":\\"px\\",\\"c_sh_h_blur\\":\\"15\\",\\"c_sh_h_vOffset_unit\\":\\"px\\",\\"c_sh_h_vOffset\\":\\"5\\",\\"c_sh_h_hOffset_unit\\":\\"px\\",\\"c_sh_h_hOffset\\":\\"5\\",\\"c_sh_inset\\":false,\\"c_p_opp_left\\":false,\\"c_p_bottom\\":\\"20\\",\\"c_p_opp_top\\":\\"1\\",\\"c_p_top\\":\\"20\\",\\"font_size_title_unit\\":\\"px\\",\\"font_size_title\\":\\"22\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}]}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column3-1\\",\\"col_tablet\\":\\"column3-1\\"}]},{\\"element_id\\":\\"zzgv858\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"4ysu858\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Project Managers<\\\\/h3>\\",\\"text_align\\":\\"left\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_align\\":\\"center\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}},{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"cdr9858\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"4\\",\\"color_divider\\":\\"#c5a47e\\",\\"divider_width\\":\\"150\\",\\"divider_type\\":\\"fullwidth\\",\\"style_divider\\":\\"solid\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"wqgf860\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}}}]}],\\"mobile_dir\\":\\"rtl\\",\\"col_tablet_landscape\\":\\"column4-3-4-1\\",\\"col_tablet\\":\\"column4-3-4-1\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"2\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"2\\"}},{\\"element_id\\":\\"c5qz331\\",\\"cols\\":[{\\"element_id\\":\\"yzpy332\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"8lb3812\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Designers<\\\\/h3>\\",\\"text_align\\":\\"right\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_align\\":\\"center\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}},{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"w9bb302\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"4\\",\\"color_divider\\":\\"#c5a47e\\",\\"divider_width\\":\\"150\\",\\"divider_type\\":\\"fullwidth\\",\\"style_divider\\":\\"solid\\"}}]},{\\"element_id\\":\\"1ip763\\",\\"grid_class\\":\\"col4-3\\",\\"modules\\":[{\\"element_id\\":\\"j8bm908\\",\\"cols\\":[{\\"element_id\\":\\"ggcr909\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"foiv801\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Emily Cornish\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/Emily-375x500.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-card-layout\\",\\"width_image\\":\\"375\\",\\"caption_image\\":\\"Designer\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"font_color_caption\\":\\"#000000\\",\\"c_b_c\\":\\"#ffffff\\",\\"font_color_title\\":\\"#000000\\",\\"c_sh_h_inset\\":false,\\"c_sh_h_color\\":\\"#000000_0.09\\",\\"c_sh_h_spread_unit\\":\\"px\\",\\"c_sh_h_spread\\":\\"5\\",\\"c_sh_h_blur_unit\\":\\"px\\",\\"c_sh_h_blur\\":\\"15\\",\\"c_sh_h_vOffset_unit\\":\\"px\\",\\"c_sh_h_vOffset\\":\\"5\\",\\"c_sh_h_hOffset_unit\\":\\"px\\",\\"c_sh_h_hOffset\\":\\"5\\",\\"c_sh_inset\\":false,\\"c_p_opp_left\\":false,\\"c_p_bottom\\":\\"20\\",\\"c_p_opp_top\\":\\"1\\",\\"c_p_top\\":\\"20\\",\\"font_size_title_unit\\":\\"px\\",\\"font_size_title\\":\\"22\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}]},{\\"element_id\\":\\"bvjj910\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"616h345\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Kevin\\\\tMacDonald\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/kevin-375x500.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-card-layout\\",\\"width_image\\":\\"375\\",\\"caption_image\\":\\"Designer\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"font_color_caption\\":\\"#000000\\",\\"c_b_c\\":\\"#ffffff\\",\\"font_color_title\\":\\"#000000\\",\\"c_sh_h_inset\\":false,\\"c_sh_h_color\\":\\"#000000_0.09\\",\\"c_sh_h_spread_unit\\":\\"px\\",\\"c_sh_h_spread\\":\\"5\\",\\"c_sh_h_blur_unit\\":\\"px\\",\\"c_sh_h_blur\\":\\"15\\",\\"c_sh_h_vOffset_unit\\":\\"px\\",\\"c_sh_h_vOffset\\":\\"5\\",\\"c_sh_h_hOffset_unit\\":\\"px\\",\\"c_sh_h_hOffset\\":\\"5\\",\\"c_sh_inset\\":false,\\"c_p_opp_left\\":false,\\"c_p_bottom\\":\\"20\\",\\"c_p_opp_top\\":\\"1\\",\\"c_p_top\\":\\"20\\",\\"font_size_title_unit\\":\\"px\\",\\"font_size_title\\":\\"22\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}]},{\\"element_id\\":\\"t6ye910\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"2e9c760\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"John Rutherford\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/rebbeca-liu-375x500.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-card-layout\\",\\"width_image\\":\\"375\\",\\"caption_image\\":\\"Designer\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"font_color_caption\\":\\"#000000\\",\\"c_b_c\\":\\"#ffffff\\",\\"font_color_title\\":\\"#000000\\",\\"c_sh_h_inset\\":false,\\"c_sh_h_color\\":\\"#000000_0.09\\",\\"c_sh_h_spread_unit\\":\\"px\\",\\"c_sh_h_spread\\":\\"5\\",\\"c_sh_h_blur_unit\\":\\"px\\",\\"c_sh_h_blur\\":\\"15\\",\\"c_sh_h_vOffset_unit\\":\\"px\\",\\"c_sh_h_vOffset\\":\\"5\\",\\"c_sh_h_hOffset_unit\\":\\"px\\",\\"c_sh_h_hOffset\\":\\"5\\",\\"c_sh_inset\\":false,\\"c_p_opp_left\\":false,\\"c_p_bottom\\":\\"20\\",\\"c_p_opp_top\\":\\"1\\",\\"c_p_top\\":\\"20\\",\\"font_size_title_unit\\":\\"px\\",\\"font_size_title\\":\\"22\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}]}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column3-1\\",\\"col_tablet\\":\\"column3-1\\"},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"2j43470\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]}],\\"col_tablet_landscape\\":\\"column4-1-4-3\\",\\"col_tablet\\":\\"column4-1-4-3\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"2\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"2\\"}},{\\"element_id\\":\\"18pw921\\",\\"cols\\":[{\\"element_id\\":\\"7qs5921\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"layout-part\\",\\"element_id\\":\\"2nms921\\",\\"mod_settings\\":{\\"selected_layout_part\\":\\"newsletter\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"padding_top\\":8,\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 252,
  'post_date' => '2021-02-12 13:17:21',
  'post_date_gmt' => '2021-02-12 13:17:21',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Portfolio</h1> <p>Interior Design Co is a full service design. We partner and collaborate with third-party vendors, making each project special and distinct.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/upstair-design-1160x497.jpg" width="1160" height="497" title="upstair-design" alt="upstair-design" srcset="https://themify.me/demo/themes/ultra-interior/files/2021/02/upstair-design-1160x497.jpg 1160w, https://themify.me/demo/themes/ultra-interior/files/2021/02/upstair-design-600x257.jpg 600w, https://themify.me/demo/themes/ultra-interior/files/2021/02/upstair-design-768x329.jpg 768w, https://themify.me/demo/themes/ultra-interior/files/2021/02/upstair-design.jpg 1400w" sizes="(max-width: 1160px) 100vw, 1160px" />
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/bedroom-560x400-560x239.jpg" width="560" height="239" title="bedroom" alt="bedroom" srcset="https://themify.me/demo/themes/ultra-interior/files/2021/02/bedroom-560x400-560x239.jpg 560w, https://themify.me/demo/themes/ultra-interior/files/2021/02/bedroom-600x257.jpg 600w, https://themify.me/demo/themes/ultra-interior/files/2021/02/bedroom-768x329.jpg 768w, https://themify.me/demo/themes/ultra-interior/files/2021/02/bedroom.jpg 1400w" sizes="(max-width: 560px) 100vw, 560px" />
<h2>Residential Projects</h2> <p>We pride ourselves in exceeding client expectations. We are part of our client\'s journey in turning their dream home into existence - from designing, conceptualizing and to materializing their vision. We create custom residences that reflects each individual\'s unique lifestyles and demands.</p>
<a href="https://themify.me/" > Learn more <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> </a>
<h2>Commercial Projects</h2> <p>With over hundreds of hotel projects, we continue to do extensive market research to ensure that our designs remain current so it relates to a broader market. With the partnership of architects, contractors and design, we ensure that each process is successful throughout the duration of the project.</p>
<a href="https://themify.me/" > Learn more <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/portfolio-project-hotel-560x416.jpg" width="560" height="416" title="portfolio-project-hotel" alt="portfolio-project-hotel" srcset="https://themify.me/demo/themes/ultra-interior/files/2021/02/portfolio-project-hotel-560x416.jpg 560w, https://themify.me/demo/themes/ultra-interior/files/2021/02/portfolio-project-hotel-600x447.jpg 600w, https://themify.me/demo/themes/ultra-interior/files/2021/02/portfolio-project-hotel.jpg 645w" sizes="(max-width: 560px) 100vw, 560px" />
<h2>We partner with our clients to understand their vision, objectives and other opportunities so we can deliver a design fit exclusively for you.</h2>
<h2>Recent Projects</h2>
<a href="https://themify.me/" > View more <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> </a><!--/themify_builder_static-->',
  'post_title' => 'Portfolio',
  'post_excerpt' => '',
  'post_name' => 'portfolio',
  'post_modified' => '2021-03-27 04:09:47',
  'post_modified_gmt' => '2021-03-27 04:09:47',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?page_id=252',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"aj6r643\\",\\"cols\\":[{\\"element_id\\":\\"dcx5644\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"jguk644\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Portfolio<\\\\/h1>\\\\n<p>Interior Design Co is a full service design. We partner and collaborate with third-party vendors, making each project special and distinct.<\\\\/p>\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\"}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"padding_top\\":\\"2\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"2\\",\\"padding_opp_top\\":\\"1\\"}},{\\"element_id\\":\\"xzo1775\\",\\"cols\\":[{\\"element_id\\":\\"edx4775\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"g6d0602\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/upstair-design-1160x497.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"width_image\\":\\"1160\\"}}]}]},{\\"element_id\\":\\"ka84947\\",\\"cols\\":[{\\"element_id\\":\\"5e03948\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"xm94788\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/bedroom-560x400.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"width_image\\":\\"560\\"}}]},{\\"element_id\\":\\"x3ig942\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"1ltd766\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Residential Projects<\\\\/h2>\\\\n<p>We pride ourselves in exceeding client expectations. We are part of our client\\\'s journey in turning their dream home into existence - from designing, conceptualizing and to materializing their vision. We create custom residences that reflects each individual\\\'s unique lifestyles and demands.<\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"10\\",\\"h2_margin_top_unit\\":\\"px\\",\\"h2_margin_top\\":\\"15\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"},\\"breakpoint_tablet\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"35\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"},\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_color\\":\\"#ffffff\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"4v1f780\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Learn more\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_alignment\\":\\"right\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_transform\\":\\"uppercase\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_top\\":\\"8\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"8\\",\\"padding_opp_bottom\\":\\"1\\"}},{\\"element_id\\":\\"5tvs764\\",\\"cols\\":[{\\"element_id\\":\\"vz3d765\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"oack813\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Commercial Projects<\\\\/h2>\\\\n<p>With over hundreds of hotel projects, we continue to do extensive market research to ensure that our designs remain current so it relates to a broader market. With the partnership of architects, contractors and design, we ensure that each process is successful throughout the duration of the project.<\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_align\\":\\"left\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"},\\"breakpoint_tablet\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"35\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"},\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"2fk8211\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Learn more\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_alignment\\":\\"right\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_transform\\":\\"uppercase\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"alignment\\":\\"left\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}}}],\\"styling\\":{\\"text_align\\":\\"right\\"}},{\\"element_id\\":\\"8st7471\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"31c0653\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/portfolio-project-hotel.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"width_image\\":\\"560\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"8\\",\\"padding_opp_bottom\\":false}},{\\"element_id\\":\\"qhm6465\\",\\"cols\\":[{\\"element_id\\":\\"wp36467\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"kutr474\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>We partner with our clients to understand their vision, objectives and other opportunities so we can deliver a design fit exclusively for you.<\\\\/h2>\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"},\\"breakpoint_tablet\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"35\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}}}],\\"styling\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"3\\",\\"background_color\\":\\"#000000_0.20\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"10\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":11,\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/bg-other-project.jpg\\",\\"text_align\\":\\"center\\",\\"font_color\\":\\"#ffffff\\"}},{\\"element_id\\":\\"afip601\\",\\"cols\\":[{\\"element_id\\":\\"4lz3602\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"fotn450\\",\\"cols\\":[{\\"element_id\\":\\"u355452\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"xp0r160\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Recent Projects<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"margin_top\\":\\"-60\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"30\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"30\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_color\\":\\"#ffffff\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"h2_margin_top_unit\\":\\"px\\",\\"h2_margin_top\\":\\"0\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.05\\",\\"b_sh_spread_unit\\":\\"px\\",\\"b_sh_spread\\":\\"0\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"10\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"0\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"0\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"h2_margin_top_unit\\":\\"px\\",\\"h2_margin_top\\":\\"0\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_right\\":\\"20\\",\\"padding_left_unit\\":\\"px\\",\\"padding_left\\":\\"20\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_bottom\\":\\"30\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"30\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"h2_margin_top_unit\\":\\"px\\",\\"h2_margin_top\\":\\"0\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"35\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"margin_top\\":\\"-60\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_align\\":\\"center\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}}]},{\\"element_id\\":\\"tzsn453\\",\\"grid_class\\":\\"col2-1\\"}]},{\\"mod_name\\":\\"portfolio\\",\\"element_id\\":\\"na7y737\\",\\"mod_settings\\":{\\"layout_portfolio\\":\\"grid3\\",\\"post_per_page_portfolio\\":\\"3\\",\\"hide_page_nav_portfolio\\":\\"yes\\",\\"display_portfolio\\":\\"none\\",\\"hide_post_meta_portfolio\\":\\"no\\",\\"hide_post_date_portfolio\\":\\"yes\\",\\"unlink_post_title_portfolio\\":\\"no\\",\\"hide_post_title_portfolio\\":\\"no\\",\\"unlink_feat_img_portfolio\\":\\"no\\",\\"auto_fullwidth_portfolio\\":false,\\"hide_feat_img_portfolio\\":\\"no\\",\\"orderby_portfolio\\":\\"date\\",\\"order_portfolio\\":\\"desc\\",\\"post_filter\\":\\"no\\",\\"category_portfolio\\":\\"0|single\\",\\"term_type\\":\\"category\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"margin_top\\":\\"70\\",\\"img_height_portfolio\\":\\"186\\",\\"img_width_portfolio\\":\\"362\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"c3b5671\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View more\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_alignment\\":\\"right\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_transform\\":\\"uppercase\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"alignment\\":\\"center\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"8\\",\\"padding_opp_bottom\\":false}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 361,
  'post_date' => '2021-02-18 11:24:54',
  'post_date_gmt' => '2021-02-18 11:24:54',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Our Services</h1> <p>At Interior Design Co., our team of designers and stylists customizes a plan suitable for your individuality and your objectives. It suits all lifestyles and all budget for each of our clients.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/custom-interior-furniture-700x500.jpg" width="700" height="500" title="custom-interior-furniture" alt="custom-interior-furniture">
<h2>Full interior design services</h2> <p>Our objective is to be a one-stop shop for all our client\'s design needs. We ensure that we see through each stages of the project until its completion. Our team of architects, designers, and stylists will create a tailored design plan that is a reflection of you or your business. We begin with in-depth research and scour the globe to find you the perfect pieces, all the while adhering to your budget and your objectives.</p>
<a href="https://themify.me/" > Learn more <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> </a>
<h2>Our Patners</h2>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/logo-artdeco-174x58.png" width="174" height="58" title="logo-artdeco" alt="logo-artdeco">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/logo-tutto-174x58.png" width="174" height="58" title="logo-tutto" alt="logo-tutto">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/logo-belikoff-174x58.png" width="174" height="58" title="logo-belikoff" alt="logo-belikoff">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/logo-simplify-174x58.png" width="174" height="58" title="logo-simplify" alt="logo-simplify">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/logo-dimensia-174x58.png" width="174" height="58" title="logo-dimensia" alt="logo-dimensia">
<h2>Property Staging</h2> <p>Whether you are deciding to sell your property or would like to transform your place of business and store, our property staging services is sure to attract any buyers and customers. We provide both occupied staging where we will use owner\'s furnishing and accessories into the design, as well as, vacant staging, which is a comprehensive staging service. All the while, keeping in mind the target demographic and the budget of our clients.</p>
<a href="https://themify.me/" > Learn more <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/staging-b-600x550.jpg" width="600" height="550" title="staging-b" alt="staging-b">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/interior-staging-593x650.jpg" width="593" height="650" title="interior-staging" alt="interior-staging">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/interior-hotel-600x550.jpg" width="600" height="550" title="interior-hotel" alt="interior-hotel">
<h2>Retail Design</h2> <p>Offering a full range of designs for your retail space. We offer services for the following spaces:</p> <h3>Restaurant &amp; Cafe </h3> <h3>Office Design</h3> <h3>Hotel and Homestay Design</h3>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/apartment-interior-600x600.jpg" width="600" height="600" title="apartment-interior" alt="apartment-interior" srcset="https://themify.me/demo/themes/ultra-interior/files/2021/02/apartment-interior-600x600.jpg 600w, https://themify.me/demo/themes/ultra-interior/files/2021/02/apartment-interior-150x150.jpg 150w" sizes="(max-width: 600px) 100vw, 600px" />
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/floor-panel-600x600.jpg" width="600" height="600" title="floor-panel" alt="floor-panel" srcset="https://themify.me/demo/themes/ultra-interior/files/2021/02/floor-panel-600x600.jpg 600w, https://themify.me/demo/themes/ultra-interior/files/2021/02/floor-panel-150x150.jpg 150w" sizes="(max-width: 600px) 100vw, 600px" />
<h2>House Renovation</h2> <p>Specializing in all phases of residential design and interiors, our goal is to truly transform your space into a home which reflects your individuality. We change the function and energy of your space to fit your lifestyle and your aesthetics. Let us help you with the transformation of your space whether you are looking to remodel or a new build. Our full range of services include space planning, furniture selections, kitchen and bath design, an architectural space review and accessorizing.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/renovation-plan-375x512.jpg" width="375" height="512" title="Renovation &amp; Remodelling" alt="Renovation &amp; Remodelling" srcset="https://themify.me/demo/themes/ultra-interior/files/2021/02/renovation-plan-375x512.jpg 375w, https://themify.me/demo/themes/ultra-interior/files/2021/02/renovation-plan.jpg 400w" sizes="(max-width: 375px) 100vw, 375px" /> <h3> Renovation & Remodelling </h3>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/advices-375x513.jpg" width="375" height="513" title="Advices &amp; Consultation" alt="Advices &amp; Consultation" srcset="https://themify.me/demo/themes/ultra-interior/files/2021/02/advices-375x513.jpg 375w, https://themify.me/demo/themes/ultra-interior/files/2021/02/advices-439x600.jpg 439w, https://themify.me/demo/themes/ultra-interior/files/2021/02/advices-400x547.jpg 400w, https://themify.me/demo/themes/ultra-interior/files/2021/02/advices.jpg 500w" sizes="(max-width: 375px) 100vw, 375px" /> <h3> Advices & Consultation </h3>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-interior/files/2021/02/worker-375x512.jpg" width="375" height="512" title="Professional Workers" alt="Professional Workers" srcset="https://themify.me/demo/themes/ultra-interior/files/2021/02/worker-375x512.jpg 375w, https://themify.me/demo/themes/ultra-interior/files/2021/02/worker.jpg 400w, https://themify.me/demo/themes/ultra-interior/files/2021/02/worker-350x478.jpg 350w" sizes="(max-width: 375px) 100vw, 375px" /> <h3> Professional Workers </h3>
<h3>Renovation Plan</h3> <p>We know that embarking into renovations can be daunting and expensive. That is why we make the process as seamless as possible to ensure that we are with you from concept through execution. Our renovation plan starts with meeting with our team of architects and designers and drawing out each stages of the renovation, providing transparency and managing expectations. </p>
<a href="https://themify.me/" > Learn more <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> </a>
<h2>Get a Quote</h2> <p>We would love to hear about your upcoming project! Contact us to book a 1:1 consultation with one of our talented designers so we can discuss your project in great detail together and get a quote. Initial consultations will be free of charge.</p>
<a href="https://themify.me/demo/themes/ultra-interior/contact/" > Contact Us <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> </a><!--/themify_builder_static-->',
  'post_title' => 'Services',
  'post_excerpt' => '',
  'post_name' => 'services',
  'post_modified' => '2021-03-27 04:07:27',
  'post_modified_gmt' => '2021-03-27 04:07:27',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?page_id=361',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"pjqw80\\",\\"cols\\":[{\\"element_id\\":\\"9zon80\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"39fw80\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Our Services<\\\\/h1>\\\\n<p>At Interior Design Co., our team of designers and stylists customizes a plan suitable for your individuality and your objectives. It suits all lifestyles and all budget for each of our clients.<\\\\/p>\\"}}]},{\\"element_id\\":\\"ha7881\\",\\"grid_class\\":\\"col3-1\\"}],\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"background_position\\":\\"54,95\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/bg-hero-service.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_top\\":\\"184\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":391,\\"padding_opp_top\\":false,\\"font_color\\":\\"#ffffff\\",\\"zi\\":\\"1\\",\\"breakpoint_mobile\\":{\\"padding_top\\":108,\\"padding_top_unit\\":\\"px\\",\\"padding_bottom\\":163,\\"padding_bottom_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"padding_top\\":\\"108\\",\\"padding_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_bottom\\":\\"219\\",\\"padding_opp_bottom\\":false},\\"breakpoint_tablet_landscape\\":{\\"padding_top\\":147,\\"padding_top_unit\\":\\"px\\",\\"padding_bottom\\":200,\\"padding_bottom_unit\\":\\"px\\"},\\"cover_gradient-circle-radial\\":false,\\"cover_gradient-gradient-angle\\":\\"180\\",\\"cover_gradient-gradient-type\\":\\"linear\\",\\"cover_color-type\\":\\"color\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\"}},{\\"element_id\\":\\"pt5a172\\",\\"cols\\":[{\\"element_id\\":\\"s3tc172\\",\\"grid_class\\":\\"col4-1\\",\\"grid_width\\":12.53999999999999914734871708787977695465087890625},{\\"element_id\\":\\"pmpk173\\",\\"grid_class\\":\\"col4-3\\",\\"modules\\":[{\\"element_id\\":\\"yuym174\\",\\"cols\\":[{\\"element_id\\":\\"zpji175\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"l8pq175\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"700\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/custom-interior-furniture-700x500.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"-10\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"%\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"-10\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"-10\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"},\\"margin_top\\":\\"-25\\",\\"height_image\\":\\"500\\"}}],\\"grid_width\\":46.63000000000000255795384873636066913604736328125},{\\"element_id\\":\\"lnd1175\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"fwzw176\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Full interior design services<\\\\/h2>\\\\n<p>Our objective is to be a one-stop shop for all our client\\\'s design needs. We ensure that we see through each stages of the project until its completion. Our team of architects, designers, and stylists will create a tailored design plan that is a reflection of you or your business. We begin with in-depth research and scour the globe to find you the perfect pieces, all the while adhering to your budget and your objectives.<\\\\/p>\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"30\\",\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"30\\",\\"margin_opp_left\\":\\"1\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"30\\",\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"30\\",\\"margin_opp_left\\":\\"1\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"ylmu553\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Learn more\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_alignment\\":\\"right\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_transform\\":\\"uppercase\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"30\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"30\\",\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"30\\",\\"margin_opp_left\\":\\"1\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}}}],\\"grid_width\\":53.36999999999999744204615126363933086395263671875,\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_right\\":\\"60\\",\\"padding_opp_top\\":false}}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet\\":\\"column-full\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"2\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"7\\",\\"padding_opp_bottom\\":false}}],\\"grid_width\\":84.2600000000000051159076974727213382720947265625,\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"background_color\\":\\"#ffffff\\"}}],\\"col_tablet\\":\\"column-full\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"padding_top\\":\\"0\\",\\"hide_anchor\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"4\\",\\"padding_opp_top\\":false,\\"zi\\":\\"3\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":\\"-10\\",\\"padding_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"padding_bottom\\":10,\\"padding_bottom_unit\\":\\"%\\"},\\"breakpoint_tablet\\":{\\"padding_bottom\\":8,\\"padding_bottom_unit\\":\\"%\\"}}},{\\"element_id\\":\\"emax267\\",\\"cols\\":[{\\"element_id\\":\\"i7uc269\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"5ea6418\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Patners<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"40\\",\\"margin_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}}},{\\"element_id\\":\\"m8z4284\\",\\"cols\\":[{\\"element_id\\":\\"8low286\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"k81y751\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"58\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"174\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/logo-artdeco-174x58.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"breakpoint_mobile\\":{\\"checkbox_i_t_m_apply_all\\":false,\\"i_t_m_right_unit\\":\\"px\\",\\"i_t_m_left_unit\\":\\"px\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_bottom_unit\\":\\"px\\",\\"i_t_m_bottom\\":\\"20\\",\\"i_t_m_opp_bottom\\":false,\\"i_t_m_top_unit\\":\\"px\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\"}}]},{\\"element_id\\":\\"6st0287\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"xbuw527\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"58\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"174\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/logo-tutto-174x58.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"breakpoint_mobile\\":{\\"checkbox_i_t_m_apply_all\\":false,\\"i_t_m_right_unit\\":\\"px\\",\\"i_t_m_left_unit\\":\\"px\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_bottom_unit\\":\\"px\\",\\"i_t_m_bottom\\":\\"20\\",\\"i_t_m_opp_bottom\\":false,\\"i_t_m_top_unit\\":\\"px\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\"}}]},{\\"element_id\\":\\"p0rk287\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"gl3v618\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"58\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"174\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/logo-belikoff-174x58.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"breakpoint_mobile\\":{\\"checkbox_i_t_m_apply_all\\":false,\\"i_t_m_right_unit\\":\\"px\\",\\"i_t_m_left_unit\\":\\"px\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_bottom_unit\\":\\"px\\",\\"i_t_m_bottom\\":\\"20\\",\\"i_t_m_opp_bottom\\":false,\\"i_t_m_top_unit\\":\\"px\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\"}}]},{\\"element_id\\":\\"b0nk10\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"84dw526\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"58\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"174\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/logo-simplify-174x58.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"breakpoint_mobile\\":{\\"checkbox_i_t_m_apply_all\\":false,\\"i_t_m_right_unit\\":\\"px\\",\\"i_t_m_left_unit\\":\\"px\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_bottom_unit\\":\\"px\\",\\"i_t_m_bottom\\":\\"20\\",\\"i_t_m_opp_bottom\\":false,\\"i_t_m_top_unit\\":\\"px\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\"}}]},{\\"element_id\\":\\"556f720\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"btg8837\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"58\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"174\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/logo-dimensia-174x58.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_tablet_landscape\\":\\"column5-1\\"}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"8\\",\\"padding_opp_bottom\\":false}},{\\"element_id\\":\\"0xtq925\\",\\"cols\\":[{\\"element_id\\":\\"mdey926\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"vugf539\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Property Staging<\\\\/h2>\\\\n<p>Whether you are deciding to sell your property or would like to transform your place of business and store, our property staging services is sure to attract any buyers and customers. We provide both occupied staging where we will use owner\\\'s furnishing and accessories into the design, as well as, vacant staging, which is a comprehensive staging service. All the while, keeping in mind the target demographic and the budget of our clients.<\\\\/p>\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"04os36\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Learn more\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_alignment\\":\\"right\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_transform\\":\\"uppercase\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"g6us887\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"jlqg484\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/staging-b-600x550.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"height_image\\":\\"550\\",\\"width_image\\":\\"600\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"8\\",\\"padding_opp_bottom\\":false}},{\\"element_id\\":\\"t94r219\\",\\"cols\\":[{\\"element_id\\":\\"wto7221\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"k2a6426\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/interior-staging-593x650.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"height_image\\":\\"650\\",\\"width_image\\":\\"593\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}}]},{\\"element_id\\":\\"4yfa188\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"j313188\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/interior-hotel-600x550.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_speed\\":\\"2\\",\\"v_dir\\":\\"up\\"}}},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"height_image\\":\\"550\\",\\"width_image\\":\\"600\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"2xu0221\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Retail Design<\\\\/h2>\\\\n<p>Offering a full range of designs for your retail space. We offer services for the following spaces:<\\\\/p>\\\\n<h3>Restaurant &amp; Cafe <\\\\/h3>\\\\n<h3>Office Design<\\\\/h3>\\\\n<h3>Hotel and Homestay Design<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"14\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_speed\\":\\"2\\",\\"v_dir\\":\\"up\\"}}},\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}}}]}],\\"col_tablet_landscape\\":\\"column4-2\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"8\\",\\"padding_opp_bottom\\":false}},{\\"element_id\\":\\"wrjr438\\",\\"cols\\":[{\\"element_id\\":\\"g50m440\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ptdo359\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/apartment-interior-600x600.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"600\\",\\"width_image\\":\\"600\\"}}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"uxts440\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"m153698\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/floor-panel-600x600.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"600\\",\\"width_image\\":\\"600\\"}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}}],\\"gutter\\":\\"gutter-narrow\\",\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"zi\\":\\"1\\"}},{\\"element_id\\":\\"y173941\\",\\"cols\\":[{\\"element_id\\":\\"blb0470\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"g8ug875\\",\\"cols\\":[{\\"element_id\\":\\"0zh6877\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"dszy472\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>House Renovation<\\\\/h2>\\\\n<p>Specializing in all phases of residential design and interiors, our goal is to truly transform your space into a home which reflects your individuality. We change the function and energy of your space to fit your lifestyle and your aesthetics. Let us help you with the transformation of your space whether you are looking to remodel or a new build. Our full range of services include space planning, furniture selections, kitchen and bath design, an architectural space review and accessorizing.<\\\\/p>\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}}}]}],\\"styling\\":{\\"margin_right\\":\\"20\\",\\"margin_left\\":\\"20\\",\\"margin_opp_left\\":\\"1\\",\\"margin_opp_bottom\\":false,\\"background_color\\":\\"#ffffff\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"padding_right\\":\\"40\\",\\"padding_left\\":\\"40\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"40\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"40\\",\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.11\\",\\"b_sh_spread_unit\\":\\"px\\",\\"b_sh_spread\\":\\"10\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"20\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"0\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"1\\"}}],\\"styling\\":{\\"padding_opp_bottom\\":\\"1\\",\\"padding_right\\":\\"30\\",\\"padding_left\\":\\"30\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"30\\",\\"padding_top\\":\\"40\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_right_unit\\":\\"px\\",\\"padding_right\\":\\"30\\",\\"padding_left_unit\\":\\"px\\",\\"padding_left\\":\\"30\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_bottom\\":\\"30\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"0\\"}}}],\\"styling\\":{\\"zi\\":\\"3\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":\\"-12\\",\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\",\\"margin-top\\":40}}},{\\"element_id\\":\\"x0x8568\\",\\"cols\\":[{\\"element_id\\":\\"jayb569\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"element_id\\":\\"g9ue222\\",\\"cols\\":[{\\"element_id\\":\\"pprd222\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"1ai2482\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"375\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/renovation-plan-375x512.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-card-layout\\",\\"title_image\\":\\"Renovation & Remodelling\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}}]},{\\"element_id\\":\\"ulps222\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"zacb793\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"375\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/advices-375x513.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-card-layout\\",\\"title_image\\":\\"Advices & Consultation\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}}]},{\\"element_id\\":\\"5dnh223\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"0wqd268\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"375\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/worker-375x512.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-card-layout\\",\\"title_image\\":\\"Professional Workers\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}}]}],\\"col_tablet_landscape\\":\\"column3-1\\",\\"col_tablet\\":\\"column3-1\\",\\"col_mobile\\":\\"column-full\\"}]},{\\"element_id\\":\\"4xsc984\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"in5s370\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Renovation Plan<\\\\/h3>\\\\n<p>We know that embarking into renovations can be daunting and expensive. That is why we make the process as seamless as possible to ensure that we are with you from concept through execution. Our renovation plan starts with meeting with our team of architects and designers and drawing out each stages of the renovation, providing transparency and managing expectations. <\\\\/p>\\",\\"margin_right\\":\\"60\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"60\\",\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"60\\",\\"margin_opp_left\\":\\"1\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"padding_top\\":34,\\"padding_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"30\\",\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"30\\",\\"margin_opp_left\\":\\"1\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"gn3w176\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Learn more\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_alignment\\":\\"right\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_transform\\":\\"uppercase\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"alignment\\":\\"center\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\"}}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"mobile_dir\\":\\"rtl\\",\\"col_tablet\\":\\"column-full\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"8\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"8\\",\\"row_width\\":\\"fullwidth-content\\"}},{\\"element_id\\":\\"saqo766\\",\\"cols\\":[{\\"element_id\\":\\"m94y767\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"fjfo468\\",\\"cols\\":[{\\"element_id\\":\\"mtfs469\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ep1w492\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Get a Quote<\\\\/h2>\\\\n<p>We would love to hear about your upcoming project! Contact us to book a 1:1 consultation with one of our talented designers so we can discuss your project in great detail together and get a quote. Initial consultations will be free of charge.<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"byuy914\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Contact Us\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/contact\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_alignment\\":\\"right\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_transform\\":\\"uppercase\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}]}],\\"styling\\":{\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"margin_top\\":\\"-150\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"6\\",\\"padding_left\\":\\"6\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"5\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"background_color\\":\\"#ffffff\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.16\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"32\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"5\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"0\\"}}],\\"styling\\":{\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":\\"1\\"}}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":28,\\"padding_opp_bottom\\":false,\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-interior\\\\/files\\\\/2021\\\\/02\\\\/bg-service-banner.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"text_align\\":\\"center\\",\\"font_color\\":\\"#000000\\",\\"cover_color-type\\":\\"color\\",\\"zi\\":\\"1\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\",\\"margin-top\\":\\"160\\",\\"hide_anchor\\":false}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 675,
  'post_date' => '2021-05-27 04:23:46',
  'post_date_gmt' => '2021-05-27 04:23:46',
  'post_content' => '<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Transform',
  'post_excerpt' => '',
  'post_name' => 'transform',
  'post_modified' => '2021-05-27 04:23:47',
  'post_modified_gmt' => '2021-05-27 04:23:47',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?page_id=675',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"7qba970\\",\\"cols\\":[{\\"element_id\\":\\"q4ez971\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 174,
  'post_date' => '2021-02-10 07:34:54',
  'post_date_gmt' => '2021-02-10 07:34:54',
  'post_content' => '<!--themify_builder_static--><h2>Our Newsletter</h2><!--/themify_builder_static-->',
  'post_title' => 'Newsletter',
  'post_excerpt' => '',
  'post_name' => 'newsletter',
  'post_modified' => '2021-02-25 06:57:05',
  'post_modified_gmt' => '2021-02-25 06:57:05',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=tbuilder_layout_part&#038;p=174',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout_part',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"tinc865\\",\\"cols\\":[{\\"element_id\\":\\"n5pq867\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"k0gl28\\",\\"cols\\":[{\\"element_id\\":\\"1gc829\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"iqbr29\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Newsletter<\\\\/h2>\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"30\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}}]},{\\"element_id\\":\\"yh7v30\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"optin\\",\\"element_id\\":\\"n7ub30\\",\\"mod_settings\\":{\\"label_firstname\\":\\"First Name\\",\\"default_fname\\":\\"John\\",\\"label_lastname\\":\\"Last Name\\",\\"default_lname\\":\\"Doe\\",\\"label_submit\\":\\"Subscribe\\",\\"message\\":\\"<p>Success!<\\\\/p>\\",\\"layout\\":\\"tb_optin_horizontal\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"success_action\\":\\"s2\\",\\"lname_hide\\":\\"1\\",\\"fname_hide\\":\\"1\\",\\"mailchimp_list\\":\\"0f2a95e5de\\",\\"provider\\":\\"mailchimp\\",\\"email_placeholder\\":\\"Enter your email\\"}}]}],\\"styling\\":{\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.19\\",\\"b_sh_spread_unit\\":\\"px\\",\\"b_sh_spread\\":\\"10\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"20\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"8\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"1\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_top\\":\\"4\\",\\"background_color\\":\\"#ffffff\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}]}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 319,
  'post_date' => '2021-02-13 13:27:44',
  'post_date_gmt' => '2021-02-13 13:27:44',
  'post_content' => 'Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat epellendus.  Ton provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.

Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate.',
  'post_title' => 'Apartment interior layout',
  'post_excerpt' => '',
  'post_name' => 'apartment-interior-layout',
  'post_modified' => '2021-02-13 13:33:37',
  'post_modified_gmt' => '2021-02-13 13:33:37',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=319',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Aug, 29 2020',
    'project_client' => 'Franklin Underwood',
    'project_services' => 'Layout Planning',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"22et820\\",\\"cols\\":[{\\"element_id\\":\\"z6s1821\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'interior-design',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/apartment-interior.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 350,
  'post_date' => '2021-02-13 13:25:21',
  'post_date_gmt' => '2021-02-13 13:25:21',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit ess. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.',
  'post_title' => 'Modern office furniture',
  'post_excerpt' => '',
  'post_name' => 'modern-office-furniture',
  'post_modified' => '2021-02-13 13:34:01',
  'post_modified_gmt' => '2021-02-13 13:34:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=350',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Feb, 13 2021',
    'project_client' => 'GoodBrew CO',
    'project_services' => 'Interior Design',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"6wo0912\\",\\"cols\\":[{\\"element_id\\":\\"9m5r913\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'furniture',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/office-layout.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 348,
  'post_date' => '2021-02-13 13:22:29',
  'post_date_gmt' => '2021-02-13 13:22:29',
  'post_content' => 'Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat epellendus.  Ton provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.

Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate.',
  'post_title' => 'Modern futuristic lounge',
  'post_excerpt' => '',
  'post_name' => 'modern-futuristic-lounge',
  'post_modified' => '2021-02-13 13:34:08',
  'post_modified_gmt' => '2021-02-13 13:34:08',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=348',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Feb, 11 2021',
    'project_client' => 'iSwtch CO',
    'project_services' => 'Interior Design, Layout Planning',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"ahzy895\\",\\"cols\\":[{\\"element_id\\":\\"iyc2896\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'planning',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/futuristic-lounge.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 352,
  'post_date' => '2021-02-13 13:22:10',
  'post_date_gmt' => '2021-02-13 13:22:10',
  'post_content' => 'Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat epellendus.  Ton provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.

Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate.',
  'post_title' => 'Tropical simple kitchen room',
  'post_excerpt' => '',
  'post_name' => 'tropical-simple-kitchen-room',
  'post_modified' => '2021-02-13 13:32:50',
  'post_modified_gmt' => '2021-02-13 13:32:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=352',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Feb, 14 2021',
    'project_client' => 'Shabby Chich Co',
    'project_services' => 'Interior Design',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"q3e0834\\",\\"cols\\":[{\\"element_id\\":\\"wur6835\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'furniture, interior-design',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/tropical-kitchen-room.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 346,
  'post_date' => '2021-02-13 13:20:23',
  'post_date_gmt' => '2021-02-13 13:20:23',
  'post_content' => 'Ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit ess. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.',
  'post_title' => 'Bright yellow sofa furniture',
  'post_excerpt' => '',
  'post_name' => 'bright-yellow-sofa-furniture',
  'post_modified' => '2021-02-13 13:20:23',
  'post_modified_gmt' => '2021-02-13 13:20:23',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=346',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Feb, 10 2020',
    'project_client' => 'Brightgaz CO',
    'project_services' => 'Furniture Planning',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"on8k317\\",\\"cols\\":[{\\"element_id\\":\\"h4qs318\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'furniture, interior-design',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/comfort-yellow-sofa.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 344,
  'post_date' => '2021-02-13 13:04:22',
  'post_date_gmt' => '2021-02-13 13:04:22',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias at vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis.

quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus.',
  'post_title' => 'Interiors for industrial room style',
  'post_excerpt' => '',
  'post_name' => 'interiors-for-industrial-room-style',
  'post_modified' => '2021-02-13 13:04:22',
  'post_modified_gmt' => '2021-02-13 13:04:22',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=344',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Feb, 09 2021',
    'project_client' => 'Chochoa Co',
    'project_services' => 'Interior Design',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"atnz118\\",\\"cols\\":[{\\"element_id\\":\\"prb1119\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'furniture, interior-design',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/interior-for-industrial.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 342,
  'post_date' => '2021-02-13 13:01:26',
  'post_date_gmt' => '2021-02-13 13:01:26',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.

inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Office stairs design',
  'post_excerpt' => '',
  'post_name' => 'office-stairs-design',
  'post_modified' => '2021-02-13 13:05:25',
  'post_modified_gmt' => '2021-02-13 13:05:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=342',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Feb, 08 2021',
    'project_client' => 'Starways Co',
    'project_services' => 'Layout Planning',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"43uq703\\",\\"cols\\":[{\\"element_id\\":\\"a4df705\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'planning',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/upstair-design.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 340,
  'post_date' => '2021-02-13 12:59:14',
  'post_date_gmt' => '2021-02-13 12:59:14',
  'post_content' => 'Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio.',
  'post_title' => 'Modern wood furniture',
  'post_excerpt' => '',
  'post_name' => 'modern-wood-furniture',
  'post_modified' => '2021-02-13 12:59:14',
  'post_modified_gmt' => '2021-02-13 12:59:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=340',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Feb , 07 2021',
    'project_client' => 'Woodrow Co',
    'project_services' => 'Interior Design',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"hs6g697\\",\\"cols\\":[{\\"element_id\\":\\"x4uf698\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'furniture, interior-design',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/modern-furniture.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 337,
  'post_date' => '2021-02-13 12:57:48',
  'post_date_gmt' => '2021-02-13 12:57:48',
  'post_content' => 'Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus. Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate.

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Perfect industrial style furniture',
  'post_excerpt' => '',
  'post_name' => 'perfect-industrial-style-furniture',
  'post_modified' => '2021-02-13 12:57:48',
  'post_modified_gmt' => '2021-02-13 12:57:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=337',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Feb, 06 2021',
    'project_client' => 'Laverne Rodgers',
    'project_services' => 'Furniture Planning',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"7jqk64\\",\\"cols\\":[{\\"element_id\\":\\"axzb65\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'furniture',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/industrial-design.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 335,
  'post_date' => '2021-02-13 12:56:02',
  'post_date_gmt' => '2021-02-13 12:56:02',
  'post_content' => 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit.recusandae. Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores.',
  'post_title' => 'Retro furniture design',
  'post_excerpt' => '',
  'post_name' => 'retro-furniture-design',
  'post_modified' => '2021-02-13 12:56:02',
  'post_modified_gmt' => '2021-02-13 12:56:02',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=335',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Feb , 04 2021',
    'project_client' => 'Dexter Mckinney',
    'project_services' => 'Furniture Planning',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"24a9730\\",\\"cols\\":[{\\"element_id\\":\\"f11o731\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'furniture, interior-design',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/retro-living-room.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 333,
  'post_date' => '2021-02-13 12:52:47',
  'post_date_gmt' => '2021-02-13 12:52:47',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Modern bathroom design',
  'post_excerpt' => '',
  'post_name' => 'modern-bathroom-design',
  'post_modified' => '2021-02-13 12:52:47',
  'post_modified_gmt' => '2021-02-13 12:52:47',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=333',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Feb, 03 2021',
    'project_client' => 'Carolyn Stone',
    'project_services' => 'Interior Design',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"om2s790\\",\\"cols\\":[{\\"element_id\\":\\"a6ps791\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'interior-design',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/modern-industrial-bathroom.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 331,
  'post_date' => '2021-02-13 12:50:58',
  'post_date_gmt' => '2021-02-13 12:50:58',
  'post_content' => 'Ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit ess. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.',
  'post_title' => 'Meting room interiors',
  'post_excerpt' => '',
  'post_name' => 'meting-room-interiors',
  'post_modified' => '2021-02-13 12:50:58',
  'post_modified_gmt' => '2021-02-13 12:50:58',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=331',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Feb, 02 2021',
    'project_client' => 'Spacer co',
    'project_services' => 'Interior Design',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"0ggw634\\",\\"cols\\":[{\\"element_id\\":\\"m0he635\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'furniture, interior-design, planning',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/meeting-rrom-furniture.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 329,
  'post_date' => '2021-02-13 12:48:57',
  'post_date_gmt' => '2021-02-13 12:48:57',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.

Inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Elegant mansion furniture',
  'post_excerpt' => '',
  'post_name' => 'elegant-mansion-furniture',
  'post_modified' => '2021-02-13 12:48:57',
  'post_modified_gmt' => '2021-02-13 12:48:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=329',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Feb, 01 2021',
    'project_client' => 'Norman Lambert',
    'project_services' => 'Layout Planning',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"t3ig372\\",\\"cols\\":[{\\"element_id\\":\\"8w4x373\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'interior-design, planning',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/elegant-mansion.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 327,
  'post_date' => '2021-02-13 12:46:37',
  'post_date_gmt' => '2021-02-13 12:46:37',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?”  repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis.',
  'post_title' => 'Wood floor panelling',
  'post_excerpt' => '',
  'post_name' => 'wood-floor-panelling',
  'post_modified' => '2021-02-13 12:46:37',
  'post_modified_gmt' => '2021-02-13 12:46:37',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=327',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Jan, 29 2021',
    'project_client' => 'Rhonda Alvarado',
    'project_services' => 'Layout Planning',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"24ld540\\",\\"cols\\":[{\\"element_id\\":\\"mtew540\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'planning',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/floor-panel.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 325,
  'post_date' => '2021-02-13 12:44:11',
  'post_date_gmt' => '2021-02-13 12:44:11',
  'post_content' => 'Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.

Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae.',
  'post_title' => 'Hamptons style furniture for living room',
  'post_excerpt' => '',
  'post_name' => 'hamptons-style-furniture-for-living-room',
  'post_modified' => '2021-02-13 12:44:11',
  'post_modified_gmt' => '2021-02-13 12:44:11',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=325',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'January, 27 2021',
    'project_client' => 'Sharon Hudson',
    'project_services' => 'Furniture Planning',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"7mo0497\\",\\"cols\\":[{\\"element_id\\":\\"37lj499\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'furniture',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/cozy-living-room.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 323,
  'post_date' => '2021-02-13 12:40:54',
  'post_date_gmt' => '2021-02-13 12:40:54',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus. Et quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus omnis.

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Retro dining furniture',
  'post_excerpt' => '',
  'post_name' => 'retro-dining-furniture',
  'post_modified' => '2021-02-13 12:40:54',
  'post_modified_gmt' => '2021-02-13 12:40:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=323',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Aug, 17 2020',
    'project_client' => 'Nicholas Tate',
    'project_services' => 'Furniture Planning',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"ocbp730\\",\\"cols\\":[{\\"element_id\\":\\"7jdv731\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'furniture',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/retro-atmosphere.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 321,
  'post_date' => '2021-02-13 12:39:01',
  'post_date_gmt' => '2021-02-13 12:39:01',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est. Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.

Perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.',
  'post_title' => 'Modern bedroom layout',
  'post_excerpt' => '',
  'post_name' => 'modern-bedroom-layout',
  'post_modified' => '2021-02-13 12:39:06',
  'post_modified_gmt' => '2021-02-13 12:39:06',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=321',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Aug, 18 2020',
    'project_client' => 'Jean Mcbride',
    'project_services' => 'Layout Planning',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"brl7829\\",\\"cols\\":[{\\"element_id\\":\\"ntkw830\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'planning',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/bedroom.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 317,
  'post_date' => '2021-02-13 11:58:26',
  'post_date_gmt' => '2021-02-13 11:58:26',
  'post_content' => 'Ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit ess. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.',
  'post_title' => 'Modern living room interiors',
  'post_excerpt' => '',
  'post_name' => 'modern-living-room-interiors',
  'post_modified' => '2021-02-13 11:58:26',
  'post_modified_gmt' => '2021-02-13 11:58:26',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=317',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Aug, 20 2020',
    'project_client' => 'Stirling Arleen',
    'project_services' => 'Interior Design',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"fx9i472\\",\\"cols\\":[{\\"element_id\\":\\"2p1d473\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'interior-design',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/living-room-design.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 315,
  'post_date' => '2021-02-13 11:47:42',
  'post_date_gmt' => '2021-02-13 11:47:42',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.

inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Contemporary living room chair',
  'post_excerpt' => '',
  'post_name' => 'contemporary-living-room-chair',
  'post_modified' => '2021-02-13 11:48:45',
  'post_modified_gmt' => '2021-02-13 11:48:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=315',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Aug, 29 2020',
    'project_client' => 'Jada Melville',
    'project_services' => 'Design Interior',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"xtpo659\\",\\"cols\\":[{\\"element_id\\":\\"o5ru660\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'interior-design',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/modern-living-room.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 313,
  'post_date' => '2021-02-13 11:39:39',
  'post_date_gmt' => '2021-02-13 11:39:39',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias at vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis.

quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus.',
  'post_title' => 'European dining room interior',
  'post_excerpt' => '',
  'post_name' => 'european-dining-room-interior',
  'post_modified' => '2021-02-13 11:59:14',
  'post_modified_gmt' => '2021-02-13 11:59:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?post_type=portfolio&#038;p=313',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'Sept, 27 2020',
    'project_client' => 'Malcolm Collins',
    'project_services' => 'Interior Design',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"5b76306\\",\\"cols\\":[{\\"element_id\\":\\"fqdw307\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'interior-design',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-interior/files/2021/02/victorian-dining-room.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 139,
  'post_date' => '2021-02-06 14:47:24',
  'post_date_gmt' => '2021-02-06 14:47:24',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '139',
  'post_modified' => '2021-02-18 11:27:16',
  'post_modified_gmt' => '2021-02-18 11:27:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?p=139',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '6',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 140,
  'post_date' => '2021-02-06 14:47:24',
  'post_date_gmt' => '2021-02-06 14:47:24',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '140',
  'post_modified' => '2021-02-18 11:27:16',
  'post_modified_gmt' => '2021-02-18 11:27:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?p=140',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '72',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 364,
  'post_date' => '2021-02-18 11:27:16',
  'post_date_gmt' => '2021-02-18 11:27:16',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '364',
  'post_modified' => '2021-02-18 11:27:16',
  'post_modified_gmt' => '2021-02-18 11:27:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?p=364',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '361',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 238,
  'post_date' => '2021-02-11 08:18:22',
  'post_date_gmt' => '2021-02-11 08:18:22',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '238',
  'post_modified' => '2021-02-18 11:27:16',
  'post_modified_gmt' => '2021-02-18 11:27:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?p=238',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '171',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 272,
  'post_date' => '2021-02-13 03:35:25',
  'post_date_gmt' => '2021-02-13 03:35:25',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '272',
  'post_modified' => '2021-02-18 11:27:16',
  'post_modified_gmt' => '2021-02-18 11:27:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?p=272',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '252',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 141,
  'post_date' => '2021-02-06 14:47:24',
  'post_date_gmt' => '2021-02-06 14:47:24',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '141',
  'post_modified' => '2021-02-18 11:27:16',
  'post_modified_gmt' => '2021-02-18 11:27:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-interior/?p=141',
  'menu_order' => 6,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '114',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_text" );
$widgets[1002] = array (
  'title' => 'Company',
  'text' => '<a href="https://themify.me/">Architectural </a>

<a href="https://themify.me/">Design Interior </a>

<a href="https://themify.me/">Design Lighting </a>

<a href="https://themify.me/">Design AutoCAD Service</a>',
  'filter' => true,
  'visual' => true,
  'tf_search_ajax' => '',
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1003] = array (
  'title' => 'Links',
  'text' => '<a href="https://themify.me/demo/themes/ultra-interior/">Home </a>

<a href="https://themify.me/demo/themes/ultra-interior/">About </a>

<a href="https://themify.me/demo/themes/ultra-interior/">Portfolio </a>

<a href="https://themify.me/demo/themes/ultra-interior/">Blog </a>

<a href="https://themify.me/demo/themes/ultra-interior/">Contact</a>',
  'filter' => true,
  'visual' => true,
  'tf_search_ajax' => '',
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1004] = array (
  'title' => 'Support',
  'text' => '<a href="https://themify.me/">FAQ </a>

<a href="https://themify.me/">Service</a>

<a href="https://themify.me/">Price </a>

<a href="https://themify.me/">Table </a>

<a href="https://themify.me/">Get A Quote</a>',
  'filter' => true,
  'visual' => true,
  'tf_search_ajax' => '',
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_search" );
$widgets[1005] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1006] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1007] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1008] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1009] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1010] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1011] = array (
  'title' => '',
  'text' => '13897 New England Hwy, Cambooya, QLD 4358, Sydney Australia',
  'filter' => true,
  'visual' => true,
  'tf_search_ajax' => '',
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1012] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
  'tf_search_ajax' => '',
);
update_option( "widget_themify-social-links", $widgets );



$sidebars_widgets = array (
  'footer-widget-1' => 
  array (
    0 => 'text-1002',
  ),
  'footer-widget-2' => 
  array (
    0 => 'text-1003',
  ),
  'footer-widget-3' => 
  array (
    0 => 'text-1004',
  ),
  'sidebar-main' => 
  array (
    0 => 'search-1005',
    1 => 'recent-posts-1006',
    2 => 'recent-comments-1007',
  ),
  'sidebar-alt' => 
  array (
    0 => 'archives-1008',
    1 => 'categories-1009',
    2 => 'meta-1010',
  ),
  'footer-social-widget' => 
  array (
    0 => 'text-1011',
    1 => 'themify-social-links-1012',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-webfonts_list' => 'recommended',
  'setting-customizer_responsive_design_tablet_landscape' => '1024',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '480',
  'setting-mobile_menu_trigger_point' => '900',
  'setting-header_design' => 'header-horizontal',
  'setting-exclude_site_tagline' => 'on',
  'setting-exclude_search_form' => 'on',
  'setting_search_form' => 'live_search',
  'setting-header_widgets' => 'none',
  'setting-footer_design' => 'footer-left-col',
  'setting-use_float_back' => 'on',
  'setting-footer_widgets' => 'footerwidget-3col',
  'setting-footer_widget_position' => 'top',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'off',
  'setting-color_animation_speed' => '5',
  'setting-relationship_taxonomy' => 'category',
  'setting-relationship_taxonomy_entries' => '3',
  'setting-relationship_taxonomy_display_content' => 'none',
  'setting-single_slider_autoplay' => 'off',
  'setting-single_slider_speed' => 'normal',
  'setting-single_slider_effect' => 'slide',
  'setting-single_slider_height' => 'auto',
  'setting-more_posts' => 'infinite',
  'setting-entries_nav' => 'numbered',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-lazy-blur' => '25',
  'setting-cache-live' => '10080',
  'setting-webp-quality' => '5',
  'setting-default_layout' => 'sidebar1',
  'setting-default_post_layout' => 'list-post',
  'setting-post_filter' => 'no',
  'setting-disable_masonry' => 'yes',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar1',
  'setting-default_page_post_layout_type' => 'classic',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-search-result_layout_display' => 'excerpt',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar1',
  'setting-default_portfolio_index_layout' => 'sidebar-none',
  'setting-default_portfolio_index_post_layout' => 'grid3',
  'setting-portfolio_post_filter' => 'yes',
  'setting-portfolio_disable_masonry' => 'yes',
  'setting-portfolio_gutter' => 'gutter',
  'setting-default_portfolio_index_display' => 'none',
  'setting-default_portfolio_single_layout' => 'sidebar-none',
  'setting-default_portfolio_single_portfolio_layout_type' => 'fullwidth',
  'setting-default_portfolio_single_image_post_width' => '1400',
  'setting-default_portfolio_single_image_post_height' => '600',
  'themify_portfolio_slug' => 'project',
  'themify_portfolio_category_slug' => 'portfolio-category',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/ultra-interior/wp-content/themes/themify-ultra/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/ultra-interior/wp-content/themes/themify-ultra/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'YouTube',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/ultra-interior/wp-content/themes/themify-ultra/themify/img/social/youtube.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'Pinterest',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/ultra-interior/wp-content/themes/themify-ultra/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Facebook',
  'setting-link_link_themify-link-5' => 'https://www.facebook.com/themify',
  'setting-link_ficon_themify-link-5' => 'ti-facebook',
  'setting-link_type_themify-link-4' => 'font-icon',
  'setting-link_title_themify-link-4' => 'Twitter',
  'setting-link_link_themify-link-4' => 'https://twitter.com/themify',
  'setting-link_ficon_themify-link-4' => 'ti-twitter-alt',
  'setting-link_type_themify-link-8' => 'font-icon',
  'setting-link_link_themify-link-8' => 'https://www.linkedin.com/company/themify/',
  'setting-link_ficon_themify-link-8' => 'ti-linkedin',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'YouTube',
  'setting-link_link_themify-link-6' => 'https://www.youtube.com/user/themifyme',
  'setting-link_ficon_themify-link-6' => 'ti-youtube',
  'setting-link_type_themify-link-7' => 'font-icon',
  'setting-link_title_themify-link-7' => 'Pinterest',
  'setting-link_ficon_themify-link-7' => 'fa-pinterest',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-5":"themify-link-5","themify-link-4":"themify-link-4","themify-link-8":"themify-link-8","themify-link-6":"themify-link-6","themify-link-7":"themify-link-7"}',
  'setting-link_field_hash' => '9',
  'setting-twitter_settings_cache' => '10',
  'setting-recaptcha_version' => 'v2',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_gallery_lightbox' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'skin' => 'interior',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'custom_css_post_id' => -1,
  'body_background' => '{"id":151,"src":"https://themify.me/demo/themes/ultra-interior/files/2021/02/body-bg-lines-1.png","style":"repeat","color":"","opacity":1,"position":"center center"}',
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
