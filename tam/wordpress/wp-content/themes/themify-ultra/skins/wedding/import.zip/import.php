<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 70,
  'name' => 'Wedding Page Menu',
  'slug' => 'wedding-page-menu',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 7,
  'post_date' => '2016-08-31 02:42:34',
  'post_date_gmt' => '2016-08-31 02:42:34',
  'post_content' => '<!--themify_builder_static--><h1>Amelia &amp; Steve</h1>
<h4>are getting married</h4>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding/files/2016/08/ring-22x15.png" width="22" height="15" title="ring" alt="ring">
<h4>Friday, October 21, 2017</h4>
<h2>Our Story</h2> <h3>One night on a hot summer day in Toronto, I randomly stumbled upon a street where I met the most important person in my life. Here is how our story goes…</h3> <p>Duis bibendum, ex ac rutrum pharetra, tortor ipsum commodo est, et vehicula metus lectus sed metus. Pellentesque. Vestibulum consectetur risus id metus lacinia suscipit. Nunc tempus sem id mi tristique, et fringilla Lorem ipsum dolor sit amet, consectetur.</p>
<ul> <li id="timeline-0"> July 2014 <i><svg><use href="#tf-far-heart-o"></use></svg></i> <h2> How We Met </h2> <p>Ego Vero Volo In Virtute Vim Esse Quam Maximam; Inde Igitur, Inquit, Ordiendum Est. Ne Amores Quidem Sanctos A Sapiente Alienos Esse Arbitrantur. Non Quam Nostram Quidem, Inquit Pomponius Iocans; De Vacuitate Doloris Eadem Sententia Erit.</p> </li> <li id="timeline-1"> Jan 2015 <i><svg><use href="#tf-far-heart-o"></use></svg></i> <h2> The First Date </h2> <figure> <img loading="lazy" width="660" height="334" src="https://themify.me/demo/themes/ultra-wedding/files/2016/09/first-date-image.jpg" alt="The First Date" srcset="https://themify.me/demo/themes/ultra-wedding/files/2016/09/first-date-image.jpg 660w, https://themify.me/demo/themes/ultra-wedding/files/2016/09/first-date-image-300x152.jpg 300w" sizes="(max-width: 660px) 100vw, 660px" /> </figure> <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit.</p> </li> <li id="timeline-2"> Sept 2016 <i><svg><use href="#tf-far-heart-o"></use></svg></i> <h2> We Are Enganged </h2> <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.</p> </li> <li id="timeline-3"> Oct 2017 <i><svg><use href="#tf-far-heart-o"></use></svg></i> <h2> Getting Married </h2> <p>Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.</p> </li> <li id="timeline-4"> <i><svg><use href="#tf-far-circle-thin"></use></svg></i> </li> </ul>
<h2>Ceremony &amp; Reception</h2>
<i style="color: #ffffff"><svg><use href="#tf-far-calendar-minus-o"></use></svg></i> <h3> FRIDAY, OCTOBER 21, 2017 </h3> <p>2:30 PM - 5:30 PM</p>
<i style="color: #ffffff"><svg><use href="#tf-far-map-marker"></use></svg></i> <h3> Marina Village Mojo Room </h3> <p>1936 Quivira Way - San Diego, California 92109</p>
<h2>Wedding Countdown</h2>
Years Days Hours Minutes Seconds
<h2>Gallery</h2>
<a href="https://themify.me/demo/themes/ultra-wedding/files/2016/09/weddings-632734_1920.jpg" > <svg><use href="#tf-ti-image"></use></svg> <img src="https://themify.me/demo/themes/ultra-wedding/files/2016/09/weddings-632734_1920-1024x516-476x353-476x353-476x353.jpg" width="476" height="353" alt="Wedding Dress"> </a>
<a href="https://themify.me/demo/themes/ultra-wedding/files/2016/09/heart-529607_1920.jpg" > <svg><use href="#tf-ti-image"></use></svg> <img src="https://themify.me/demo/themes/ultra-wedding/files/2016/09/heart-529607_1920-1024x681-476x353-476x353-476x353.jpg" width="476" height="353" alt="Love"> </a>
<a href="https://themify.me/demo/themes/ultra-wedding/files/2016/08/wedding-dresses-1486004_1920.jpg" > <svg><use href="#tf-ti-image"></use></svg> <img src="https://themify.me/demo/themes/ultra-wedding/files/2016/08/wedding-dresses-1486004_1920-1024x682-951x353-951x353-951x353.jpg" width="951" height="353" alt="Pre Wedding "> </a>
<a href="https://themify.me/demo/themes/ultra-wedding/files/2016/08/marriage-918864_1920.jpg" > <svg><use href="#tf-ti-image"></use></svg> <img src="https://themify.me/demo/themes/ultra-wedding/files/2016/08/marriage-918864_1920-1024x682-951x353-951x353-951x353.jpg" width="951" height="353" alt="The Party"> </a>
<a href="https://themify.me/demo/themes/ultra-wedding/files/2016/08/bride-997604_1920.jpg" > <svg><use href="#tf-ti-image"></use></svg> <img src="https://themify.me/demo/themes/ultra-wedding/files/2016/08/bride-997604_1920-1024x683-476x353-476x353-476x353.jpg" width="476" height="353" alt="Hair Make Up"> </a>
<a href="https://themify.me/demo/themes/ultra-wedding/files/2016/09/wedding-997605_1920.jpg" > <svg><use href="#tf-ti-image"></use></svg> <img src="https://themify.me/demo/themes/ultra-wedding/files/2016/09/wedding-997605_1920-1024x683-476x353-476x353-476x353.jpg" width="476" height="353" alt="Together"> </a>
<h2>Are You Attending</h2><h3>Please RSVP before September 25</h3>
<form action="https://themify.me/demo/themes/ultra-wedding/wp-admin/admin-ajax.php" class="builder-contact" id="tb_2e885eb-form" method="post" data-post-id="0" data-element-id="2e885eb" > <label for="tb_2e885eb-contact-name">Name </label> <input type="text" name="contact-name" placeholder="" id="tb_2e885eb-contact-name" value="" /> <label for="tb_2e885eb-contact-email">Email </label> <input type="text" name="contact-email" placeholder="" id="tb_2e885eb-contact-email" value="" /> <label for="tb_2e885eb-contact-message">Message *</label> <textarea name="contact-message" placeholder="" id="tb_2e885eb-contact-message" rows="8" cols="45" required></textarea> <label> <input type="checkbox" name="contact-sendcopy" id="tb_2e885eb-sendcopy" value="1" /> Send Copy </label> <button type="submit"> Send</button> </form>
Spring valley, San Diego, CA<!--/themify_builder_static-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2020-10-03 01:55:50',
  'post_modified_gmt' => '2020-10-03 01:55:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding/?page_id=7',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'display_content' => 'content',
    'body_background_repeat' => 'fullcover',
    'mobile_menu_styles' => 'default',
    'header_wrap' => 'transparent',
    'background_repeat' => 'fullcover',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"e46977f\\",\\"cols\\":[{\\"element_id\\":\\"f90bd1a\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"0d0caef\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Amelia &amp; Steve<\\\\/h1>\\",\\"font_size\\":\\"1.3\\",\\"font_size_unit\\":\\"em\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"1f2ab7e\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>are getting married<\\\\/h4>\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"03b2319\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/08\\\\/ring.png\\",\\"width_image\\":\\"22\\",\\"height_image\\":\\"15\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"841320b\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Friday, October 21, 2017<\\\\/h4>\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}]}],\\"styling\\":{\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/08\\\\/wedding-bg-top-1024x744.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color\\":\\"000000_0.39\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"font_color\\":\\"ffffff_1.00\\",\\"text_align\\":\\"center\\",\\"padding_top\\":\\"22\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"29\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}},{\\"element_id\\":\\"dd1357a\\",\\"cols\\":[{\\"element_id\\":\\"c0c5d17\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"4c136bd\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"text_align\\":\\"center\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"6\\",\\"padding_right_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_left\\":\\"6\\",\\"padding_left_unit\\":\\"%\\",\\"margin_bottom\\":\\"50\\",\\"border_top_color\\":\\"fdf5f4\\",\\"border_top_width\\":\\"5\\",\\"border_right_color\\":\\"fdf5f4\\",\\"border_right_width\\":\\"5\\",\\"border_bottom_color\\":\\"fdf5f4\\",\\"border_bottom_width\\":\\"5\\",\\"border_left_color\\":\\"fdf5f4\\",\\"border_left_width\\":\\"5\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"content_text\\":\\"<h2>Our Story<\\\\/h2>\\\\n<h3>One night on a hot summer day in Toronto, I randomly stumbled upon a street where I met the most important person in my life. Here is how our story goes…<\\\\/h3>\\\\n<p>Duis bibendum, ex ac rutrum pharetra, tortor ipsum commodo est, et vehicula metus lectus sed metus. Pellentesque. Vestibulum consectetur risus id metus lacinia suscipit. Nunc tempus sem id mi tristique, et fringilla Lorem ipsum dolor sit amet, consectetur.<\\\\/p>\\\\n\\"}}]}],\\"styling\\":{\\"custom_css_row\\":\\"our-story-section\\",\\"row_anchor\\":\\"story\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"8\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"14\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}},{\\"element_id\\":\\"588ce6b\\",\\"cols\\":[{\\"element_id\\":\\"500b694\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"timeline\\",\\"element_id\\":\\"1a0ae49\\",\\"mod_settings\\":{\\"template_timeline\\":\\"list\\",\\"source_timeline\\":\\"text\\",\\"category_post_timeline\\":\\"0|single\\",\\"order_post_timeline\\":\\"desc\\",\\"orderby_post_timeline\\":\\"date\\",\\"display_post_timeline\\":\\"excerpt\\",\\"hide_feat_img_post_timeline\\":\\"no\\",\\"text_source_timeline\\":[{\\"title_timeline\\":\\"How We Met\\",\\"icon_timeline\\":\\"fa-heart-o\\",\\"date_timeline\\":\\"July 2014\\",\\"content_timeline\\":\\"<p>Ego Vero Volo In Virtute Vim Esse Quam Maximam; Inde Igitur, Inquit, Ordiendum Est. Ne Amores Quidem Sanctos A Sapiente Alienos Esse Arbitrantur. Non Quam Nostram Quidem, Inquit Pomponius Iocans; De Vacuitate Doloris Eadem Sententia Erit.<\\\\/p>\\"},{\\"title_timeline\\":\\"The First Date\\",\\"icon_timeline\\":\\"fa-heart-o\\",\\"date_timeline\\":\\"Jan 2015\\",\\"image_timeline\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/09\\\\/first-date-image.jpg\\",\\"content_timeline\\":\\"<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit.<\\\\/p>\\"},{\\"title_timeline\\":\\"We Are Enganged\\",\\"icon_timeline\\":\\"fa-heart-o\\",\\"date_timeline\\":\\"Sept 2016\\",\\"content_timeline\\":\\"<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.<\\\\/p>\\"},{\\"title_timeline\\":\\"Getting Married\\",\\"icon_timeline\\":\\"fa-heart-o\\",\\"date_timeline\\":\\"Oct 2017\\",\\"content_timeline\\":\\"<p>Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.<\\\\/p>\\"},{\\"icon_timeline\\":\\"fa-circle-thin\\"}],\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}]}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_bottom\\":\\"7\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}},{\\"element_id\\":\\"97e0983\\",\\"cols\\":[{\\"element_id\\":\\"9bc46f5\\",\\"grid_class\\":\\"col4-2\\",\\"styling\\":{\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/08\\\\/ring-1932-1024x682.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"31ca331\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"c9983e5\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Ceremony &amp; Reception<\\\\/h2>\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"8b05301\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"title_feature\\":\\"FRIDAY, OCTOBER 21, 2017\\",\\"content_feature\\":\\"<p>2:30 PM - 5:30 PM<\\\\/p>\\",\\"layout_feature\\":\\"icon-top\\",\\"circle_stroke_feature\\":\\"0\\",\\"circle_color_feature\\":\\"#de5d5d\\",\\"circle_size_feature\\":\\"medium\\",\\"icon_type_feature\\":\\"icon\\",\\"icon_feature\\":\\"fa-calendar-minus-o\\",\\"icon_color_feature\\":\\"ffffff\\",\\"link_options\\":\\"regular\\",\\"circle_percentage_feature\\":\\"0\\"}},{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"48834d1\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"title_feature\\":\\"Marina Village Mojo Room\\",\\"content_feature\\":\\"<p>1936 Quivira Way - San Diego, California 92109<\\\\/p>\\",\\"layout_feature\\":\\"icon-top\\",\\"circle_stroke_feature\\":\\"0\\",\\"circle_color_feature\\":\\"#de5d5d\\",\\"circle_size_feature\\":\\"medium\\",\\"icon_type_feature\\":\\"icon\\",\\"icon_feature\\":\\"fa-map-marker\\",\\"icon_color_feature\\":\\"ffffff\\",\\"link_options\\":\\"regular\\",\\"circle_percentage_feature\\":\\"0\\"}}],\\"styling\\":{\\"background_color\\":\\"ff887b\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"text_align\\":\\"center\\",\\"padding_top\\":\\"60\\",\\"padding_bottom\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"checkbox_border_apply_all\\":\\"border\\"}}}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"custom_css_row\\":\\"ceremony-section\\",\\"row_anchor\\":\\"ceremony\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"font_color\\":\\"ffffff_1.00\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"7acf3d7\\",\\"cols\\":[{\\"element_id\\":\\"32a1893\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"2f93f27\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Wedding Countdown<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_bottom\\":\\"50\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"countdown\\",\\"element_id\\":\\"a277bea\\",\\"mod_settings\\":{\\"font_color_type\\":\\"font_color_solid\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border-type\\":\\"top\\",\\"mod_date_countdown\\":\\"2022-01-25 13:30:50\\",\\"color_countdown\\":\\"transparent\\",\\"done_action_countdown\\":\\"nothing\\",\\"label_years\\":\\"Years\\",\\"label_days\\":\\"Days\\",\\"label_hours\\":\\"Hours\\",\\"label_minutes\\":\\"Minutes\\",\\"label_seconds\\":\\"Seconds\\"}}]}],\\"styling\\":{\\"background_color\\":\\"fdf5f4\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"6\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"12\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}},{\\"element_id\\":\\"b565006\\",\\"cols\\":[{\\"element_id\\":\\"3398627\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"a6eb522\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Gallery<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_bottom\\":\\"50\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"element_id\\":\\"c093895\\",\\"cols\\":[{\\"element_id\\":\\"4808559\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"b5b14bc\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/09\\\\/weddings-632734_1920-1024x516-476x353-476x353.jpg\\",\\"width_image\\":\\"476\\",\\"auto_fullwidth\\":\\"1\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/09\\\\/weddings-632734_1920.jpg\\",\\"param_image\\":\\"lightbox\\",\\"image_zoom_icon\\":\\"zoom\\",\\"alt_image\\":\\"Wedding Dress\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"6ec3e7f\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"73a60f6\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/09\\\\/heart-529607_1920-1024x681-476x353-476x353.jpg\\",\\"width_image\\":\\"476\\",\\"auto_fullwidth\\":\\"1\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/09\\\\/heart-529607_1920.jpg\\",\\"param_image\\":\\"lightbox\\",\\"image_zoom_icon\\":\\"zoom\\",\\"alt_image\\":\\"Love\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"border_top_style\\":\\"none\\",\\"border_right_style\\":\\"none\\",\\"border_bottom_style\\":\\"none\\",\\"border_left_style\\":\\"none\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"4fa4936\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"281da56\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/08\\\\/wedding-dresses-1486004_1920-1024x682-951x353-951x353.jpg\\",\\"width_image\\":\\"951\\",\\"auto_fullwidth\\":\\"1\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/08\\\\/wedding-dresses-1486004_1920.jpg\\",\\"param_image\\":\\"lightbox\\",\\"image_zoom_icon\\":\\"zoom\\",\\"alt_image\\":\\"Pre Wedding \\",\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]}],\\"gutter\\":\\"gutter-none\\"},{\\"element_id\\":\\"728f932\\",\\"cols\\":[{\\"element_id\\":\\"58d1e51\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ad56f08\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/08\\\\/marriage-918864_1920-1024x682-951x353-951x353.jpg\\",\\"width_image\\":\\"951\\",\\"auto_fullwidth\\":\\"1\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/08\\\\/marriage-918864_1920.jpg\\",\\"param_image\\":\\"lightbox\\",\\"image_zoom_icon\\":\\"zoom\\",\\"alt_image\\":\\"The Party\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"ff9a8be\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"2e36563\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/08\\\\/bride-997604_1920-1024x683-476x353-476x353.jpg\\",\\"width_image\\":\\"476\\",\\"auto_fullwidth\\":\\"1\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/08\\\\/bride-997604_1920.jpg\\",\\"param_image\\":\\"lightbox\\",\\"image_zoom_icon\\":\\"zoom\\",\\"alt_image\\":\\"Hair Make Up\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"e92c297\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"011139b\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/09\\\\/wedding-997605_1920-1024x683-476x353-476x353.jpg\\",\\"width_image\\":\\"476\\",\\"auto_fullwidth\\":\\"1\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/09\\\\/wedding-997605_1920.jpg\\",\\"param_image\\":\\"lightbox\\",\\"image_zoom_icon\\":\\"zoom\\",\\"alt_image\\":\\"Together\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]}],\\"gutter\\":\\"gutter-none\\"}]}],\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"row_anchor\\":\\"gallery\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}},{\\"element_id\\":\\"e788fd6\\",\\"cols\\":[{\\"element_id\\":\\"be417cd\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"8673ab5\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Are You Attending<\\\\/h2><h3>Please RSVP before September 25<\\\\/h3>\\",\\"font_color\\":\\"ffffff_1.00\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_bottom\\":\\"50\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"element_id\\":\\"c9d6f5d\\",\\"cols\\":[{\\"element_id\\":\\"8e05067\\",\\"grid_class\\":\\"col4-1\\",\\"grid_width\\":18.9902000000000015234036254696547985076904296875},{\\"element_id\\":\\"66548eb\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"2e885eb\\",\\"mod_settings\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"checkbox_border_inputs_apply_all\\":\\"1\\",\\"checkbox_border_send_apply_all\\":\\"1\\",\\"checkbox_padding_success_message_apply_all\\":\\"1\\",\\"checkbox_margin_success_message_apply_all\\":\\"1\\",\\"checkbox_border_success_message_apply_all\\":\\"1\\",\\"checkbox_padding_error_message_apply_all\\":\\"1\\",\\"checkbox_margin_error_message_apply_all\\":\\"1\\",\\"checkbox_border_error_message_apply_all\\":\\"1\\",\\"layout_contact\\":\\"style2\\",\\"post_type\\":\\"enable\\",\\"field_sendcopy_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_email_active\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_captcha_active\\":false,\\"field_subject_active\\":false,\\"field_subject_require\\":false,\\"field_email_require\\":false,\\"field_name_require\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"send_to_admins\\":\\"true\\",\\"field_optin_active\\":false,\\"provider\\":\\"mailchimp\\",\\"user_role\\":\\"admin\\"}}],\\"grid_width\\":55.78580000000000183035808731801807880401611328125},{\\"element_id\\":\\"2c4a324\\",\\"grid_class\\":\\"col4-1\\",\\"grid_width\\":18.825500000000001676880856393836438655853271484375}]}]}],\\"styling\\":{\\"row_anchor\\":\\"reservation\\",\\"background_color\\":\\"443432\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"font_color\\":\\"ffffff_1.00\\",\\"link_color\\":\\"fcffcc_1.00\\",\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"6\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"12\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}},{\\"element_id\\":\\"5b6c190\\",\\"cols\\":[{\\"element_id\\":\\"75fa94f\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"maps-pro\\",\\"element_id\\":\\"386eabe\\",\\"mod_settings\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border-type\\":\\"top\\",\\"map_display_type\\":\\"dynamic\\",\\"w_map\\":\\"100\\",\\"w_map_unit\\":\\"%\\",\\"w_map_static\\":\\"500\\",\\"h_map\\":\\"600\\",\\"type_map\\":\\"ROADMAP\\",\\"style_map\\":\\"routexl\\",\\"scrollwheel_map\\":\\"disable\\",\\"draggable_map\\":\\"enable\\",\\"disable_map_ui\\":\\"no\\",\\"zoom_map\\":\\"17\\",\\"map_polyline\\":\\"no\\",\\"map_polyline_geodesic\\":\\"no\\",\\"map_center\\":\\"Spring valley, San Diego, CA\\",\\"markers\\":[{\\"address\\":\\"Spring valley, San Diego, CA\\",\\"latlng\\":\\"32.744774,-116.99891600000001\\",\\"title\\":\\"Spring valley, San Diego, CA\\",\\"image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding\\\\/files\\\\/2016\\\\/08\\\\/wedding-icon.png\\"}],\\"map_polyline_stroke\\":\\"2\\",\\"map_polyline_color\\":\\"#ff0000_1\\"}}]}],\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 5884,
  'post_date' => '2016-09-20 05:06:10',
  'post_date_gmt' => '2016-09-20 05:06:10',
  'post_content' => '',
  'post_title' => 'Our Story',
  'post_excerpt' => '',
  'post_name' => 'bride-groom',
  'post_modified' => '2016-09-21 00:58:20',
  'post_modified_gmt' => '2016-09-21 00:58:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding/2016/09/20/bride-groom/',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '5884',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => '#story',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'wedding-page-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 5885,
  'post_date' => '2016-09-20 05:06:10',
  'post_date_gmt' => '2016-09-20 05:06:10',
  'post_content' => '',
  'post_title' => 'When/Where',
  'post_excerpt' => '',
  'post_name' => 'wedding-party',
  'post_modified' => '2016-09-21 00:58:20',
  'post_modified_gmt' => '2016-09-21 00:58:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding/2016/09/20/wedding-party/',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '5885',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => '#ceremony',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'wedding-page-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 5886,
  'post_date' => '2016-09-20 05:06:10',
  'post_date_gmt' => '2016-09-20 05:06:10',
  'post_content' => '',
  'post_title' => 'Photo Gallery',
  'post_excerpt' => '',
  'post_name' => 'when-where',
  'post_modified' => '2016-09-21 00:58:20',
  'post_modified_gmt' => '2016-09-21 00:58:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding/2016/09/20/when-where/',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '5886',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => '#gallery',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'wedding-page-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 5887,
  'post_date' => '2016-09-20 05:06:10',
  'post_date_gmt' => '2016-09-20 05:06:10',
  'post_content' => '',
  'post_title' => 'RSVP',
  'post_excerpt' => '',
  'post_name' => 'rsvp-2',
  'post_modified' => '2016-09-21 00:58:20',
  'post_modified_gmt' => '2016-09-21 00:58:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding/2016/09/20/rsvp-2/',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '5887',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => 'highlight-link',
    ),
    '_menu_item_url' => '#reservation',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'wedding-page-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_text" );
$widgets[1002] = array (
  'title' => '',
  'text' => '',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1003] = array (
  'title' => 'About',
  'text' => 'The Ultra theme is Themify\'s flagship theme. It\'s a WordPress designed to give you more control on the design of your theme. Built to work seamlessly with our drag & drop Builder plugin, it gives you the ability to customize the look and feel of your content. ',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1004] = array (
  'title' => 'Address',
  'text' => '25 Ohio St. Cleveland. MA<br/>
(912) 555-8900<br/>
<a href="https://themify.me/">themify.me</a>',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1005] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-large',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1006] = array (
  'title' => 'Hours',
  'text' => 'MON - FRI 9AM -11PM<br/>
SAT - SUN 5PM - 2AM<br/>
Bar open only on weekends',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1007] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1008] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );

$widgets = get_option( "widget_search" );
$widgets[1009] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1010] = array (
  'title' => 'Widget 1',
  'text' => 'Optional widget here',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1011] = array (
  'title' => 'Widget 2',
  'text' => 'Display any widget here',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1012] = array (
  'title' => 'Widget 3',
  'text' => 'For example, phone #: 123-333-4567',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1013] = array (
  'title' => 'About',
  'text' => 'The Ultra theme is Themify\'s flagship theme. It\'s a WordPress designed to give you more control on the design of your theme. Built to work seamlessly with our drag & drop Builder plugin, it gives you the ability to customize the look and feel of your content. ',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1014] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1015] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1016] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_themify-feature-posts" );
$widgets[1017] = array (
  'title' => 'Recent Posts',
  'category' => '0',
  'show_count' => '3',
  'show_date' => 'on',
  'show_thumb' => 'on',
  'display' => 'none',
  'hide_title' => NULL,
  'thumb_width' => '50',
  'thumb_height' => '50',
  'excerpt_length' => '55',
  'orderby' => 'date',
  'order' => 'DESC',
);
update_option( "widget_themify-feature-posts", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1018] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1019] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1020] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1021] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_themify-twitter" );
$widgets[1022] = array (
  'title' => 'Latest Tweets',
  'username' => 'themify',
  'show_count' => '3',
  'hide_timestamp' => NULL,
  'show_follow' => 'on',
  'follow_text' => '→ Follow me',
  'include_retweets' => 'on',
  'exclude_replies' => NULL,
);
update_option( "widget_themify-twitter", $widgets );

$widgets = get_option( "widget_themify-twitter" );
$widgets[1023] = array (
  'title' => 'Latest Tweets',
  'username' => 'themify',
  'show_count' => '2',
  'hide_timestamp' => NULL,
  'show_follow' => NULL,
  'follow_text' => '→ Follow me',
  'include_retweets' => NULL,
  'exclude_replies' => NULL,
);
update_option( "widget_themify-twitter", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1024] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1025] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );

$widgets = get_option( "widget_search" );
$widgets[1026] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1027] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1028] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1029] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_themify-feature-posts" );
$widgets[1030] = array (
  'title' => 'Recent Posts',
  'category' => '0',
  'show_count' => '3',
  'show_date' => 'on',
  'show_thumb' => 'on',
  'display' => 'none',
  'hide_title' => NULL,
  'thumb_width' => '50',
  'thumb_height' => '50',
  'excerpt_length' => '55',
  'orderby' => 'date',
  'order' => 'DESC',
);
update_option( "widget_themify-feature-posts", $widgets );

$widgets = get_option( "widget_themify-feature-posts" );
$widgets[1031] = array (
  'title' => 'Recent Posts',
  'category' => '0',
  'show_count' => '2',
  'show_date' => 'on',
  'show_thumb' => 'on',
  'display' => 'none',
  'hide_title' => NULL,
  'thumb_width' => '50',
  'thumb_height' => '50',
  'excerpt_length' => '55',
  'orderby' => 'date',
  'order' => 'DESC',
);
update_option( "widget_themify-feature-posts", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1032] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1033] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1034] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-large',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_themify-twitter" );
$widgets[1035] = array (
  'title' => 'Latest Tweets',
  'username' => 'themify',
  'show_count' => '3',
  'hide_timestamp' => NULL,
  'show_follow' => 'on',
  'follow_text' => '→ Follow me',
  'include_retweets' => 'on',
  'exclude_replies' => NULL,
);
update_option( "widget_themify-twitter", $widgets );

$widgets = get_option( "widget_themify-twitter" );
$widgets[1036] = array (
  'title' => 'Latest Tweets',
  'username' => 'themify',
  'show_count' => '2',
  'hide_timestamp' => NULL,
  'show_follow' => NULL,
  'follow_text' => '→ Follow me',
  'include_retweets' => NULL,
  'exclude_replies' => NULL,
);
update_option( "widget_themify-twitter", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1037] = array (
  'title' => 'Widget 1',
  'text' => 'Optional widget here',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1038] = array (
  'title' => 'Widget 2',
  'text' => 'Display any widget here',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1039] = array (
  'title' => 'Widget 3',
  'text' => 'For example, phone #: 123-333-4567',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1040] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1041] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );

$widgets = get_option( "widget_search" );
$widgets[1042] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1043] = array (
  'title' => 'Widget 1',
  'text' => 'Optional widget here',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1044] = array (
  'title' => 'Widget 2',
  'text' => 'Optional widget here',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1045] = array (
  'title' => 'Widget 3',
  'text' => 'Optional widget here',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1046] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1047] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1048] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1049] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );



$sidebars_widgets = array (
  'orphaned_widgets_1' => 
  array (
    0 => 'text-1002',
  ),
  'orphaned_widgets_5' => 
  array (
    0 => 'text-1003',
  ),
  'footer-widget-1' => 
  array (
    0 => 'text-1004',
  ),
  'footer-widget-2' => 
  array (
    0 => 'themify-social-links-1005',
  ),
  'footer-widget-3' => 
  array (
    0 => 'text-1006',
  ),
  'wp_inactive_widgets' => 
  array (
    0 => 'archives-1007',
    1 => 'meta-1008',
    2 => 'search-1009',
    3 => 'text-1010',
    4 => 'text-1011',
    5 => 'text-1012',
    6 => 'text-1013',
    7 => 'categories-1014',
    8 => 'recent-posts-1015',
    9 => 'recent-comments-1016',
    10 => 'themify-feature-posts-1017',
    11 => 'themify-social-links-1018',
    12 => 'themify-social-links-1019',
    13 => 'themify-social-links-1020',
    14 => 'themify-social-links-1021',
    15 => 'themify-twitter-1022',
    16 => 'themify-twitter-1023',
    17 => 'archives-1024',
    18 => 'meta-1025',
    19 => 'search-1026',
    20 => 'categories-1027',
    21 => 'recent-posts-1028',
    22 => 'recent-comments-1029',
    23 => 'themify-feature-posts-1030',
    24 => 'themify-feature-posts-1031',
    25 => 'themify-social-links-1032',
    26 => 'themify-social-links-1033',
    27 => 'themify-social-links-1034',
    28 => 'themify-twitter-1035',
    29 => 'themify-twitter-1036',
    30 => 'text-1037',
    31 => 'text-1038',
    32 => 'text-1039',
    33 => 'archives-1040',
    34 => 'meta-1041',
    35 => 'search-1042',
    36 => 'text-1043',
    37 => 'text-1044',
    38 => 'text-1045',
    39 => 'categories-1046',
    40 => 'recent-posts-1047',
    41 => 'recent-comments-1048',
  ),
  'footer-social-widget' => 
  array (
    0 => 'themify-social-links-1049',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-webfonts_list' => 'recommended',
  'setting-lazy-blur' => '25',
  'setting-cache-live' => '10080',
  'setting-default_layout' => 'sidebar-none',
  'setting-default_post_layout' => 'list-post',
  'setting-post_filter' => 'yes',
  'setting-disable_masonry' => 'yes',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_post_meta_author' => 'yes',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar1',
  'setting-default_page_post_layout_type' => 'classic',
  'setting-default_page_post_meta' => 'no',
  'setting-default_page_post_meta_author' => 'yes',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-search-result_layout' => 'sidebar-none',
  'setting-search-result_post_layout' => 'list-thumb-image',
  'setting-search-result_layout_display' => 'excerpt',
  'setting-search-result_post_meta' => 'yes',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar1',
  'setting-default_portfolio_index_layout' => 'sidebar-none',
  'setting-default_portfolio_index_post_layout' => 'grid3',
  'setting-portfolio_post_filter' => 'yes',
  'setting-portfolio_disable_masonry' => 'yes',
  'setting-portfolio_gutter' => 'gutter',
  'setting-default_portfolio_index_display' => 'none',
  'setting-default_portfolio_index_post_meta_category' => 'yes',
  'setting-default_portfolio_index_unlink_post_image' => 'yes',
  'setting-default_portfolio_single_layout' => 'sidebar-none',
  'setting-default_portfolio_single_portfolio_layout_type' => 'fullwidth',
  'setting-default_portfolio_single_unlink_post_image' => 'yes',
  'themify_portfolio_slug' => 'project',
  'themify_portfolio_category_slug' => 'portfolio-category',
  'setting-customizer_responsive_design_tablet_landscape' => '1024',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '480',
  'setting-mobile_menu_trigger_point' => '1200',
  'setting-header_design' => 'header-menu-split',
  'setting-exclude_site_tagline' => 'on',
  'setting-exclude_search_form' => 'on',
  'setting_search_form' => 'live_search',
  'setting-exclude_header_widgets' => 'on',
  'setting-exclude_social_widget' => 'on',
  'setting-header_widgets' => 'none',
  'setting-footer_design' => 'footer-block',
  'setting-exclude_footer_menu_navigation' => 'on',
  'setting-use_float_back' => 'on',
  'setting-footer_widgets' => 'none',
  'setting-footer_widget_position' => 'top',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'off',
  'setting-color_animation_speed' => '5',
  'setting-relationship_taxonomy' => 'category',
  'setting-relationship_taxonomy_entries' => '3',
  'setting-relationship_taxonomy_display_content' => 'none',
  'setting-single_slider_autoplay' => 'off',
  'setting-single_slider_speed' => 'normal',
  'setting-single_slider_effect' => 'slide',
  'setting-single_slider_height' => 'auto',
  'setting-more_posts' => 'infinite',
  'setting-entries_nav' => 'numbered',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/ultra-restaurant/wp-content/themes/themify-ultra/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/ultra-restaurant/wp-content/themes/themify-ultra/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'Google+',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/ultra-restaurant/wp-content/themes/themify-ultra/themify/img/social/google-plus.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'YouTube',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/ultra-restaurant/wp-content/themes/themify-ultra/themify/img/social/youtube.png',
  'setting-link_type_themify-link-4' => 'image-icon',
  'setting-link_title_themify-link-4' => 'Pinterest',
  'setting-link_img_themify-link-4' => 'https://themify.me/demo/themes/ultra-restaurant/wp-content/themes/themify-ultra/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-8' => 'font-icon',
  'setting-link_title_themify-link-8' => 'YouTube',
  'setting-link_link_themify-link-8' => 'https://themify.me/',
  'setting-link_ficon_themify-link-8' => 'fa-youtube',
  'setting-link_type_themify-link-10' => 'font-icon',
  'setting-link_title_themify-link-10' => 'Instagram',
  'setting-link_link_themify-link-10' => 'https://themify.me/',
  'setting-link_ficon_themify-link-10' => 'fa-instagram',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Twitter',
  'setting-link_link_themify-link-5' => 'https://themify.me/',
  'setting-link_ficon_themify-link-5' => 'fa-twitter',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'Facebook',
  'setting-link_link_themify-link-6' => 'https://themify.me/',
  'setting-link_ficon_themify-link-6' => 'fa-facebook',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4","themify-link-8":"themify-link-8","themify-link-10":"themify-link-10","themify-link-5":"themify-link-5","themify-link-6":"themify-link-6"}',
  'setting-link_field_hash' => '11',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'skin' => 'wedding',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'site-logo_image' => '{"mode":"image","id":110,"src":"https://themify.me/demo/themes/ultra-wedding/files/2016/09/wedding-logo.png","imgwidth":"","imgheight":"","mobile":{"color":"","opacity":"1.00"},"color":"","opacity":"1.00"}',
  'custom_css_post_id' => -1,
  'sticky_header_imageselect' => '{"id":"","src":"","imgheight":"","imgwidth":"68"}',
  'scheme_link_color' => '{"color":"","opacity":1,"mobile":{"color":"","opacity":"1.00"}}',
  'mobile_menu_hover_color' => '{"color":"","opacity":1,"mobile":{"color":"","opacity":"1.00"}}',
  'mobile_menu_hover_background' => '{"color":"","opacity":1,"mobile":{"color":"","opacity":"1.00"}}',
  'main_nav_link_hover_background' => '{"color":"","opacity":1,"mobile":{"color":"","opacity":"1.00"}}',
  'main_nav_link_hover_color' => '{"color":"","opacity":1,"mobile":{"color":"","opacity":"1.00"}}',
  'customcss' => '8',
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "wedding-page-menu" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
