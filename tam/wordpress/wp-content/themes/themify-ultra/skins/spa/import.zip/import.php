<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 2,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 3,
  'name' => 'simple',
  'slug' => 'simple',
  'term_group' => 0,
  'taxonomy' => 'product_type',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 10,
  'name' => 'Cosmetic',
  'slug' => 'cosmetic',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 11,
  'name' => 'Cosmetic',
  'slug' => 'cosmetic',
  'term_group' => 0,
  'taxonomy' => 'product_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 12,
  'name' => 'Anti Acne',
  'slug' => 'anti-acne',
  'term_group' => 0,
  'taxonomy' => 'product_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 13,
  'name' => 'Soap',
  'slug' => 'soap',
  'term_group' => 0,
  'taxonomy' => 'product_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 14,
  'name' => 'Supplement',
  'slug' => 'supplement',
  'term_group' => 0,
  'taxonomy' => 'product_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 15,
  'name' => 'Aromatherapy',
  'slug' => 'aromatherapy',
  'term_group' => 0,
  'taxonomy' => 'product_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 16,
  'name' => 'Shampoo',
  'slug' => 'shampoo',
  'term_group' => 0,
  'taxonomy' => 'product_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 17,
  'name' => 'Shaving',
  'slug' => 'shaving',
  'term_group' => 0,
  'taxonomy' => 'product_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 18,
  'name' => 'Cream',
  'slug' => 'cream',
  'term_group' => 0,
  'taxonomy' => 'product_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 19,
  'name' => 'Nail Paint',
  'slug' => 'nail-paint',
  'term_group' => 0,
  'taxonomy' => 'product_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 20,
  'name' => 'Waxing',
  'slug' => 'waxing',
  'term_group' => 0,
  'taxonomy' => 'product_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 11,
  'post_date' => '2016-11-02 02:39:22',
  'post_date_gmt' => '2016-11-02 02:39:22',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static-->Yonge St, Toronto ON
<h2>Contact Form</h2>
<img src="https://themify.me/demo/themes/ultra-spa/files/2016/11/title-white-divider.png" title="title white divider" alt="title white divider" />
<form action="https://themify.me/demo/themes/ultra-spa/wp-admin/admin-ajax.php" id="contact-0--form" method="post" data-post-id="0" data-element-id="8f53caf"> <label for="contact-0--contact-name">Name </label> <input type="text" name="contact-name" placeholder="" id="contact-0--contact-name" value="" /> <label for="contact-0--contact-email">Email </label> <input type="text" name="contact-email" placeholder="" id="contact-0--contact-email" value="" /> <label for="contact-0--contact-message">Message *</label> <textarea name="contact-message" placeholder="" id="contact-0--contact-message" rows="8" cols="45" required></textarea> <button type="submit"> Send </button> </form>
<p>128 Main Street <br />Toronto, ON <br />M1E 2G6</p>

<h3>416-238-3368</h3>

<ul> <li><strong>Mon - Fri</strong> <em>11:00am - 8:00pm</em></li> <li><strong>Sat</strong> <em>9:00am - 8:00pm</em></li> <li><strong>Sun</strong> <em>9:00am - 5:00pm</em></li> </ul>
<!--/themify_builder_static-->',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2020-07-25 07:39:01',
  'post_modified_gmt' => '2020-07-25 07:39:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?page_id=11',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'mobile_menu_styles' => 'default',
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"622ae38\\",\\"cols\\":[{\\"element_id\\":\\"e76c27b\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"maps-pro\\",\\"element_id\\":\\"ef12583\\",\\"mod_settings\\":{\\"map_display_type\\":\\"dynamic\\",\\"w_map\\":\\"100\\",\\"unit_w\\":\\"%\\",\\"w_map_static\\":\\"500\\",\\"h_map\\":\\"645\\",\\"type_map\\":\\"ROADMAP\\",\\"style_map\\":\\"greyscale\\",\\"scrollwheel_map\\":\\"disable\\",\\"draggable_map\\":\\"enable\\",\\"disable_map_ui\\":\\"no\\",\\"zoom_map\\":\\"17\\",\\"map_center\\":\\"1 Yonge Street,\\\\nToronto, ON\\\\nCanada\\",\\"markers\\":[{\\"address\\":\\"1 Yonge Street,\\\\nToronto, ON\\\\nCanada\\",\\"title\\":\\"Yonge St, Toronto ON\\",\\"image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/map-pin.png\\"}],\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"w_map_unit\\":\\"%\\",\\"map_polyline\\":\\"no\\",\\"map_polyline_geodesic\\":\\"yes\\",\\"map_polyline_stroke\\":\\"2\\",\\"map_polyline_color\\":\\"#ff0000_1\\"}}]}],\\"styling\\":{\\"row_width\\":\\"fullwidth\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"4bc0805\\",\\"cols\\":[{\\"element_id\\":\\"5c8ef79\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"plain-text\\",\\"element_id\\":\\"991b7da\\",\\"mod_settings\\":{\\"plain_text\\":\\"<h2>Contact Form<\\\\/h2>\\",\\"font_color\\":\\"ffffff\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"9f7734c\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/title-white-divider.png\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"-2\\",\\"margin_top_unit\\":\\"em\\",\\"margin_bottom\\":\\"3\\",\\"margin_bottom_unit\\":\\"em\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"8f53caf\\",\\"mod_settings\\":{\\"layout_contact\\":\\"style1\\",\\"text_align_success_message_left\\":\\"left\\",\\"text_align_success_message_center\\":\\"center\\",\\"text_align_success_message_right\\":\\"right\\",\\"text_align_success_message_justify\\":\\"justify\\",\\"text_align_error_message_left\\":\\"left\\",\\"text_align_error_message_center\\":\\"center\\",\\"text_align_error_message_right\\":\\"right\\",\\"text_align_error_message_justify\\":\\"justify\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"field_email_active\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"contact_sent_from\\":\\"enable\\",\\"send_to_admins\\":\\"true\\"}}],\\"grid_width\\":55.81750000000000255795384873636066913604736328125,\\"styling\\":{\\"background_color\\":\\"82d3da_1.00\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"50\\",\\"padding_right\\":\\"50\\",\\"padding_bottom\\":\\"50\\",\\"padding_left\\":\\"50\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"cdead84\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"8ab3326\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>128 Main Street <br \\\\/>Toronto, ON <br \\\\/>M1E 2G6<\\\\/p>\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"30\\"}}},{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"b3f47be\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"1\\",\\"color_divider\\":\\"dddddd_1.00\\",\\"divider_type\\":\\"fullwidth\\",\\"divider_width\\":\\"200\\",\\"divider_align\\":\\"left\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"style_divider\\":\\"solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"a219b94\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>416-238-3368<\\\\/h3>\\",\\"font_color\\":\\"f1a4a4\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"20\\"}},{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"2f26788\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"1\\",\\"color_divider\\":\\"dddddd_1.00\\",\\"divider_type\\":\\"fullwidth\\",\\"divider_width\\":\\"200\\",\\"divider_align\\":\\"left\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"style_divider\\":\\"solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"099b1f1\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"font_color_type\\":\\"font_color_solid\\",\\"border-type\\":\\"top\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\",\\"font_color_type_h5\\":\\"font_color_h5_solid\\",\\"font_color_type_h6\\":\\"font_color_h6_solid\\",\\"checkbox_dropcap_padding_apply_all\\":\\"1\\",\\"checkbox_dropcap_margin_apply_all\\":\\"1\\",\\"dropcap_border-type\\":\\"top\\",\\"content_text\\":\\"<ul>\\\\n<li><strong>Mon - Fri<\\\\/strong> <em>11:00am - 8:00pm<\\\\/em><\\\\/li>\\\\n<li><strong>Sat<\\\\/strong> <em>9:00am - 8:00pm<\\\\/em><\\\\/li>\\\\n<li><strong>Sun<\\\\/strong> <em>9:00am - 5:00pm<\\\\/em><\\\\/li>\\\\n<\\\\/ul>\\",\\"add_css_text\\":\\"location-hours\\"}},{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"97f07a8\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"1\\",\\"color_divider\\":\\"dddddd_1.00\\",\\"divider_type\\":\\"fullwidth\\",\\"divider_width\\":\\"200\\",\\"divider_align\\":\\"left\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"style_divider\\":\\"solid\\"}}],\\"grid_width\\":40.982799999999997453414835035800933837890625,\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_left\\":\\"3\\",\\"padding_left_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_css_column\\":\\"contact-info\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\"}}}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"background_repeat_inner\\":\\"repeat\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_position_inner\\":\\"center-center\\",\\"checkbox_padding_inner_apply_all\\":\\"1\\",\\"checkbox_border_inner_apply_all\\":\\"1\\",\\"top-frame_type\\":\\"top-presets\\",\\"bottom-frame_type\\":\\"bottom-presets\\",\\"left-frame_type\\":\\"left-presets\\",\\"right-frame_type\\":\\"right-presets\\",\\"padding_bottom\\":\\"3\\",\\"padding_bottom_unit\\":\\"%\\",\\"breakpoint_tablet_landscape\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"50\\",\\"checkbox_border_apply_all\\":\\"border\\"}}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 10,
  'post_date' => '2016-11-02 02:38:29',
  'post_date_gmt' => '2016-11-02 02:38:29',
  'post_content' => '<!--themify_builder_static--><h1>Gallery<br/>Photos</h1>
<a href="https://themify.me/demo/themes/ultra-spa/services/" rel="noopener" target="_blank" > <img src="https://themify.me/demo/themes/ultra-spa/files/2016/11/PeopleImages.com-ID377634-476x353-476x353.jpg" width="476" height="353" title="Lily Aromatheraphy" alt="Lily Aromatheraphy"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-spa/services/" rel="noopener" target="_blank"> Lily Aromatheraphy </a> </h3>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/massage-476x353-1-476x353.jpg" width="476" height="353" title="Massage" alt="Massage" srcset="https://themify.me/demo/themes/ultra-spa/files/2016/11/massage-476x353-1.jpg 476w, https://themify.me/demo/themes/ultra-spa/files/2016/11/massage-476x353-1-300x222.jpg 300w" sizes="(max-width: 476px) 100vw, 476px" /> <h3> Massage </h3>
<img src="https://themify.me/demo/themes/ultra-spa/files/2016/11/PeopleImages.com-ID1167254-476x353-476x353.jpg" width="476" height="353" title="Rose Oil Theraphy" alt="Rose Oil Theraphy"> <h3> Rose Oil Theraphy </h3>
<img src="https://themify.me/demo/themes/ultra-spa/files/2016/11/PeopleImages.com-ID1301337-476x353-476x353.jpg" width="476" height="353" title="Hot Stone Massage" alt="Hot Stone Massage"> <h3> Hot Stone Massage </h3>
<img src="https://themify.me/demo/themes/ultra-spa/files/2016/11/PeopleImages.com-ID376407-4-750x556-750x556.jpg" width="750" height="556" title="Stay Fresh" alt="Stay Fresh"> <h3> Stay Fresh </h3>
<img src="https://themify.me/demo/themes/ultra-spa/files/2016/11/PeopleImages.com-ID377644-951x353-951x353.jpg" width="951" height="353" title="Lavender Aromatheraphy" alt="Lavender Aromatheraphy"> <h3> Lavender Aromatheraphy </h3>
<img src="https://themify.me/demo/themes/ultra-spa/files/2016/11/PeopleImages.com-ID1301286-476x353-476x353.jpg" width="476" height="353" title="Olive Oil " alt="Olive Oil "> <h3> Olive Oil </h3>
<img src="https://themify.me/demo/themes/ultra-spa/files/2016/11/PeopleImages.com-ID8214-476x353-476x353.jpg" width="476" height="353" title="Manicure and pedicure" alt="Manicure and pedicure"> <h3> Manicure and pedicure </h3>
<h2>Instagram<br/>Our Instagram Photo</h2>
<img src="https://themify.me/demo/themes/ultra-spa-dev/files/2016/10/aromatheraphy-yellow.jpg" width="290" height="250" title="" alt="">
<img src="https://themify.me/demo/themes/ultra-spa-dev/files/2016/10/massage-oil.jpg" width="290" height="250" title="" alt="">
<img src="https://themify.me/demo/themes/ultra-spa-dev/files/2016/10/stone-massage.jpg" width="290" height="250" title="" alt="">
<img src="https://themify.me/demo/themes/ultra-spa-dev/files/2016/10/face-massages.jpg" width="290" height="250" title="" alt="">
<img src="https://themify.me/demo/themes/ultra-spa-dev/files/2016/10/body-massage.jpg" width="290" height="250" title="" alt="">
<img src="https://themify.me/demo/themes/ultra-spa-dev/files/2016/10/massage-facial.jpg" width="290" height="250" title="" alt="">
<img src="https://themify.me/demo/themes/ultra-spa-dev/files/2016/10/olive-spa.jpg" width="290" height="250" title="" alt="">
<img src="https://themify.me/demo/themes/ultra-spa-dev/files/2016/10/aromatheraphy-flower.jpg" width="290" height="250" title="" alt="">
<img src="https://themify.me/demo/themes/ultra-spa-dev/files/2016/10/waxing-1.jpg" width="290" height="250" title="" alt="">
<img src="https://themify.me/demo/themes/ultra-spa-dev/files/2016/10/aromatheraphy-2.jpg" width="290" height="250" title="" alt="">
<img src="https://themify.me/demo/themes/ultra-spa-dev/files/2016/10/massage-theraphy.jpg" width="290" height="250" title="" alt="">
<img src="https://themify.me/demo/themes/ultra-spa-dev/files/2016/10/after-facial.jpg" width="290" height="250" title="" alt=""><!--/themify_builder_static-->',
  'post_title' => 'Gallery',
  'post_excerpt' => '',
  'post_name' => 'gallery',
  'post_modified' => '2020-10-03 02:35:49',
  'post_modified_gmt' => '2020-10-03 02:35:49',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?page_id=10',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"rs00258\\",\\"cols\\":[{\\"element_id\\":\\"qwdr262\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"fancy-heading\\",\\"element_id\\":\\"fh96262\\",\\"mod_settings\\":{\\"heading\\":\\"Gallery\\",\\"sub_heading\\":\\"Photos\\",\\"heading_tag\\":\\"h1\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"text_alignment\\":\\"themify-text-center\\"}}]}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"background_color\\":\\"f4f4f4\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"4\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"6\\",\\"padding_bottom_unit\\":\\"%\\",\\"margin_top_unit\\":\\"em\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"border_bottom_color\\":\\"dddddd\\",\\"border_bottom_width\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"row_width\\":\\"fullwidth\\"}},{\\"element_id\\":\\"h8ba259\\",\\"cols\\":[{\\"element_id\\":\\"9b91264\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"ed0u264\\",\\"cols\\":[{\\"element_id\\":\\"erye265\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"t5kr265\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/PeopleImages.com-ID377634-476x353.jpg\\",\\"width_image\\":\\"476\\",\\"auto_fullwidth\\":\\"1\\",\\"title_image\\":\\"Lily Aromatheraphy\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/services\\\\/\\",\\"param_image\\":\\"newtab\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"l8nl265\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/massage-476x353-1.jpg\\",\\"width_image\\":\\"476\\",\\"auto_fullwidth\\":\\"1\\",\\"title_image\\":\\"Massage\\",\\"param_image\\":\\"lightbox\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"gp5b265\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"2syo265\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/PeopleImages.com-ID1167254-476x353.jpg\\",\\"width_image\\":\\"476\\",\\"auto_fullwidth\\":\\"1\\",\\"title_image\\":\\"Rose Oil Theraphy\\",\\"param_image\\":\\"lightbox\\",\\"image_zoom_icon\\":\\"zoom\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"border_top_style\\":\\"none\\",\\"border_right_style\\":\\"none\\",\\"border_bottom_style\\":\\"none\\",\\"border_left_style\\":\\"none\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"vxoc265\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/PeopleImages.com-ID1301337-476x353.jpg\\",\\"width_image\\":\\"476\\",\\"auto_fullwidth\\":\\"1\\",\\"title_image\\":\\"Hot Stone Massage\\",\\"param_image\\":\\"lightbox\\",\\"image_zoom_icon\\":\\"zoom\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"border_top_style\\":\\"none\\",\\"border_right_style\\":\\"none\\",\\"border_bottom_style\\":\\"none\\",\\"border_left_style\\":\\"none\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"vh6o265\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"arwj266\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/PeopleImages.com-ID376407-4-750x556.jpg\\",\\"width_image\\":\\"750\\",\\"auto_fullwidth\\":\\"1\\",\\"title_image\\":\\"Stay Fresh\\",\\"param_image\\":\\"lightbox\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]}],\\"gutter\\":\\"gutter-none\\"}]}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_top\\":\\"-50\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"row_width\\":\\"fullwidth\\",\\"custom_css_row\\":\\"gallery-block\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":\\"-5\\"}},{\\"element_id\\":\\"d1ui259\\",\\"cols\\":[{\\"element_id\\":\\"ghsv266\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"s1oz266\\",\\"cols\\":[{\\"element_id\\":\\"6rdq266\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ao94266\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/PeopleImages.com-ID377644-951x353.jpg\\",\\"width_image\\":\\"951\\",\\"auto_fullwidth\\":\\"1\\",\\"title_image\\":\\"Lavender Aromatheraphy\\",\\"param_image\\":\\"lightbox\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"cmx5267\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"33vm267\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/PeopleImages.com-ID1301286-476x353.jpg\\",\\"width_image\\":\\"476\\",\\"auto_fullwidth\\":\\"1\\",\\"title_image\\":\\"Olive Oil \\",\\"param_image\\":\\"lightbox\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"apcp267\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"29u5267\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/PeopleImages.com-ID8214-476x353.jpg\\",\\"width_image\\":\\"476\\",\\"auto_fullwidth\\":\\"1\\",\\"title_image\\":\\"Manicure and pedicure\\",\\"param_image\\":\\"lightbox\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]}],\\"gutter\\":\\"gutter-none\\"}]}],\\"styling\\":{\\"row_width\\":\\"fullwidth\\",\\"custom_css_row\\":\\"gallery-block\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"0nr5259\\",\\"cols\\":[{\\"element_id\\":\\"3yu7267\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"fancy-heading\\",\\"element_id\\":\\"gsjy267\\",\\"mod_settings\\":{\\"heading\\":\\"Instagram\\",\\"sub_heading\\":\\"Our Instagram Photo\\",\\"heading_tag\\":\\"h2\\",\\"text_alignment\\":\\"themify-text-center\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}]}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"40\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"7a9q259\\",\\"cols\\":[{\\"element_id\\":\\"oy7y268\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"7zi5268\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa-dev\\\\/files\\\\/2016\\\\/10\\\\/aromatheraphy-yellow.jpg\\",\\"width_image\\":\\"290\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"0kuq268\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa-dev\\\\/files\\\\/2016\\\\/10\\\\/massage-oil.jpg\\",\\"width_image\\":\\"290\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"gsrk268\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa-dev\\\\/files\\\\/2016\\\\/10\\\\/stone-massage.jpg\\",\\"width_image\\":\\"290\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"t6im268\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"a90d268\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa-dev\\\\/files\\\\/2016\\\\/10\\\\/face-massages.jpg\\",\\"width_image\\":\\"290\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"2t1e268\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa-dev\\\\/files\\\\/2016\\\\/10\\\\/body-massage.jpg\\",\\"width_image\\":\\"290\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"5s01268\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa-dev\\\\/files\\\\/2016\\\\/10\\\\/massage-facial.jpg\\",\\"width_image\\":\\"290\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"font_color\\":\\"ffffff_1.00\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"jq3k269\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"r54y269\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa-dev\\\\/files\\\\/2016\\\\/10\\\\/olive-spa.jpg\\",\\"width_image\\":\\"290\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"8doq269\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa-dev\\\\/files\\\\/2016\\\\/10\\\\/aromatheraphy-flower.jpg\\",\\"width_image\\":\\"290\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"fz14269\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa-dev\\\\/files\\\\/2016\\\\/10\\\\/waxing-1.jpg\\",\\"width_image\\":\\"290\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"qqj7269\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"9e2l269\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa-dev\\\\/files\\\\/2016\\\\/10\\\\/aromatheraphy-2.jpg\\",\\"width_image\\":\\"290\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"rf44269\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa-dev\\\\/files\\\\/2016\\\\/10\\\\/massage-theraphy.jpg\\",\\"width_image\\":\\"290\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"eshq269\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa-dev\\\\/files\\\\/2016\\\\/10\\\\/after-facial.jpg\\",\\"width_image\\":\\"290\\",\\"auto_fullwidth\\":\\"1\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_border_apply_all\\":\\"border\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"font_color\\":\\"ffffff_1.00\\",\\"text_align\\":\\"center\\",\\"padding_bottom\\":\\"8\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"50\\",\\"checkbox_border_apply_all\\":\\"border\\"}}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 6,
  'post_date' => '2016-11-02 02:37:31',
  'post_date_gmt' => '2016-11-02 02:37:31',
  'post_content' => '<!--themify_builder_static--><h1>Ultra Spa</h1><h4>The best rated spa in Toronto</h4>
<h3>416-366 2886</h3>
<ul> <li><strong>Mon - Fri</strong> <em>11:00am - 8:00pm</em></li> <li><strong>Sat</strong> <em>9:00am - 8:00pm</em></li> <li><strong>Sun</strong> <em>9:00am - 5:00pm</em></li> </ul>
<h2>Services<br/></h2>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/nails-400x340-400x232.jpg" width="400" height="232" title="nails" alt="Nails" srcset="https://themify.me/demo/themes/ultra-spa/files/2016/11/nails-400x340-400x232.jpg 400w, https://themify.me/demo/themes/ultra-spa/files/2016/11/nails-300x174.jpg 300w, https://themify.me/demo/themes/ultra-spa/files/2016/11/nails.jpg 560w" sizes="(max-width: 400px) 100vw, 400px" />
<h3 style="text-align: center;">Nails</h3><p style="text-align: center;">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/facial-360x480.jpg" width="360" height="480" title="facial" alt="Facial" srcset="https://themify.me/demo/themes/ultra-spa/files/2016/11/facial.jpg 360w, https://themify.me/demo/themes/ultra-spa/files/2016/11/facial-225x300.jpg 225w" sizes="(max-width: 360px) 100vw, 360px" />
<h3>Facial</h3> <p>With endless modalities and customization, we have thousands of spa and wellness location for your next massage</p> <ul> <li> Lorem ipsum dolor sit amet.</li> <li> Duis aute irure dolor.</li> <li> Nemo enim ipsam voluptatem.</li> <li> Temporibus autem quibusdam.</li> </ul>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/massage-560x340.jpg" width="560" height="340" title="massage" alt="massage" srcset="https://themify.me/demo/themes/ultra-spa/files/2016/11/massage.jpg 560w, https://themify.me/demo/themes/ultra-spa/files/2016/11/massage-300x182.jpg 300w" sizes="(max-width: 560px) 100vw, 560px" />
<h3 style="text-align: right;">Massage</h3><p style="text-align: right;">Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/waxing-360x240.jpg" width="360" height="240" title="waxing" alt="waxing" srcset="https://themify.me/demo/themes/ultra-spa/files/2016/11/waxing.jpg 360w, https://themify.me/demo/themes/ultra-spa/files/2016/11/waxing-300x200.jpg 300w" sizes="(max-width: 360px) 100vw, 360px" />
<h3>Waxing</h3><p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet.</p>
<a href="http://themify.me/" > View service & pricing </a>
<h2>Promotions</h2> <p>Subscribe our newsletter and receive monthly promotions &amp; new products.</p>
<h2>Get 15% discount</h2>
<img loading="lazy" width="240" height="22" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/title-white-divider.png" title="title white divider" alt="title white divider">
<h2>This Month Special</h2>
$24 <p>Beauty</p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
$15 <p>Massage</p> Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.
$15 <p>Yoga</p> Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.
<h5 style="text-align: center;">Visit our store &amp; present your code:<br />WEBPROMO</h5>
<h2>Our Shop<br/></h2>
<ul data-lazy="1"> <li> <figure> <a href="https://themify.me/demo/themes/ultra-spa/product/cosmetic-set/" title="Cosmetic Set"><img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/pink-cosmetic-258x243.jpg" width="258" height="243" title="pink-cosmetic" alt="pink-cosmetic"></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-spa/product/cosmetic-set/" title="Cosmetic Set"> Cosmetic Set </a> </h3> 
 <bdi>&#36;70.00</bdi> <p><a href="?add-to-cart=87" data-quantity="1" data-product_id="87" data-product_sku="" aria-label="Add &ldquo;Cosmetic Set&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-spa/product/anti-acne-cream-package/" title="Anti Acne Cream Package"><img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/anti-acne-cream-package-258x243.jpg" width="258" height="243" title="anti-acne-cream-package" alt="anti-acne-cream-package"></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-spa/product/anti-acne-cream-package/" title="Anti Acne Cream Package"> Anti Acne Cream Package </a> </h3> 
 <bdi>&#36;150.00</bdi> <p><a href="?add-to-cart=85" data-quantity="1" data-product_id="85" data-product_sku="" aria-label="Add &ldquo;Anti Acne Cream Package&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-spa/product/bath-salt/" title="Bath Salt"><img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/10/olive-soap-258x243.jpg" width="258" height="243" title="olive-soap" alt="olive-soap"></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-spa/product/bath-salt/" title="Bath Salt"> Bath Salt </a> </h3> 
 <bdi>&#36;25.00</bdi> <p><a href="?add-to-cart=49" data-quantity="1" data-product_id="49" data-product_sku="" aria-label="Add &ldquo;Bath Salt&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-spa/product/skin-supplement/" title="Skin Supplement"><img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/skin-suplement-258x243.jpg" width="258" height="243" title="skin-suplement" alt="skin-suplement"></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-spa/product/skin-supplement/" title="Skin Supplement"> Skin Supplement </a> </h3> 
 <bdi>&#36;25.00</bdi> <p><a href="?add-to-cart=81" data-quantity="1" data-product_id="81" data-product_sku="" aria-label="Add &ldquo;Skin Supplement&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> </ul>
<a href="https://themify.me/demo/themes/ultra-spa/shop" > Shop More </a><!--/themify_builder_static-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2021-02-20 03:46:46',
  'post_modified_gmt' => '2021-02-20 03:46:46',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?page_id=6',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'header_design' => 'header-horizontal',
    'mobile_menu_styles' => 'default',
    'header_wrap' => 'transparent',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"50bbc1e\\",\\"cols\\":[{\\"element_id\\":\\"3dda76d\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"99567cd\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Ultra Spa<\\\\/h1><h4>The best rated spa in Toronto<\\\\/h4>\\",\\"font_size\\":\\"1.1\\",\\"font_size_unit\\":\\"em\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"font_size_h1\\":\\"4.75\\",\\"font_size_h1_unit\\":\\"em\\",\\"line_height_h1\\":\\"72\\",\\"font_size_h4\\":\\"1.5\\",\\"font_size_h4_unit\\":\\"em\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"008d8a5\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>416-366 2886<\\\\/h3>\\",\\"font_color\\":\\"f1a4a4_1.00\\",\\"font_size\\":\\"1.2\\",\\"font_size_unit\\":\\"em\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"e670210\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"font_color_type\\":\\"font_color_solid\\",\\"border-type\\":\\"top\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\",\\"font_color_type_h5\\":\\"font_color_h5_solid\\",\\"font_color_type_h6\\":\\"font_color_h6_solid\\",\\"checkbox_dropcap_padding_apply_all\\":\\"1\\",\\"checkbox_dropcap_margin_apply_all\\":\\"1\\",\\"dropcap_border-type\\":\\"top\\",\\"content_text\\":\\"<ul>\\\\n<li><strong>Mon - Fri<\\\\/strong> <em>11:00am - 8:00pm<\\\\/em><\\\\/li>\\\\n<li><strong>Sat<\\\\/strong> <em>9:00am - 8:00pm<\\\\/em><\\\\/li>\\\\n<li><strong>Sun<\\\\/strong> <em>9:00am - 5:00pm<\\\\/em><\\\\/li>\\\\n<\\\\/ul>\\",\\"add_css_text\\":\\"location-hours\\"}}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_css_column\\":\\"spa-info\\"}},{\\"element_id\\":\\"29d8438\\",\\"grid_class\\":\\"col4-2\\"}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/ultra-spa-header-2-1024x716.jpg\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"right-bottom\\",\\"background_color\\":\\"eefeff\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"20\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"20\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"breakpoint_tablet_landscape\\":{\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/bg-header-spa-mobile-4.jpg\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_tablet\\":{\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/bg-header-spa-mobile-4.jpg\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_mobile\\":{\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/bg-header-spa-mobile-small.jpg\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"25\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"50\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}},{\\"element_id\\":\\"1d18bca\\",\\"cols\\":[{\\"element_id\\":\\"3166b7d\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"fancy-heading\\",\\"element_id\\":\\"2e12aa6\\",\\"mod_settings\\":{\\"heading\\":\\"Services\\",\\"heading_tag\\":\\"h2\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_bottom\\":\\"50\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"text_alignment\\":\\"themify-text-center\\"}},{\\"element_id\\":\\"f48ee40\\",\\"cols\\":[{\\"element_id\\":\\"51c51ee\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"1ce2387\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/nails-400x340.jpg\\",\\"width_image\\":\\"400\\",\\"param_image\\":\\"regular\\",\\"alt_image\\":\\"Nails\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"fb2a4a1\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3 style=\\\\\\"text-align: center;\\\\\\">Nails<\\\\/h3><p style=\\\\\\"text-align: center;\\\\\\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.<\\\\/p>\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"60\\",\\"margin_bottom\\":\\"30\\"}}}]},{\\"element_id\\":\\"34e77ca\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"acfa72d\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/facial.jpg\\",\\"width_image\\":\\"360\\",\\"param_image\\":\\"regular\\",\\"alt_image\\":\\"Facial\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]},{\\"element_id\\":\\"f0de90f\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"1164f2a\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Facial<\\\\/h3>\\\\n<p>With endless modalities and customization, we have thousands of spa and wellness location for your next massage<\\\\/p>\\\\n<ul>\\\\n<li><i class=\\\\\\"fa fa-circle\\\\\\"><\\\\/i> Lorem ipsum dolor sit amet.<\\\\/li>\\\\n<li><i class=\\\\\\"fa fa-circle\\\\\\"><\\\\/i> Duis aute irure dolor.<\\\\/li>\\\\n<li><i class=\\\\\\"fa fa-circle\\\\\\"><\\\\/i> Nemo enim ipsam voluptatem.<\\\\/li>\\\\n<li><i class=\\\\\\"fa fa-circle\\\\\\"><\\\\/i> Temporibus autem quibusdam.<\\\\/li>\\\\n<\\\\/ul>\\\\n\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"50\\",\\"margin_bottom\\":\\"30\\"}}}]}]}]}],\\"styling\\":{\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/pink-flower-1.jpg\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_position\\":\\"left-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_tablet_landscape\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_mobile\\":{\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/pink-flower-small-mobile.jpg\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"20\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}},{\\"element_id\\":\\"16d8327\\",\\"cols\\":[{\\"element_id\\":\\"e3b0347\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"4240289\\",\\"cols\\":[{\\"element_id\\":\\"4106353\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3a03d88\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/massage.jpg\\",\\"width_image\\":\\"560\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"861f650\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3 style=\\\\\\"text-align: right;\\\\\\">Massage<\\\\/h3><p style=\\\\\\"text-align: right;\\\\\\">Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda.<\\\\/p>\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"50\\",\\"margin_bottom\\":\\"30\\"}}}]},{\\"element_id\\":\\"7594d3a\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"7feded2\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/waxing.jpg\\",\\"width_image\\":\\"360\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"c45ad29\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Waxing<\\\\/h3><p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet.<\\\\/p>\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"50\\",\\"margin_bottom\\":\\"40\\"}}}]}]},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"0837088\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_top\\":\\"30\\",\\"border_top_style\\":\\"none\\",\\"border_right_style\\":\\"none\\",\\"border_bottom_style\\":\\"none\\",\\"border_left_style\\":\\"none\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"link_color\\":\\"ffffff\\",\\"padding_link_top\\":\\"5\\",\\"padding_link_top_unit\\":\\"%\\",\\"checkbox_padding_link_apply_all\\":\\"1\\",\\"checkbox_link_margin_apply_all\\":\\"1\\",\\"checkbox_link_border_apply_all\\":\\"1\\",\\"buttons_size\\":\\"normal\\",\\"buttons_shape\\":\\"squared\\",\\"display\\":\\"buttons-horizontal\\",\\"content_button\\":[{\\"label\\":\\"View service & pricing\\",\\"link\\":\\"http:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"pink\\",\\"icon_alignment\\":\\"left\\"}]}}]}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/white-flower.jpg\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"right-bottom\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"background_repeat_inner\\":\\"repeat\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_position_inner\\":\\"center-center\\",\\"checkbox_padding_inner_apply_all\\":\\"1\\",\\"checkbox_border_inner_apply_all\\":\\"1\\",\\"top-frame_type\\":\\"top-presets\\",\\"bottom-frame_type\\":\\"bottom-presets\\",\\"left-frame_type\\":\\"left-presets\\",\\"right-frame_type\\":\\"right-presets\\",\\"padding_top\\":\\"2\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"20\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"breakpoint_tablet_landscape\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_bottom\\":\\"20\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\"}}},{\\"element_id\\":\\"49bd0a6\\",\\"cols\\":[{\\"element_id\\":\\"830f4a8\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"0ee4d6d\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Promotions<\\\\/h2>\\\\n<p>Subscribe our newsletter and receive monthly promotions &amp; new products.<\\\\/p>\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_tablet\\":{\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}}],\\"grid_width\\":33.141199999999997771737980656325817108154296875,\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"font_color\\":\\"#ffffff\\",\\"padding_right\\":\\"5\\",\\"padding_right_unit\\":\\"%\\",\\"border_right_color\\":\\"47556c_1.00\\",\\"border_right_width\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_tablet\\":{\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_color\\":\\"#ffffff\\",\\"padding_bottom\\":\\"15\\",\\"padding_bottom_unit\\":\\"px\\",\\"text_align\\":\\"left\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#47556c\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"},\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_align\\":\\"right\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"breakpoint_tablet_landscape\\":{\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_align\\":\\"right\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_color\\":\\"#ffffff\\"},\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#47556c\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_bottom\\":\\"15\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"}}},{\\"element_id\\":\\"3892a65\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"4ce933b\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Get 15% discount<\\\\/h2>\\",\\"add_css_text\\":\\"news-letter\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"element_id\\":\\"gek9190\\",\\"cols\\":[{\\"element_id\\":\\"bp3n191\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"optin\\",\\"element_id\\":\\"7yzr363\\",\\"mod_settings\\":{\\"label_firstname\\":\\"First Name\\",\\"default_fname\\":\\"John\\",\\"label_lastname\\":\\"Last Name\\",\\"default_lname\\":\\"Doe\\",\\"label_submit\\":\\"Subscribe\\",\\"message\\":\\"<p>Success!<\\\\/p>\\",\\"layout\\":\\"tb_optin_horizontal\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"success_action\\":\\"s2\\",\\"lname_hide\\":\\"1\\",\\"fname_hide\\":\\"1\\",\\"mailchimp_list\\":\\"297ec65a49\\",\\"provider\\":\\"mailchimp\\",\\"checkbox_r_c_sb_apply_all\\":\\"1\\",\\"r_c_sb_opp_left\\":false,\\"r_c_sb_opp_bottom\\":false,\\"r_c_sb_top\\":\\"0\\",\\"bg_c_s\\":\\"#f1a4a4\\",\\"checkbox_r_c_in_apply_all\\":\\"1\\",\\"r_c_in_opp_left\\":false,\\"r_c_in_opp_bottom\\":false,\\"r_c_in_top\\":\\"0\\",\\"p_in_opp_left\\":false,\\"p_in_opp_top\\":\\"1\\",\\"p_in_bottom\\":\\"18\\",\\"p_in_top\\":\\"18\\",\\"p_sb_opp_left\\":false,\\"p_sb_bottom\\":\\"18\\",\\"p_sb_opp_top\\":\\"1\\",\\"p_sb_top\\":\\"18\\",\\"b_s-type\\":\\"top\\",\\"b_in-type\\":\\"all\\",\\"b_in_top_width\\":\\"5\\",\\"b_in_top_color\\":\\"#fff204\\",\\"b_in_top_style\\":\\"none\\",\\"email_placeholder\\":\\"Email\\",\\"f_c_i\\":\\"#797979\\"}}]},{\\"element_id\\":\\"vlbp192\\",\\"grid_class\\":\\"col3-1\\"}]}],\\"grid_width\\":63.65979999999999705551090301014482975006103515625,\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"font_color\\":\\"ffffff_1.00\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_border_apply_all\\":\\"border\\"}}],\\"col_tablet\\":\\"column-full\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"custom_css_row\\":\\"newsletter-block\\",\\"background_color\\":\\"273244_1.00\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"12\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"40\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"12\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"5\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\"}}},{\\"element_id\\":\\"d361e9b\\",\\"cols\\":[{\\"element_id\\":\\"2f56d84\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"7b78d0c\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/title-white-divider.png\\",\\"param_image\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_bottom\\":\\"10\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"plain-text\\",\\"element_id\\":\\"0eabde8\\",\\"mod_settings\\":{\\"plain_text\\":\\"<h2>This Month Special<\\\\/h2>\\",\\"font_color\\":\\"ffffff_1.00\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"0\\",\\"margin_right\\":\\"0\\",\\"margin_bottom\\":\\"-10\\",\\"margin_left\\":\\"0\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"element_id\\":\\"1492b30\\",\\"cols\\":[{\\"element_id\\":\\"5429a1a\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"pricing-table\\",\\"element_id\\":\\"9716ac8\\",\\"mod_settings\\":{\\"mod_color_pricing_table\\":\\"transparent\\",\\"mod_price_pricing_table\\":\\"$24\\",\\"mod_description_pricing_table\\":\\"Beauty\\",\\"mod_feature_list_pricing_table\\":\\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\\",\\"border_right_color\\":\\"a1e8ee_1.00\\",\\"border_right_width\\":\\"1\\",\\"mod_title_font_color\\":\\"ffffff_1.00\\",\\"mod_text_align_title_left\\":\\"left\\",\\"mod_text_align_title_center\\":\\"center\\",\\"mod_text_align_title_right\\":\\"right\\",\\"mod_text_align_title_justify\\":\\"justify\\",\\"mod_title_background_color\\":\\"82d3da_1.00\\",\\"mod_feature_font_color\\":\\"ffffff_1.00\\",\\"mod_text_align_content_left\\":\\"left\\",\\"mod_text_align_content_center\\":\\"center\\",\\"mod_text_align_content_right\\":\\"right\\",\\"mod_text_align_content_justify\\":\\"justify\\",\\"mod_feature_bg_color\\":\\"82d3da_1.00\\",\\"mod_text_align_button_left\\":\\"left\\",\\"mod_text_align_button_center\\":\\"center\\",\\"mod_text_align_button_right\\":\\"right\\",\\"mod_text_align_button_justify\\":\\"justify\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"5318ea1\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"pricing-table\\",\\"element_id\\":\\"5e6165c\\",\\"mod_settings\\":{\\"mod_color_pricing_table\\":\\"transparent\\",\\"mod_price_pricing_table\\":\\"$15\\",\\"mod_description_pricing_table\\":\\"Massage\\",\\"mod_feature_list_pricing_table\\":\\"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.\\",\\"border_right_color\\":\\"a1e8ee_1.00\\",\\"border_right_width\\":\\"1\\",\\"mod_title_font_color\\":\\"ffffff_1.00\\",\\"mod_text_align_title_left\\":\\"left\\",\\"mod_text_align_title_center\\":\\"center\\",\\"mod_text_align_title_right\\":\\"right\\",\\"mod_text_align_title_justify\\":\\"justify\\",\\"mod_title_background_color\\":\\"82d3da_1.00\\",\\"mod_feature_font_color\\":\\"ffffff_1.00\\",\\"mod_text_align_content_left\\":\\"left\\",\\"mod_text_align_content_center\\":\\"center\\",\\"mod_text_align_content_right\\":\\"right\\",\\"mod_text_align_content_justify\\":\\"justify\\",\\"mod_feature_bg_color\\":\\"82d3da_1.00\\",\\"mod_text_align_button_left\\":\\"left\\",\\"mod_text_align_button_center\\":\\"center\\",\\"mod_text_align_button_right\\":\\"right\\",\\"mod_text_align_button_justify\\":\\"justify\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\"}},{\\"element_id\\":\\"d879b85\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"pricing-table\\",\\"element_id\\":\\"c499176\\",\\"mod_settings\\":{\\"mod_color_pricing_table\\":\\"transparent\\",\\"mod_price_pricing_table\\":\\"$15\\",\\"mod_description_pricing_table\\":\\"Yoga\\",\\"mod_feature_list_pricing_table\\":\\"Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.\\",\\"mod_title_font_color\\":\\"ffffff_1.00\\",\\"mod_text_align_title_left\\":\\"left\\",\\"mod_text_align_title_center\\":\\"center\\",\\"mod_text_align_title_right\\":\\"right\\",\\"mod_text_align_title_justify\\":\\"justify\\",\\"mod_title_background_color\\":\\"82d3da_1.00\\",\\"mod_feature_font_color\\":\\"ffffff_1.00\\",\\"mod_text_align_content_left\\":\\"left\\",\\"mod_text_align_content_center\\":\\"center\\",\\"mod_text_align_content_right\\":\\"right\\",\\"mod_text_align_content_justify\\":\\"justify\\",\\"mod_feature_bg_color\\":\\"82d3da_1.00\\",\\"mod_text_align_button_left\\":\\"left\\",\\"mod_text_align_button_center\\":\\"center\\",\\"mod_text_align_button_right\\":\\"right\\",\\"mod_text_align_button_justify\\":\\"justify\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_border_apply_all\\":\\"border\\"}}],\\"gutter\\":\\"gutter-none\\"},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"677906e\\",\\"mod_settings\\":{\\"content_text\\":\\"<h5 style=\\\\\\"text-align: center;\\\\\\">Visit our store &amp; present your code:<br \\\\/>WEBPROMO<\\\\/h5>\\",\\"font_color\\":\\"fff\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}],\\"styling\\":{\\"background_color\\":\\"82d3da_1.00\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"50\\",\\"padding_right\\":\\"5\\",\\"padding_right_unit\\":\\"%\\",\\"padding_bottom\\":\\"50\\",\\"padding_left\\":\\"5\\",\\"padding_left_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":\\"-8\\"}}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"-150\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_tablet\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"50\\",\\"checkbox_border_apply_all\\":\\"border\\"}}},{\\"element_id\\":\\"999d0e1\\",\\"cols\\":[{\\"element_id\\":\\"2789eb0\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"fancy-heading\\",\\"element_id\\":\\"0f00299\\",\\"mod_settings\\":{\\"heading\\":\\"Our Shop\\",\\"heading_tag\\":\\"h2\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_bottom\\":\\"50\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"text_alignment\\":\\"themify-text-center\\"}},{\\"mod_name\\":\\"products\\",\\"element_id\\":\\"cbb1f43\\",\\"mod_settings\\":{\\"query_products\\":\\"all\\",\\"hide_child_products\\":\\"no\\",\\"hide_free_products\\":\\"no\\",\\"post_per_page_products\\":\\"4\\",\\"orderby_products\\":\\"date\\",\\"order_products\\":\\"desc\\",\\"template_products\\":\\"list\\",\\"layout_products\\":\\"grid4\\",\\"layout_slider\\":\\"slider-default\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"4\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"scroll\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"show_arrow_slider\\":\\"yes\\",\\"description_products\\":\\"none\\",\\"hide_feat_img_products\\":\\"no\\",\\"img_width_products\\":\\"258\\",\\"img_height_products\\":\\"243\\",\\"unlink_feat_img_products\\":\\"no\\",\\"hide_post_title_products\\":\\"no\\",\\"unlink_post_title_products\\":\\"no\\",\\"hide_price_products\\":\\"no\\",\\"hide_add_to_cart_products\\":\\"no\\",\\"hide_rating_products\\":\\"no\\",\\"hide_sales_badge\\":\\"no\\",\\"hide_page_nav_products\\":\\"yes\\",\\"text_align\\":\\"center\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"addb95f\\",\\"mod_settings\\":{\\"buttons_size\\":\\"normal\\",\\"buttons_style\\":\\"outline\\",\\"content_button\\":[{\\"label\\":\\"Shop More\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/shop\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"pink\\"}],\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"padding_top_link\\":\\"20\\",\\"padding_right_link\\":\\"40\\",\\"padding_bottom_link\\":\\"20\\",\\"padding_left_link\\":\\"40\\",\\"checkbox_link_padding_apply_all\\":\\"padding\\",\\"link_checkbox_margin_apply_all\\":\\"margin\\",\\"link_checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}]}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"8\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 8,
  'post_date' => '2016-11-02 02:38:09',
  'post_date_gmt' => '2016-11-02 02:38:09',
  'post_content' => '<!--themify_builder_static--><h1>Services<br/>What we offer</h1>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/nails-560x325.jpg" width="560" height="325" title="Nails" alt="Nails" srcset="https://themify.me/demo/themes/ultra-spa/files/2016/11/nails.jpg 560w, https://themify.me/demo/themes/ultra-spa/files/2016/11/nails-300x174.jpg 300w, https://themify.me/demo/themes/ultra-spa/files/2016/11/nails-400x340-400x232.jpg 400w" sizes="(max-width: 560px) 100vw, 560px" /> <h3> Nails </h3>
<h4>Nail Manicure (Per packages)</h4> 
 $25 <br/>
<h4>Hand Massage (Per packages)</h4> 
 $35 <br/>
<h4>Nail Coloring (Per color)</h4> 
 $25 <br/>
<h4>Nail Theraphy (50Min)</h4> 
 $30 <br/>
<h4>Nail Painting (40Min)</h4> 
 $15 <br/>
<h4>Customized Spa Manicure (40Min)</h4> 
 $25 <br/>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/massage-service-560x325.jpg" width="560" height="325" title="Massage" alt="Massage" srcset="https://themify.me/demo/themes/ultra-spa/files/2016/11/massage-service.jpg 560w, https://themify.me/demo/themes/ultra-spa/files/2016/11/massage-service-300x174.jpg 300w" sizes="(max-width: 560px) 100vw, 560px" /> <h3> Massage </h3>
<h4>Full Body Massage (55 Min)</h4> 
 $25 <br/>
<h4>Hot Stone Massage (55 Min)</h4> 
 $25 <br/>
<h4>Deep Tissue Massage (Per area)</h4> 
 $25 <br/>
<h4>Aromatherapy Massage (50 Min)</h4> 
 $25 <br/>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/facial-service-560x325.jpg" width="560" height="325" title="Facial" alt="Facial" srcset="https://themify.me/demo/themes/ultra-spa/files/2016/11/facial-service.jpg 560w, https://themify.me/demo/themes/ultra-spa/files/2016/11/facial-service-300x174.jpg 300w" sizes="(max-width: 560px) 100vw, 560px" /> <h3> Facial </h3>
<h4>Face Scrub (45 Min)</h4> 
 $25 <br/>
<h4>Face Massage (30 Min)</h4> 
 $35 <br/>
<h4>Facial (Per packages)</h4> 
 $25 <br/>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-spa/files/2016/11/waxing-service-560x325.jpg" width="560" height="325" title="Waxing" alt="Waxing" srcset="https://themify.me/demo/themes/ultra-spa/files/2016/11/waxing-service.jpg 560w, https://themify.me/demo/themes/ultra-spa/files/2016/11/waxing-service-300x174.jpg 300w" sizes="(max-width: 560px) 100vw, 560px" /> <h3> Waxing </h3>
<h4>Laser Wax (Per packages)</h4> 
 $155 <br/>
<h4>Avocado wax (Per area)</h4> 
 $25 <br/>
<h4>Apricott Wax (Per area)</h4> 
 $35 <br/>
<h4>Natural Waxing (Per packages)</h4> 
 $55 <br/>
<h2>Call To Book Your Appoinment <br/>416 - 228 - 3368</h2>
Bay st, Toronto, ON<!--/themify_builder_static-->',
  'post_title' => 'Services',
  'post_excerpt' => '',
  'post_name' => 'services',
  'post_modified' => '2020-10-03 02:33:21',
  'post_modified_gmt' => '2020-10-03 02:33:21',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?page_id=8',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"wfj2849\\",\\"cols\\":[{\\"element_id\\":\\"szfg854\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"fancy-heading\\",\\"element_id\\":\\"71kd856\\",\\"mod_settings\\":{\\"heading\\":\\"Services\\",\\"sub_heading\\":\\"What we offer\\",\\"heading_tag\\":\\"h1\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"text_alignment\\":\\"themify-text-center\\"}}]}],\\"styling\\":{\\"row_width\\":\\"fullwidth\\",\\"background_color\\":\\"f4f4f4_1.00\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"4\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"3\\",\\"padding_bottom_unit\\":\\"%\\",\\"margin_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"border_bottom_color\\":\\"dddddd_1.00\\",\\"border_bottom_width\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"ejei849\\",\\"cols\\":[{\\"element_id\\":\\"yj2j858\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"vpdz858\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/nails.jpg\\",\\"width_image\\":\\"560\\",\\"title_image\\":\\"Nails\\",\\"param_image\\":\\"regular\\",\\"padding_bottom\\":\\"6\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"font_size_title\\":\\"2.5\\",\\"font_size_title_unit\\":\\"em\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"ncr2858\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Nail Manicure (Per packages)\\",\\"price_service_menu\\":\\"$25\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"6\\",\\"margin_top_unit\\":\\"%\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"lb5p859\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Hand Massage (Per packages)\\",\\"price_service_menu\\":\\"$35\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"zxfq859\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Nail Coloring (Per color)\\",\\"price_service_menu\\":\\"$25\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"80r2859\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Nail Theraphy (50Min)\\",\\"price_service_menu\\":\\"$30\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"f35n859\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Nail Painting (40Min)\\",\\"price_service_menu\\":\\"$15\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"c3i5859\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Customized Spa Manicure (40Min)\\",\\"price_service_menu\\":\\"$25\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"9jgq860\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/massage-service.jpg\\",\\"width_image\\":\\"560\\",\\"title_image\\":\\"Massage\\",\\"param_image\\":\\"regular\\",\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"6\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"font_size_title\\":\\"2.5\\",\\"font_size_title_unit\\":\\"em\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"p86x860\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Full Body Massage (55 Min)\\",\\"price_service_menu\\":\\"$25\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"6\\",\\"margin_top_unit\\":\\"%\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"6br8860\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Hot Stone Massage (55 Min)\\",\\"price_service_menu\\":\\"$25\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"89q7860\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Deep Tissue Massage (Per area)\\",\\"price_service_menu\\":\\"$25\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"5kms860\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Aromatherapy Massage (50 Min)\\",\\"price_service_menu\\":\\"$25\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]},{\\"element_id\\":\\"jvh9861\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"l0jf861\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/facial-service.jpg\\",\\"width_image\\":\\"560\\",\\"title_image\\":\\"Facial\\",\\"param_image\\":\\"regular\\",\\"padding_bottom\\":\\"6\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"font_size_title\\":\\"2.5\\",\\"font_size_title_unit\\":\\"em\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"j865861\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Face Scrub (45 Min)\\",\\"price_service_menu\\":\\"$25\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"6\\",\\"margin_top_unit\\":\\"%\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"rxps861\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Face Massage (30 Min)\\",\\"price_service_menu\\":\\"$35\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"6ala861\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Facial (Per packages)\\",\\"price_service_menu\\":\\"$25\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"4z7f862\\",\\"mod_settings\\":{\\"style_image\\":\\"image-overlay\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/waxing-service.jpg\\",\\"width_image\\":\\"560\\",\\"title_image\\":\\"Waxing\\",\\"param_image\\":\\"regular\\",\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"6\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"font_size_title\\":\\"2.5\\",\\"font_size_title_unit\\":\\"em\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"56fv862\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Laser Wax (Per packages)\\",\\"price_service_menu\\":\\"$155\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"6\\",\\"margin_top_unit\\":\\"%\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"sq54862\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Avocado wax (Per area)\\",\\"price_service_menu\\":\\"$25\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"v10b862\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Apricott Wax (Per area)\\",\\"price_service_menu\\":\\"$35\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"qndy862\\",\\"mod_settings\\":{\\"style_service_menu\\":\\"image-top\\",\\"title_service_menu\\":\\"Natural Waxing (Per packages)\\",\\"price_service_menu\\":\\"$55\\",\\"link_options\\":\\"regular\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]}],\\"styling\\":{\\"custom_css_row\\":\\"service-block\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"0hv8849\\",\\"cols\\":[{\\"element_id\\":\\"qr8t863\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"fancy-heading\\",\\"element_id\\":\\"mk59863\\",\\"mod_settings\\":{\\"heading\\":\\"Call To Book Your Appoinment \\",\\"sub_heading\\":\\"416 - 228 - 3368\\",\\"heading_tag\\":\\"h2\\",\\"css_class\\":\\"white-heading\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"font_color\\":\\"ffffff_1.00\\",\\"font_size\\":\\"36\\",\\"font_color_subheading\\":\\"ffffff_1.00\\",\\"font_size_subheading\\":\\"36\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"text_alignment\\":\\"themify-text-center\\"}}]}],\\"styling\\":{\\"background_color\\":\\"273244_1.00\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"4\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"40\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}},{\\"element_id\\":\\"4k3g849\\",\\"cols\\":[{\\"element_id\\":\\"semx864\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"maps-pro\\",\\"element_id\\":\\"7o8b864\\",\\"mod_settings\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_top_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"map_display_type\\":\\"dynamic\\",\\"w_map\\":\\"100\\",\\"unit_w\\":\\"%\\",\\"w_map_static\\":\\"500\\",\\"h_map\\":\\"500\\",\\"type_map\\":\\"ROADMAP\\",\\"style_map\\":\\"greyscale\\",\\"scrollwheel_map\\":\\"disable\\",\\"draggable_map\\":\\"enable\\",\\"disable_map_ui\\":\\"no\\",\\"zoom_map\\":\\"18\\",\\"map_center\\":\\"1 Yonge Street,\\\\nToronto, ON\\\\nCanada\\",\\"markers\\":[{\\"address\\":\\"1 Yonge Street,\\\\nToronto, ON\\\\nCanada\\",\\"latlng\\":\\"43.6429251,-79.3741862\\",\\"title\\":\\"Bay st, Toronto, ON\\",\\"image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-spa\\\\/files\\\\/2016\\\\/11\\\\/map-pin.png\\"}],\\"w_map_unit\\":\\"%\\",\\"map_polyline\\":\\"no\\",\\"margin_top\\":\\"-16.5\\"}}]}],\\"styling\\":{\\"background_slider_size\\":\\"large\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_repeat\\":\\"repeat\\",\\"background_attachment\\":\\"scroll\\",\\"background_position\\":\\"center-center\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"background_repeat_inner\\":\\"repeat\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_position_inner\\":\\"center-center\\",\\"checkbox_padding_inner_apply_all\\":\\"1\\",\\"checkbox_border_inner_apply_all\\":\\"1\\",\\"top-frame_type\\":\\"top-presets\\",\\"top-frame_width_unit\\":\\"%\\",\\"top-frame_height_unit\\":\\"%\\",\\"bottom-frame_type\\":\\"bottom-presets\\",\\"bottom-frame_width_unit\\":\\"%\\",\\"bottom-frame_height_unit\\":\\"%\\",\\"left-frame_type\\":\\"left-presets\\",\\"left-frame_width_unit\\":\\"%\\",\\"left-frame_height_unit\\":\\"%\\",\\"right-frame_type\\":\\"right-presets\\",\\"right-frame_width_unit\\":\\"%\\",\\"right-frame_height_unit\\":\\"%\\",\\"padding_bottom\\":\\"3\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"breakpoint_tablet_landscape\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"-80\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_tablet\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"-50\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"-50\\",\\"checkbox_border_apply_all\\":\\"border\\"}}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 423,
  'post_date' => '2020-12-31 14:13:03',
  'post_date_gmt' => '2020-12-31 14:13:03',
  'post_content' => '[wc_frontend_manager]',
  'post_title' => 'Store Manager',
  'post_excerpt' => '',
  'post_name' => 'store-manager',
  'post_modified' => '2020-12-31 14:13:03',
  'post_modified_gmt' => '2020-12-31 14:13:03',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/store-manager/',
  'menu_order' => 0,
  'post_type' => 'page',
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 87,
  'post_date' => '2016-11-01 16:20:05',
  'post_date_gmt' => '2016-11-01 16:20:05',
  'post_content' => '<div>

Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil.

</div>',
  'post_title' => 'Cosmetic Set',
  'post_excerpt' => 'Similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum.',
  'post_name' => 'cosmetic-set',
  'post_modified' => '2021-08-03 18:49:54',
  'post_modified_gmt' => '2021-08-03 18:49:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=87',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500092:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"sbj8190\\"}],\\"styling\\":[],\\"element_id\\":\\"eu4b802\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '88',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/pink-cosmetic.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '70',
    '_price' => '70',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '4.9.0',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_tax_status' => 'taxable',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'cosmetic',
    'product_tag' => 'cosmetic',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/pink-cosmetic.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 85,
  'post_date' => '2016-10-26 16:03:14',
  'post_date_gmt' => '2016-10-26 16:03:14',
  'post_content' => '<div>

Adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.

</div>',
  'post_title' => 'Anti Acne Cream Package',
  'post_excerpt' => 'Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus.',
  'post_name' => 'anti-acne-cream-package',
  'post_modified' => '2021-12-31 19:14:48',
  'post_modified_gmt' => '2021-12-31 19:14:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=85',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500100:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"iwhn000\\"}],\\"styling\\":[],\\"element_id\\":\\"li04300\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '86',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/anti-acne-cream-package.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '150',
    '_price' => '150',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '5.8.0',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_tax_status' => 'taxable',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'anti-acne',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/anti-acne-cream-package.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 49,
  'post_date' => '2016-10-23 16:22:33',
  'post_date_gmt' => '2016-10-23 16:22:33',
  'post_content' => '<div>

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus.

</div>',
  'post_title' => 'Bath Salt',
  'post_excerpt' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.',
  'post_name' => 'bath-salt',
  'post_modified' => '2021-08-03 18:50:30',
  'post_modified_gmt' => '2021-08-03 18:50:30',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=49',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500109:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"18a6022\\"}],\\"styling\\":[],\\"element_id\\":\\"tqxs133\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '25',
    '_price' => '25',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '4.9.0',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_thumbnail_id' => '52',
    '_wc_review_count' => '0',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/10/olive-soap.jpg',
    '_tax_status' => 'taxable',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'soap',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/10/olive-soap.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 81,
  'post_date' => '2016-10-22 15:44:37',
  'post_date_gmt' => '2016-10-22 15:44:37',
  'post_content' => '<div>

Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.

</div>',
  'post_title' => 'Skin Supplement',
  'post_excerpt' => 'Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_name' => 'skin-supplement',
  'post_modified' => '2021-05-19 21:00:48',
  'post_modified_gmt' => '2021-05-19 21:00:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=81',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500120:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"mgch764\\"}],\\"styling\\":[],\\"element_id\\":\\"6f72889\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '82',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/skin-suplement.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '25',
    '_price' => '25',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '4.9.0',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_tax_status' => 'taxable',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'supplement',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/skin-suplement.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 70,
  'post_date' => '2016-10-17 08:04:35',
  'post_date_gmt' => '2016-10-17 08:04:35',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio.',
  'post_title' => 'Aromatherapy Essence',
  'post_excerpt' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_name' => 'aromatherapy-essence',
  'post_modified' => '2019-10-29 17:43:51',
  'post_modified_gmt' => '2019-10-29 17:43:51',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=70',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500134:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"zi3f552\\"}],\\"styling\\":[],\\"element_id\\":\\"fp8j024\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '71',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/aromatheraphy-oil.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '20',
    '_price' => '20',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '3.7.1',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_tax_status' => 'taxable',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'aromatherapy',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/aromatheraphy-oil.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 47,
  'post_date' => '2016-10-16 16:20:26',
  'post_date_gmt' => '2016-10-16 16:20:26',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Flava Shampoo',
  'post_excerpt' => '<div>

Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

</div>',
  'post_name' => 'flava-shampoo',
  'post_modified' => '2016-11-07 06:29:02',
  'post_modified_gmt' => '2016-11-07 06:29:02',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=47',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500142:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"hym6020\\"}],\\"styling\\":[],\\"element_id\\":\\"diel042\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '18',
    '_price' => '18',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_thumbnail_id' => '54',
    '_wc_review_count' => '0',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/10/flava-shampoo-1.jpg',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'shampoo',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/10/flava-shampoo-1.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 44,
  'post_date' => '2016-10-15 16:12:17',
  'post_date_gmt' => '2016-10-15 16:12:17',
  'post_content' => '<div>

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

</div>',
  'post_title' => 'Shaving Foam',
  'post_excerpt' => 'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_name' => 'shaving-foam',
  'post_modified' => '2016-11-07 06:29:09',
  'post_modified_gmt' => '2016-11-07 06:29:09',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=44',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1557183429:2',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"5ycn492\\"}],\\"styling\\":[],\\"element_id\\":\\"oply308\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '35',
    '_price' => '35',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_thumbnail_id' => '56',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/10/shave-tube.jpg',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'shaving',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/10/shave-tube.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 83,
  'post_date' => '2016-10-14 15:48:16',
  'post_date_gmt' => '2016-10-14 15:48:16',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam.',
  'post_title' => 'Aloe Vera Cream',
  'post_excerpt' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit.',
  'post_name' => 'aloe-vera-cream',
  'post_modified' => '2016-11-07 06:29:17',
  'post_modified_gmt' => '2016-11-07 06:29:17',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=83',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1557178359:90',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"opqt002\\"}],\\"styling\\":[],\\"element_id\\":\\"c6my510\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '84',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/alole-vera.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '20',
    '_price' => '20',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'cream',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/alole-vera.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 42,
  'post_date' => '2016-10-14 15:42:21',
  'post_date_gmt' => '2016-10-14 15:42:21',
  'post_content' => '<div>

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

</div>',
  'post_title' => 'Kannel N6',
  'post_excerpt' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'kannel-n6',
  'post_modified' => '2019-11-19 18:45:00',
  'post_modified_gmt' => '2019-11-19 18:45:00',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=42',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500203:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"yv3u805\\"}],\\"styling\\":[],\\"element_id\\":\\"ygnu015\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '45',
    '_sale_price' => '35',
    '_price' => '35',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '3.8.0',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_thumbnail_id' => '55',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/10/kennel-n6.jpg',
    '_wc_review_count' => '0',
    '_tax_status' => 'taxable',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'soap',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/10/kennel-n6.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 79,
  'post_date' => '2016-10-04 09:19:28',
  'post_date_gmt' => '2016-10-04 09:19:28',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
  'post_title' => 'Cosmetic Brush Set',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_name' => 'cosmetic-brush-set',
  'post_modified' => '2016-11-07 06:30:11',
  'post_modified_gmt' => '2016-11-07 06:30:11',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=79',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500211:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"ju3p903\\"}],\\"styling\\":[],\\"element_id\\":\\"izep220\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '80',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/cosmetic-brush-set.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '12',
    '_price' => '12',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'cosmetic',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/cosmetic-brush-set.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 76,
  'post_date' => '2016-09-26 09:06:51',
  'post_date_gmt' => '2016-09-26 09:06:51',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_title' => 'Red Nail Paint',
  'post_excerpt' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.',
  'post_name' => 'red-nail-paint',
  'post_modified' => '2016-11-07 06:30:19',
  'post_modified_gmt' => '2016-11-07 06:30:19',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=76',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500219:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"emhk110\\"}],\\"styling\\":[],\\"element_id\\":\\"0gz9001\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '77',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/nail-paint.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '15',
    '_price' => '15',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'nail-paint',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/nail-paint.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 74,
  'post_date' => '2016-09-22 09:01:00',
  'post_date_gmt' => '2016-09-22 09:01:00',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.',
  'post_title' => 'Avocado Body Cream',
  'post_excerpt' => 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_name' => 'avocado-body-cream',
  'post_modified' => '2016-11-07 06:30:26',
  'post_modified_gmt' => '2016-11-07 06:30:26',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=74',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500226:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"nhdm334\\"}],\\"styling\\":[],\\"element_id\\":\\"pp2z330\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '75',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/avocado-cream.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '35',
    '_price' => '35',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'cream',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/avocado-cream.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 72,
  'post_date' => '2016-09-18 08:42:49',
  'post_date_gmt' => '2016-09-18 08:42:49',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.',
  'post_title' => 'Night Cream',
  'post_excerpt' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_name' => 'night-cream-2',
  'post_modified' => '2016-11-07 06:30:32',
  'post_modified_gmt' => '2016-11-07 06:30:32',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=72',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500232:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"4gds244\\"}],\\"styling\\":[],\\"element_id\\":\\"us0g404\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '73',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/whitening-cream.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '16',
    '_price' => '16',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'cream',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/whitening-cream.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 68,
  'post_date' => '2016-09-11 08:01:21',
  'post_date_gmt' => '2016-09-11 08:01:21',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
  'post_title' => 'Waxing Cream',
  'post_excerpt' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_name' => 'waxing-cream',
  'post_modified' => '2016-11-07 06:30:40',
  'post_modified_gmt' => '2016-11-07 06:30:40',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=68',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500240:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"rm7u006\\"}],\\"styling\\":[],\\"element_id\\":\\"ayk1404\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '69',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/waxing-cream.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '35',
    '_price' => '35',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'waxing',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/waxing-cream.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 66,
  'post_date' => '2016-09-09 07:58:29',
  'post_date_gmt' => '2016-09-09 07:58:29',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'White Pearl Soap',
  'post_excerpt' => 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_name' => 'white-pearl-soap',
  'post_modified' => '2016-11-07 06:30:48',
  'post_modified_gmt' => '2016-11-07 06:30:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=66',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500248:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"8px6027\\"}],\\"styling\\":[],\\"element_id\\":\\"8h63203\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '67',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/white-pearl-soap.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '55',
    '_sale_price' => '45',
    '_price' => '45',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'soap',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/white-pearl-soap.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 62,
  'post_date' => '2016-09-07 07:46:15',
  'post_date_gmt' => '2016-09-07 07:46:15',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio.',
  'post_title' => 'Sunblock Cream',
  'post_excerpt' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat',
  'post_name' => 'sunblock-cream',
  'post_modified' => '2016-11-07 06:30:57',
  'post_modified_gmt' => '2016-11-07 06:30:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=62',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500257:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"wmvz040\\"}],\\"styling\\":[],\\"element_id\\":\\"s4ge400\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '63',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/sunblock.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '35',
    '_price' => '35',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'cream',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/sunblock.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 64,
  'post_date' => '2016-09-06 07:48:56',
  'post_date_gmt' => '2016-09-06 07:48:56',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Whitening Skin Refill Soap',
  'post_excerpt' => 'Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_name' => 'whitening-skin-refill-soap',
  'post_modified' => '2016-11-07 06:31:05',
  'post_modified_gmt' => '2016-11-07 06:31:05',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=64',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500265:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"qywg808\\"}],\\"styling\\":[],\\"element_id\\":\\"bzyu410\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '65',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/skin-whitening-pills.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '78',
    '_price' => '78',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'soap',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/skin-whitening-pills.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 59,
  'post_date' => '2016-09-05 07:43:38',
  'post_date_gmt' => '2016-09-05 07:43:38',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_title' => 'Apple Shampoo',
  'post_excerpt' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?',
  'post_name' => 'apple-shampoo',
  'post_modified' => '2021-04-08 12:31:46',
  'post_modified_gmt' => '2021-04-08 12:31:46',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=59',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500275:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"xpxc705\\"}],\\"styling\\":[],\\"element_id\\":\\"ovb7303\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '60',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/apple-shampoo.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '45',
    '_price' => '45',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '4.9.0',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_tax_status' => 'taxable',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'shampoo',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/apple-shampoo.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 57,
  'post_date' => '2016-09-04 07:39:52',
  'post_date_gmt' => '2016-09-04 07:39:52',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
  'post_title' => 'Night Cream',
  'post_excerpt' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.',
  'post_name' => 'night-cream',
  'post_modified' => '2016-11-07 06:31:23',
  'post_modified_gmt' => '2016-11-07 06:31:23',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=57',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500283:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"j0j1074\\"}],\\"styling\\":[],\\"element_id\\":\\"mpq9300\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '58',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/facial-cream-2.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '25',
    '_price' => '25',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'cream',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/facial-cream-2.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 89,
  'post_date' => '2016-08-04 16:52:56',
  'post_date_gmt' => '2016-08-04 16:52:56',
  'post_content' => '<div>

Deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum.

</div>',
  'post_title' => 'After Bath Skin Treatment Set',
  'post_excerpt' => 'Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum.',
  'post_name' => 'bath-skin-treatment-set',
  'post_modified' => '2016-11-07 06:31:32',
  'post_modified_gmt' => '2016-11-07 06:31:32',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?post_type=product&#038;p=89',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1478500292:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"equal_column_height\\":\\"\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"6l7n609\\"}],\\"styling\\":[],\\"element_id\\":\\"9n5t006\\"}]',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '90',
    'post_image' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/afterbath.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '35',
    '_price' => '35',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '2.6.4',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_tag' => 'cream',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-spa/files/2016/11/afterbath.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 18,
  'post_date' => '2016-11-02 02:42:27',
  'post_date_gmt' => '2016-11-02 02:42:27',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '18',
  'post_modified' => '2016-11-02 02:50:50',
  'post_modified_gmt' => '2016-11-02 02:50:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?p=18',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '6',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 17,
  'post_date' => '2016-11-02 02:42:27',
  'post_date_gmt' => '2016-11-02 02:42:27',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '17',
  'post_modified' => '2016-11-02 02:50:50',
  'post_modified_gmt' => '2016-11-02 02:50:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?p=17',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '8',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 16,
  'post_date' => '2016-11-02 02:42:27',
  'post_date_gmt' => '2016-11-02 02:42:27',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '16',
  'post_modified' => '2016-11-02 02:50:50',
  'post_modified_gmt' => '2016-11-02 02:50:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?p=16',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '10',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 24,
  'post_date' => '2016-11-02 02:50:50',
  'post_date_gmt' => '2016-11-02 02:50:50',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '24',
  'post_modified' => '2016-11-02 02:50:50',
  'post_modified_gmt' => '2016-11-02 02:50:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?p=24',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => 'shop',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 15,
  'post_date' => '2016-11-02 02:42:27',
  'post_date_gmt' => '2016-11-02 02:42:27',
  'post_content' => '',
  'post_title' => 'Contact Us',
  'post_excerpt' => '',
  'post_name' => '15',
  'post_modified' => '2016-11-02 02:50:50',
  'post_modified_gmt' => '2016-11-02 02:50:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-spa/?p=15',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '11',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_woocommerce_products" );
$widgets[1002] = array (
  'title' => 'Recent Products',
  'number' => 5,
  'show' => '',
  'orderby' => 'date',
  'order' => 'desc',
  'hide_free' => 0,
  'show_hidden' => 0,
);
update_option( "widget_woocommerce_products", $widgets );

$widgets = get_option( "widget_woocommerce_price_filter" );
$widgets[1003] = array (
  'title' => 'Filter by price',
);
update_option( "widget_woocommerce_price_filter", $widgets );

$widgets = get_option( "widget_woocommerce_product_tag_cloud" );
$widgets[1004] = array (
  'title' => 'Product Tags',
);
update_option( "widget_woocommerce_product_tag_cloud", $widgets );



$sidebars_widgets = array (
  'sidebar-main' => 
  array (
    0 => 'woocommerce_products-1002',
    1 => 'woocommerce_price_filter-1003',
    2 => 'woocommerce_product_tag_cloud-1004',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-search_post_type' => 'all',
  'setting-webfonts_list' => 'recommended',
  'setting-lazy-blur' => '25',
  'setting-cache-live' => '10080',
  'setting-default_layout' => 'sidebar1',
  'setting-default_post_layout' => 'list-post',
  'setting-post_filter' => 'yes',
  'setting-disable_masonry' => 'yes',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar1',
  'setting-default_page_post_layout_type' => 'classic',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-search-result_layout_display' => 'content',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar1',
  'setting-default_portfolio_index_layout' => 'sidebar-none',
  'setting-default_portfolio_index_post_layout' => 'grid3',
  'setting-portfolio_post_filter' => 'yes',
  'setting-portfolio_disable_masonry' => 'yes',
  'setting-portfolio_gutter' => 'gutter',
  'setting-default_portfolio_index_display' => 'none',
  'setting-default_portfolio_index_post_meta_category' => 'yes',
  'setting-default_portfolio_index_unlink_post_image' => 'yes',
  'setting-default_portfolio_single_layout' => 'sidebar-none',
  'setting-default_portfolio_single_portfolio_layout_type' => 'fullwidth',
  'setting-default_portfolio_single_unlink_post_image' => 'yes',
  'themify_portfolio_slug' => 'project',
  'themify_portfolio_category_slug' => 'portfolio-category',
  'setting-shop_layout' => 'sidebar1',
  'setting-shop_archive_layout' => 'sidebar-none',
  'setting-products_layout' => 'grid4',
  'setting-product_disable_masonry' => 'yes',
  'setting-product_hover_image' => 'on',
  'setting-product_shop_image_size' => 'woocommerce',
  'setting-single_product_layout' => 'sidebar1',
  'setting-product_single_image_size' => 'woocommerce',
  'setting-related_products_limit' => '3',
  'setting-product_description_type' => 'long',
  'setting-cart_show_seconds' => 'off',
  'setting-customizer_responsive_design_tablet_landscape' => '1024',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '480',
  'setting-mobile_menu_trigger_point' => '1200',
  'setting-header_design' => 'header-horizontal',
  'setting-exclude_site_tagline' => 'on',
  'setting-exclude_search_form' => 'on',
  'setting_search_form' => 'live_search',
  'setting-exclude_social_widget' => 'on',
  'setting-header_widgets' => 'none',
  'setting-footer_design' => 'footer-block',
  'setting-exclude_footer_site_logo' => 'on',
  'setting-exclude_footer_menu_navigation' => 'on',
  'setting-use_float_back' => 'on',
  'setting-footer_widgets' => 'footerwidget-1col',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'off',
  'setting-color_animation_speed' => '5',
  'setting-relationship_taxonomy' => 'category',
  'setting-relationship_taxonomy_entries' => '3',
  'setting-relationship_taxonomy_display_content' => 'none',
  'setting-single_slider_autoplay' => 'off',
  'setting-single_slider_speed' => 'normal',
  'setting-single_slider_effect' => 'slide',
  'setting-single_slider_height' => 'auto',
  'setting-more_posts' => 'infinite',
  'setting-entries_nav' => 'numbered',
  'setting-footer_text_left' => '<h3>VISIT US</h3>
128 Main Street, Toronto, ON.',
  'setting-footer_text_right' => '<h3>416-238-3368</h3>',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/ultra-spa/wp-content/themes/themify-ultra/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/ultra-spa/wp-content/themes/themify-ultra/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'Google+',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/ultra-spa/wp-content/themes/themify-ultra/themify/img/social/google-plus.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'YouTube',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/ultra-spa/wp-content/themes/themify-ultra/themify/img/social/youtube.png',
  'setting-link_type_themify-link-4' => 'image-icon',
  'setting-link_title_themify-link-4' => 'Pinterest',
  'setting-link_img_themify-link-4' => 'https://themify.me/demo/themes/ultra-spa/wp-content/themes/themify-ultra/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Twitter',
  'setting-link_ficon_themify-link-5' => 'fa-twitter',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'Facebook',
  'setting-link_ficon_themify-link-6' => 'fa-facebook',
  'setting-link_type_themify-link-7' => 'font-icon',
  'setting-link_title_themify-link-7' => 'Google+',
  'setting-link_ficon_themify-link-7' => 'fa-google-plus',
  'setting-link_type_themify-link-8' => 'font-icon',
  'setting-link_title_themify-link-8' => 'YouTube',
  'setting-link_ficon_themify-link-8' => 'fa-youtube',
  'setting-link_type_themify-link-9' => 'font-icon',
  'setting-link_title_themify-link-9' => 'Pinterest',
  'setting-link_ficon_themify-link-9' => 'fa-pinterest',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4","themify-link-5":"themify-link-5","themify-link-6":"themify-link-6","themify-link-7":"themify-link-7","themify-link-8":"themify-link-8","themify-link-9":"themify-link-9"}',
  'setting-link_field_hash' => '10',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'skin' => 'spa',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'site-logo_image' => '',
  'main_nav_link_color' => '',
  'main_nav_link_hover_color' => '',
  'main_nav_link_active_background' => '',
  'main_nav_link_active_color' => '',
  'main_nav_link_active_hover_color' => '',
  'custom_css_post_id' => -1,
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
