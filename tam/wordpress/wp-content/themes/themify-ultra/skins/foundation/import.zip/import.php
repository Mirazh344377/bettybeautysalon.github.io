<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 4,
  'name' => 'Blog',
  'slug' => 'blog',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 2,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 3,
  'name' => 'Footer Menu',
  'slug' => 'footer-menu',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 5,
  'name' => 'Services',
  'slug' => 'services',
  'term_group' => 0,
  'taxonomy' => 'portfolio-category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 6,
  'name' => 'Uncategorized',
  'slug' => 'uncategorized',
  'term_group' => 0,
  'taxonomy' => 'portfolio-category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 261,
  'post_date' => '2020-05-30 04:56:32',
  'post_date_gmt' => '2020-05-30 04:56:32',
  'post_content' => '<!-- wp:themify-builder/canvas /-->

<!-- wp:paragraph -->
<p>All the countries we are supporting are starting to impose restrictions to slow the spread of the virus.  We have sent relief goods to over a thousand families to help them survive this pandemic. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur</p>
<!-- /wp:paragraph -->',
  'post_title' => 'COVID-19 Response',
  'post_excerpt' => 'All the countries we are supporting are starting to impose restrictions to slow the spread of the virus.  We have sent relief goods to over a thousand families to help them survive this pandemic…',
  'post_name' => 'happiness-for-them',
  'post_modified' => '2020-08-25 05:05:18',
  'post_modified_gmt' => '2020-08-25 05:05:18',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=261',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"unft555\\",\\"cols\\":[{\\"element_id\\":\\"gs9y557\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/orphan-kids.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 259,
  'post_date' => '2020-05-30 04:55:15',
  'post_date_gmt' => '2020-05-30 04:55:15',
  'post_content' => '<!-- wp:paragraph -->
<p>For a lot of communities, access to books is a luxury.  The past month, we held a “give a book for a child” project where we found overwhelmingly generous turnouts.  We have sent over 10,000 books to children and communities</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur</p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Book for kids',
  'post_excerpt' => 'For a lot of communities, access to books is a luxury.  The past month, we held a “give a book for a child” project where we found overwhelmingly generous turnouts.  We have sent over 10,000 books to children and communities….',
  'post_name' => 'book-for-kids',
  'post_modified' => '2020-08-25 05:07:48',
  'post_modified_gmt' => '2020-08-25 05:07:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=259',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"jpoc102\\",\\"cols\\":[{\\"element_id\\":\\"dlc0105\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/book-for-kids.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 256,
  'post_date' => '2020-05-30 04:53:16',
  'post_date_gmt' => '2020-05-30 04:53:16',
  'post_content' => '<!-- wp:themify-builder/canvas /-->

<!-- wp:paragraph -->
<p>Now more than ever, our fight to end poverty needs to be stronger.  United Nations released the 2020 report on Sustainable Development Goals, which reflects a very sobering data</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur</p>
<!-- /wp:paragraph -->',
  'post_title' => 'They need us',
  'post_excerpt' => 'Now more than ever, our fight to end poverty needs to be stronger.  United Nations released the 2020 report on Sustainable Development Goals, which reflects a very sobering data…….',
  'post_name' => 'they-need-us',
  'post_modified' => '2020-08-25 05:07:49',
  'post_modified_gmt' => '2020-08-25 05:07:49',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=256',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"dmbx254\\",\\"cols\\":[{\\"element_id\\":\\"itvp256\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/happy-kids.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 254,
  'post_date' => '2020-05-30 04:52:12',
  'post_date_gmt' => '2020-05-30 04:52:12',
  'post_content' => '<!-- wp:themify-builder/canvas /-->

<!-- wp:paragraph -->
<p>With school shutdowns around the world due to the pandemic, children and their families in poverty are impacted due to the lack of resources to attend classes online</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur</p>
<!-- /wp:paragraph -->',
  'post_title' => 'Education for kids',
  'post_excerpt' => 'With school shutdowns around the world due to the pandemic, children and their families in poverty are impacted due to the lack of resources to attend classes online….',
  'post_name' => 'education-for-kids',
  'post_modified' => '2020-08-25 05:07:51',
  'post_modified_gmt' => '2020-08-25 05:07:51',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=254',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"vrgs55\\",\\"cols\\":[{\\"element_id\\":\\"8iwn57\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/education-for-kids.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 252,
  'post_date' => '2020-05-30 04:50:57',
  'post_date_gmt' => '2020-05-30 04:50:57',
  'post_content' => '<!-- wp:themify-builder/canvas /-->

<!-- wp:paragraph -->
<p>Sharing art for a cause has allowed artists, art organizations and non-artists charities to approach art-based projects.  Last year alone, we have hosted 20 art-fundraising events to help children and their families have access to</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur</p>
<!-- /wp:paragraph -->',
  'post_title' => 'Art in Fundraising',
  'post_excerpt' => 'Sharing art for a cause has allowed artists, art organizations and non-artists charities to approach art-based projects.  Last year alone, we have hosted 20 art-fundraising events to help children and their families have access to….',
  'post_name' => 'art-in-fundraising',
  'post_modified' => '2020-08-25 05:07:53',
  'post_modified_gmt' => '2020-08-25 05:07:53',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=252',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"1p62872\\",\\"cols\\":[{\\"element_id\\":\\"d0sk877\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/kids-paint-contest.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 250,
  'post_date' => '2020-05-30 04:49:48',
  'post_date_gmt' => '2020-05-30 04:49:48',
  'post_content' => '<!-- wp:themify-builder/canvas /-->

<!-- wp:paragraph -->
<p>The past couple of months have been a reality check on a number of things we have taken for granted, and also a reality check on how much communities and families need out help now more than ever</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur</p>
<!-- /wp:paragraph -->',
  'post_title' => 'Volunteer in time of isolation',
  'post_excerpt' => 'The past couple of months have been a reality check on a number of things we have taken for granted, and also a reality check on how much communities and families need out help now more than ever…
',
  'post_name' => 'support-their-freedom',
  'post_modified' => '2020-08-25 05:07:54',
  'post_modified_gmt' => '2020-08-25 05:07:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=250',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"e4mv950\\",\\"cols\\":[{\\"element_id\\":\\"imxz952\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/kids-happy.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 246,
  'post_date' => '2020-05-30 04:48:10',
  'post_date_gmt' => '2020-05-30 04:48:10',
  'post_content' => '<!-- wp:themify-builder/canvas /-->

<!-- wp:paragraph -->
<p>We have shared many stories on how we allocate our resources to helping communities and families escape poverty.  This year alone, we have housed over 100 kids living on the streets with their families, giving them access to water and food</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur</p>
<!-- /wp:paragraph -->',
  'post_title' => 'Donation For Kids on Street',
  'post_excerpt' => 'We have shared many stories on how we allocate our resources to helping communities and families escape poverty.  This year alone, we have housed over 100 kids living on the streets with their families, giving them access to water and food….',
  'post_name' => 'donation-for-kids-on-street',
  'post_modified' => '2020-08-25 05:07:55',
  'post_modified_gmt' => '2020-08-25 05:07:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=246',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"0u1c852\\",\\"cols\\":[{\\"element_id\\":\\"7698854\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/kids-on-street.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 244,
  'post_date' => '2020-05-30 04:46:43',
  'post_date_gmt' => '2020-05-30 04:46:43',
  'post_content' => '<!-- wp:themify-builder/canvas /-->

<!-- wp:paragraph -->
<p>The world has changed for children in the past years, all thanks to your help and your fight to uphold the rights of children.  This year, we have saved 1000 children from abusive homes, human trafficking</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur</p>
<!-- /wp:paragraph -->',
  'post_title' => 'Sharing Happiness',
  'post_excerpt' => 'The world has changed for children in the past years, all thanks to your help and your fight to uphold the rights of children.  This year, we have saved 1000 children from abusive homes, human trafficking….',
  'post_name' => 'sharing-happiness',
  'post_modified' => '2020-08-25 05:07:57',
  'post_modified_gmt' => '2020-08-25 05:07:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=244',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"hqz6951\\",\\"cols\\":[{\\"element_id\\":\\"rp66952\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/people-together.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 242,
  'post_date' => '2020-05-30 04:45:39',
  'post_date_gmt' => '2020-05-30 04:45:39',
  'post_content' => '<!-- wp:themify-builder/canvas /-->

<!-- wp:paragraph -->
<p>In these uncertain and unprecedented times, we hope to spread peace and refuge through the scriptures.  The past month, we have received 500 bible donations to send out to countries who do not have access</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur</p>
<!-- /wp:paragraph -->',
  'post_title' => 'Give the gift of bible',
  'post_excerpt' => 'In these uncertain and unprecedented times, we hope to spread peace and refuge through the scriptures.  The past month, we have received 500 bible donations to send out to countries who do not have access…',
  'post_name' => 'give-the-gift-of-bible',
  'post_modified' => '2020-08-25 05:07:59',
  'post_modified_gmt' => '2020-08-25 05:07:59',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=242',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"y587213\\",\\"cols\\":[{\\"element_id\\":\\"q3jo215\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/reading-bible.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 239,
  'post_date' => '2020-05-30 04:22:09',
  'post_date_gmt' => '2020-05-30 04:22:09',
  'post_content' => '<!-- wp:themify-builder/canvas /-->

<!-- wp:paragraph -->
<p>Nearly 4,000 Canadians came together to bring tangible hope to children and families.   Monetary and physical donations were sent out to 10,000 poor kids all over the world. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur</p>
<!-- /wp:paragraph -->',
  'post_title' => 'Donation for poor kids',
  'post_excerpt' => 'Nearly 4,000 Canadians came together to bring tangible hope to children and families.   Monetary and physical donations were sent out to 10,000 poor kids all over the world...',
  'post_name' => 'donation-for-poor-kids',
  'post_modified' => '2020-08-25 05:07:59',
  'post_modified_gmt' => '2020-08-25 05:07:59',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=239',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"60c6764\\",\\"cols\\":[{\\"element_id\\":\\"lnqs807\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/kids-washing-dish.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 235,
  'post_date' => '2020-05-30 04:19:34',
  'post_date_gmt' => '2020-05-30 04:19:34',
  'post_content' => '<!-- wp:themify-builder/canvas /-->

<!-- wp:paragraph -->
<p>Will you help provide much needed help for refugees? During this time, we need to come together to help refugees survive the pandemic.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur</p>
<!-- /wp:paragraph -->',
  'post_title' => 'Fundraising for child refugee',
  'post_excerpt' => 'Will you help provide much needed help for refugees? During this time, we need to come together to help refugees survive the pandemic...',
  'post_name' => 'fundraising-for-child-refugee',
  'post_modified' => '2020-08-25 05:08:01',
  'post_modified_gmt' => '2020-08-25 05:08:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=235',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"41zg632\\",\\"cols\\":[{\\"element_id\\":\\"1czl635\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/kids-hope.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 84,
  'post_date' => '2020-05-29 11:00:53',
  'post_date_gmt' => '2020-05-29 11:00:53',
  'post_content' => '<!-- wp:themify-builder/canvas /-->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph --><!--themify_builder_static--><h1>About</h1>
<h3>Vision</h3> <p>Our vision is to bring together local and global organizations in the movement to end poverty. </p>
<h3>Mission</h3> <p>Since the 1500, we have been one of the world’s leading organizations in ending poverty. Our mission continues to be to provide aid all over the world to communities and families in poverty.</p>

<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/05/story-560x425.jpg" width="560" title="story" alt="story" srcset="https://themify.me/demo/themes/ultra-foundation/files/2020/05/story.jpg 560w, https://themify.me/demo/themes/ultra-foundation/files/2020/05/story-750x570.jpg 750w, https://themify.me/demo/themes/ultra-foundation/files/2020/05/story-550x418.jpg 550w" sizes="(max-width: 560px) 100vw, 560px" />
<h3>Story</h3> <p>This foundation’s vision for developing children has taken roots in the hearts and minds of a small group of people around the globe as they work together to release communities from poverty. </p> <p>What started as a short mission trip between a group of young people coming together to make a change, this foundation continues to exist as an agency to provide medical, social, psychological and education needs of children and their families. </p>
<h3>Our Impact</h3> <p>Today, thousands of children and their families are discovering lives full of promises - making education, clean water, and opportunities easily accessible. With our global partnership, we have offered financial support to over 15 communities in 9 countries - all thanks to your donations and support.</p> <p>During this time of uncertainty, our efforts to end poverty need to be stronger than ever and so we launch the global movement to reach out even further. We have doubled our efforts in making clean water, food and clothing more accessible to those most at risk during the pandemic. </p>
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/05/our-impact-560x425.jpg" width="560" title="our-impact" alt="our-impact" />

<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/05/about-clean-water.png" alt="Clean Water" /> 
 
 <h3> Clean Water </h3> <p>+3000 People provide with clean water</p>
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/05/about-built-schools.png" alt="Build Schools" /> 
 
 <h3> Build Schools </h3> <p>+100 schools built in this area.</p>
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/05/about-access-education.png" alt="Access to Education" /> 
 
 <h3> Access to Education </h3> <p>+3000 children given access to education</p>
<h2>Our Video</h2> <h5>Through your help and your support, more children and families are given opportunities to live a quality life they deserve.</h5>
<a href="https://www.youtube.com/watch?v=FPPce2D8pYI" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/05/about-video-950x500.png" width="950" height="500" title="about-video" alt="about-video" /> </a>
<h2>Our Partners</h2> <h5>Our Partners in making the world a better place. </h5>
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-a-105x46.jpg" width="105" title="client-logo-a" alt="client-logo-a" />
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-b-84x46.jpg" width="84" title="client-logo-b" alt="client-logo-b" />
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-c-114x46.jpg" width="114" title="client-logo-c" alt="client-logo-c" />
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-d-198x46.jpg" width="198" title="client-logo-d" alt="client-logo-d" />
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-e-135x46.jpg" width="135" title="client-logo-e" alt="client-logo-e" />
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-f-200x46.jpg" width="200" title="client-logo-f" alt="client-logo-f" />
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-g-82x46.jpg" width="82" title="client-logo-g" alt="client-logo-g" />
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-h-103x45.jpg" width="103" title="client-logo-h" alt="client-logo-h" />
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-i-142x46.jpg" width="142" title="client-logo-i" alt="client-logo-i" />
<img src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-j-177x46.jpg" width="177" title="client-logo-j" alt="client-logo-j" /><!--/themify_builder_static-->',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2020-08-23 16:19:48',
  'post_modified_gmt' => '2020-08-23 16:19:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?page_id=84',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"g4i5222\\",\\"cols\\":[{\\"element_id\\":\\"26r7224\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"o844472\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>About<\\\\/h1>\\",\\"font_color_h1\\":\\"#ffffff\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\",\\"font_size_h1_unit\\":\\"px\\",\\"font_size_h1\\":\\"34\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":6.5,\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":6.5,\\"cover_color\\":\\"#000000_0.30\\",\\"cover_color-type\\":\\"color\\",\\"background_color\\":\\"#000000\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/05\\\\/about-bg.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"text_align\\":\\"center\\",\\"hide_anchor\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"12\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"12\\"},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"},\\"breakpoint_tablet_landscape\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"}}},{\\"element_id\\":\\"jx89289\\",\\"cols\\":[{\\"element_id\\":\\"l8qd290\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"4jus529\\",\\"cols\\":[{\\"element_id\\":\\"as81531\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"uxq5108\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Vision<\\\\/h3>\\\\n<p>Our vision is to bring together local and global organizations in the movement to end poverty.  <\\\\/p>\\\\n\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false}}]},{\\"element_id\\":\\"ph65531\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"qkib74\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Mission<\\\\/h3>\\\\n<p>Since the 1500, we have been one of the world’s leading organizations in ending poverty.  Our mission continues to be to provide aid all over the world to communities and families in poverty.<\\\\/p>\\\\n\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false}}]}],\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\"},{\\"element_id\\":\\"vzwf9\\",\\"cols\\":[{\\"element_id\\":\\"frrw10\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"sbhq804\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"1\\",\\"color_divider\\":\\"#f3f3f3\\",\\"divider_width\\":\\"150\\",\\"divider_type\\":\\"fullwidth\\",\\"bottom_margin_divider\\":\\"50\\",\\"top_margin_divider\\":\\"50\\",\\"style_divider\\":\\"solid\\"}}]}]},{\\"element_id\\":\\"s9z5858\\",\\"cols\\":[{\\"element_id\\":\\"hngj859\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"7puj321\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"rounded\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/05\\\\/story.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"margin_bottom_unit\\":\\"%\\",\\"margin_top_unit\\":\\"%\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"3\\",\\"margin_opp_top\\":false,\\"margin_top\\":\\"3\\",\\"width_image\\":\\"560\\"}}]},{\\"element_id\\":\\"84lu859\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"whl6145\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Story<\\\\/h3>\\\\n<p>This foundation’s vision for developing children has taken roots in the hearts and minds of a small group of people around the globe as they work together to release communities from poverty.  <\\\\/p>\\\\n<p>What started as a short mission trip between a group of young people coming together to make a change, this foundation continues to exist as an agency to provide medical, social, psychological and education needs of children and their families.\\\\n<\\\\/p>\\\\n\\",\\"font_color_type\\":\\"font_color_solid\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\"}]}],\\"styling\\":{\\"border-type\\":\\"top\\",\\"border_inner-type\\":\\"top\\",\\"padding_inner_opp_left\\":false,\\"padding_inner_opp_top\\":false,\\"background_position_inner\\":\\"50,50\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_repeat_inner\\":\\"repeat\\",\\"cover_color-type\\":\\"color\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_top\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":8,\\"hide_anchor\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\",\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\"},\\"breakpoint_tablet_landscape\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"}}},{\\"element_id\\":\\"fw81380\\",\\"cols\\":[{\\"element_id\\":\\"7vkn382\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"y9x0387\\",\\"cols\\":[{\\"element_id\\":\\"gwu0388\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"5kma389\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Our Impact<\\\\/h3>\\\\n<p>Today, thousands of children and their families are discovering lives full of promises - making education, clean water, and opportunities easily accessible.  With our global partnership, we have offered financial support to over 15 communities in 9 countries - all thanks to your donations and support.<\\\\/p>\\\\n<p>During this time of uncertainty, our efforts to end poverty need to be stronger than ever and so we launch the global movement to reach out even further.  We have doubled our efforts in making clean water, food and clothing more accessible to those most at risk during the pandemic.\\\\n<\\\\/p>\\\\n\\",\\"font_color_type\\":\\"font_color_solid\\"}}]},{\\"element_id\\":\\"sbpe388\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"casm388\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"rounded\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/05\\\\/our-impact-560x425.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"margin_bottom_unit\\":\\"%\\",\\"margin_top_unit\\":\\"%\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"3\\",\\"margin_opp_top\\":false,\\"margin_top\\":\\"3\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_bottom\\":false,\\"width_image\\":\\"560\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\"},{\\"element_id\\":\\"ipqp386\\",\\"cols\\":[{\\"element_id\\":\\"gver386\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"8e6l387\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"1\\",\\"color_divider\\":\\"#dddddd\\",\\"divider_width\\":\\"150\\",\\"divider_type\\":\\"fullwidth\\",\\"bottom_margin_divider\\":\\"50\\",\\"top_margin_divider\\":\\"50\\",\\"style_divider\\":\\"solid\\"}}]}]},{\\"element_id\\":\\"8e91126\\",\\"cols\\":[{\\"element_id\\":\\"s7nr127\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"z23j500\\",\\"mod_settings\\":{\\"title_feature\\":\\"Clean Water\\",\\"circle_percentage_feature\\":\\"100\\",\\"circle_stroke_feature\\":\\"0\\",\\"icon_feature\\":\\"fa-home\\",\\"layout_feature\\":\\"icon-top\\",\\"circle_size_feature\\":\\"small\\",\\"icon_type_feature\\":\\"image_icon\\",\\"link_options\\":\\"regular\\",\\"feature_download_link\\":false,\\"icon_bg_feature\\":\\"#3bdadc\\",\\"icon_color_feature\\":\\"#ffffff\\",\\"content_feature\\":\\"<p>+3000 People provide with clean water<\\\\/p>\\",\\"image_feature\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/05\\\\/about-clean-water.png\\"}}]},{\\"element_id\\":\\"5uyd88\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"a4en546\\",\\"mod_settings\\":{\\"title_feature\\":\\"Build Schools\\",\\"circle_percentage_feature\\":\\"100\\",\\"circle_stroke_feature\\":\\"0\\",\\"icon_feature\\":\\"fa-home\\",\\"layout_feature\\":\\"icon-top\\",\\"circle_size_feature\\":\\"small\\",\\"icon_type_feature\\":\\"image_icon\\",\\"link_options\\":\\"regular\\",\\"feature_download_link\\":false,\\"icon_bg_feature\\":\\"#3bdadc\\",\\"icon_color_feature\\":\\"#ffffff\\",\\"content_feature\\":\\"<p>+100 schools built in this area.<\\\\/p>\\",\\"image_feature\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/05\\\\/about-built-schools.png\\"}}]},{\\"element_id\\":\\"warl89\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"o331228\\",\\"mod_settings\\":{\\"title_feature\\":\\"Access to Education\\",\\"circle_percentage_feature\\":\\"100\\",\\"circle_stroke_feature\\":\\"0\\",\\"icon_feature\\":\\"fa-home\\",\\"layout_feature\\":\\"icon-top\\",\\"circle_size_feature\\":\\"small\\",\\"icon_type_feature\\":\\"image_icon\\",\\"link_options\\":\\"regular\\",\\"feature_download_link\\":false,\\"icon_bg_feature\\":\\"#3bdadc\\",\\"icon_color_feature\\":\\"#ffffff\\",\\"content_feature\\":\\"<p>+3000 children given access to education<\\\\/p>\\",\\"image_feature\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/05\\\\/about-access-education.png\\"}}]}],\\"col_tablet_landscape\\":\\"column3-1\\",\\"col_tablet\\":\\"column3-1\\",\\"col_mobile\\":\\"column-full\\"}]}],\\"styling\\":{\\"border-type\\":\\"top\\",\\"border_inner_bottom_width\\":\\"1\\",\\"border_inner_bottom_color\\":\\"#f3f3f3\\",\\"border_inner-type\\":\\"bottom\\",\\"padding_inner_opp_left\\":false,\\"padding_inner_opp_top\\":false,\\"background_position_inner\\":\\"50,50\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_repeat_inner\\":\\"repeat\\",\\"cover_color-type\\":\\"color\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_top\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"background_color\\":\\"#f3f3f3\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"breakpoint_mobile\\":{\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\"},\\"breakpoint_tablet\\":{\\"padding_top\\":10,\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":10,\\"padding_bottom_unit\\":\\"%\\"},\\"breakpoint_tablet_landscape\\":{\\"padding_top\\":7,\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":8,\\"padding_bottom_unit\\":\\"%\\"}}},{\\"element_id\\":\\"1x0o528\\",\\"cols\\":[{\\"element_id\\":\\"hgf1530\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"o3y3115\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Video<\\\\/h2>\\\\n<h5>Through your help and your support, more children and families are given opportunities to live a quality life they deserve.<\\\\/h5>\\\\n\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_bottom\\":\\"20\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"xccy982\\",\\"mod_settings\\":{\\"image_zoom_icon\\":\\"zoom\\",\\"param_image\\":\\"lightbox\\",\\"link_image\\":\\"https:\\\\/\\\\/www.youtube.com\\\\/watch?v=FPPce2D8pYI\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"rounded\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/05\\\\/about-video-950x500.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"90\\",\\"margin_opp_top\\":false,\\"width_image\\":\\"950\\",\\"height_image\\":\\"500\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"6m49530\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Partners<\\\\/h2>\\\\n<h5>Our Partners in making the world a better place.  <\\\\/h5>\\\\n\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"90\\",\\"margin_opp_top\\":false,\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"40\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"50\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet_landscape\\":{\\"margin_bottom\\":63,\\"margin_bottom_unit\\":\\"px\\"}}},{\\"element_id\\":\\"6rrh181\\",\\"cols\\":[{\\"element_id\\":\\"lvu8182\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"xl55182\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-a-105x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"width_image\\":\\"105\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"}}},{\\"element_id\\":\\"xeom183\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"l9pc183\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-b-84x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"84\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"}}},{\\"element_id\\":\\"pawq183\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"s170184\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-c-114x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"114\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"}}},{\\"element_id\\":\\"v75u184\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"xyxm184\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-d-198x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"198\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"}}},{\\"element_id\\":\\"ffju185\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"8yv9185\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-e-135x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"135\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"},\\"breakpoint_tablet_landscape\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_top_style\\":\\"solid\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column5-1\\",\\"col_tablet\\":\\"column5-1\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"none\\",\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"none\\",\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"}}},{\\"element_id\\":\\"cxhi213\\",\\"cols\\":[{\\"element_id\\":\\"pu8q214\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"td0f214\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-f-200x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"200\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"none\\",\\"border-type\\":\\"top\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"}}},{\\"element_id\\":\\"88c3214\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"g8le214\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-g-82x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"82\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"none\\",\\"border-type\\":\\"top\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"}}},{\\"element_id\\":\\"txgs215\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"5sgh215\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-h-103x45.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"103\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"none\\",\\"border-type\\":\\"top\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"}}},{\\"element_id\\":\\"kxt8215\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"yt0w215\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-i-142x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"142\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"none\\",\\"border-type\\":\\"top\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"}}},{\\"element_id\\":\\"xjwr215\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"4f9k215\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-j-177x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"177\\"}}],\\"styling\\":{\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"none\\",\\"border-type\\":\\"top\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"breakpoint_tablet_landscape\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_opp_left\\":false,\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_opp_bottom\\":false,\\"b_ra_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_top_style\\":\\"solid\\"}}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column5-1\\",\\"col_tablet\\":\\"column5-1\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"top\\"},\\"breakpoint_tablet\\":{\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_opp_left\\":false,\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_opp_bottom\\":false,\\"b_ra_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"top\\"}}}],\\"styling\\":{\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\"}}}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"hide_anchor\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"breakpoint_mobile\\":{\\"padding_bottom\\":10,\\"padding_bottom_unit\\":\\"%\\",\\"padding_top\\":10,\\"padding_top_unit\\":\\"%\\"},\\"breakpoint_tablet\\":{\\"padding_bottom\\":\\"7\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false},\\"breakpoint_tablet_landscape\\":{\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top\\":\\"8\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false}}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 192,
  'post_date' => '2020-05-29 13:23:50',
  'post_date_gmt' => '2020-05-29 13:23:50',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Contact Us</h1>
<h3>Make a Change</h3> <p>For information on how to volunteer and how to donate, please make sure to refer to our FAQ page to see if we’ve already answered your question. Otherwise, please send us an email at <a href="mailto:hello@foundation.com">hello@foundation.com</a></p>
<h3>Our Info</h3> <p>Office Hours: Monday to Friday 8:00 am to 5:00pm (Eastern)</p> <p>Mailing Address:<br /><i>1234 Street, Toronto ON</i></p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/05/map-1160x600.jpg" width="1160" height="600" title="map" alt="map" srcset="https://themify.me/demo/themes/ultra-foundation/files/2020/05/map.jpg 1160w, https://themify.me/demo/themes/ultra-foundation/files/2020/05/map-600x310.jpg 600w, https://themify.me/demo/themes/ultra-foundation/files/2020/05/map-768x397.jpg 768w" sizes="(max-width: 1160px) 100vw, 1160px" />
<h4>Send a Message</h4>
<form action="https://themify.me/demo/themes/ultra-foundation/wp-admin/admin-ajax.php" class="builder-contact" id="tb_cibr691-form" method="post" data-post-id="0" data-element-id="cibr691" data-orig-id="" > <label for="tb_cibr691-contact-name">First Name *</label> <input type="text" name="contact-name" placeholder=" " id="tb_cibr691-contact-name" value="" required> First Name * <label for="tb_cibr691-contact-email">Email *</label> <input type="text" name="contact-email" placeholder=" " id="tb_cibr691-contact-email" value="" required> Email * <label for="tb_cibr691-contact-subject">Subject *</label> <input type="text" name="contact-subject" placeholder=" " id="tb_cibr691-contact-subject" value="" required> Subject * <label for="tb_cibr691-contact-message">Message *</label> <textarea name="contact-message" placeholder=" " id="tb_cibr691-contact-message" required></textarea> Message * <button type="submit">Send Message</button> </form>
<h4>Visit Our Office</h4>
<em><svg aria-hidden="true"><use href="#tf-ti-direction"></use></svg></em> 2091 Mission St.<br> San Francisco, CA 94110
<h4>Phone</h4>
<em><svg aria-hidden="true"><use href="#tf-fas-phone"></use></svg></em> +(23)123-4556 <em><svg aria-hidden="true"><use href="#tf-fas-fax"></use></svg></em> +(23)123-1234
<h4>Email</h4>
<a href="hello@foundation.com"> <em><svg aria-hidden="true"><use href="#tf-far-envelope"></use></svg></em> hello@foundation.com </a><!--/themify_builder_static-->',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2021-12-24 09:44:42',
  'post_modified_gmt' => '2021-12-24 09:44:42',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?page_id=192',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"1g0y557\\",\\"cols\\":[{\\"element_id\\":\\"jqi4558\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ydcp554\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Contact Us<\\\\/h1>\\",\\"font_size_h1\\":\\"34\\",\\"font_color_h1\\":\\"#ffffff\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"6.5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"6.5\\",\\"text_align\\":\\"center\\",\\"background_color\\":\\"#000000\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/05\\\\/contact-bg.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"},\\"breakpoint_tablet_landscape\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"}}},{\\"element_id\\":\\"cw5q272\\",\\"cols\\":[{\\"element_id\\":\\"4hgl272\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"ne2v273\\",\\"cols\\":[{\\"element_id\\":\\"hr3d273\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"77x1274\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Make a Change<\\\\/h3>\\\\n<p>For information on how to volunteer and how to donate, please make sure to refer to our FAQ page to see if we’ve already answered your question. Otherwise, please send us an email at <a href=\\\\\\"mailto:hello@foundation.com\\\\\\">hello@foundation.com<\\\\/a><\\\\/p>\\"}}]},{\\"element_id\\":\\"0ri2275\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"0vxh276\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Our Info<\\\\/h3>\\\\n<p>Office Hours: Monday to Friday 8:00 am to 5:00pm (Eastern)<\\\\/p>\\\\n<p>Mailing Address:<br \\\\/><i>1234 Street, Toronto ON<\\\\/i><\\\\/p>\\\\n\\",\\"breakpoint_mobile\\":{\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"26\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}}]}],\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\"}]}],\\"styling\\":{\\"border-type\\":\\"top\\",\\"border_inner-type\\":\\"top\\",\\"padding_inner_opp_left\\":false,\\"padding_inner_opp_top\\":false,\\"background_position_inner\\":\\"50,50\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_repeat_inner\\":\\"repeat\\",\\"cover_color-type\\":\\"color\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"12\\",\\"background_color\\":\\"#f3f3f3\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"18\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"},\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"22\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"},\\"breakpoint_tablet_landscape\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"12\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"6\\"}}},{\\"element_id\\":\\"qrtw681\\",\\"cols\\":[{\\"element_id\\":\\"zd60683\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"kx9y693\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/05\\\\/map.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"margin_top\\":\\"-110\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"-20\\"},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"-15\\"},\\"breakpoint_tablet_landscape\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"-10\\"},\\"width_image\\":\\"1160\\",\\"height_image\\":\\"600\\",\\"border-type\\":\\"left\\"}}]}]},{\\"element_id\\":\\"kj9f861\\",\\"cols\\":[{\\"element_id\\":\\"3d99862\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"sn5b179\\",\\"cols\\":[{\\"element_id\\":\\"2k22179\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"6xep860\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Send a Message<\\\\/h4>\\",\\"text_transform_h4\\":\\"none\\",\\"letter_spacing_h4\\":\\"0\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}},{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"cibr691\\",\\"mod_settings\\":{\\"field_name_label\\":\\"First Name\\",\\"field_email_label\\":\\"Email\\",\\"field_subject_label\\":\\"Subject\\",\\"field_message_label\\":\\"Message\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_sendcopy_subject\\":\\"COPY:\\",\\"field_send_label\\":\\"Send Message\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"field_name_require\\":\\"yes\\",\\"field_email_require\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_email_active\\":\\"yes\\",\\"field_subject_active\\":\\"yes\\",\\"field_subject_require\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_extra\\":\\"{\\\\\\"fields\\\\\\":[]}\\",\\"field_order\\":\\"{\\\\\\"field_name_label\\\\\\":0,\\\\\\"field_email_label\\\\\\":1,\\\\\\"field_subject_label\\\\\\":2,\\\\\\"field_message_label\\\\\\":3}\\",\\"field_optin_label\\":\\"Subscribe to my newsletter.\\",\\"field_optin_active\\":false,\\"provider\\":\\"mailchimp\\",\\"field_sendcopy_active\\":false,\\"field_captcha_active\\":false,\\"include_name_mail\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"user_role\\":\\"admin\\",\\"send_to_admins\\":\\"true\\",\\"layout_contact\\":\\"animated-label\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"%\\",\\"margin_bottom\\":\\"5\\",\\"margin_opp_top\\":false}}}]},{\\"element_id\\":\\"xg8z180\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"s9fs539\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Visit Our Office<\\\\/h4>\\",\\"text_transform_h4\\":\\"none\\",\\"letter_spacing_h4\\":\\"0\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"n0m9732\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon\\":\\"ti-direction\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"2091 Mission St.<br> San Francisco, CA 94110\\",\\"link_options\\":\\"regular\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"font_color_icon\\":\\"#00b964\\",\\"margin_bottom\\":\\"40\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"r9f2417\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Phone<\\\\/h4>\\",\\"text_transform_h4\\":\\"none\\",\\"letter_spacing_h4\\":\\"0\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"noux708\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon\\":\\"fas fa-phone\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"+(23)123-4556\\",\\"link_options\\":\\"regular\\"},{\\"icon\\":\\"fas fa-fax\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"+(23)123-1234\\",\\"link_options\\":\\"regular\\"}],\\"icon_arrangement\\":\\"icon_vertical\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"font_color_icon\\":\\"#00b964\\",\\"margin_bottom\\":\\"40\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"j5kc609\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Email<\\\\/h4>\\",\\"text_transform_h4\\":\\"none\\",\\"letter_spacing_h4\\":\\"0\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"trss391\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon\\":\\"far fa-envelope\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"hello@foundation.com\\",\\"link\\":\\"hello@foundation.com\\",\\"link_options\\":\\"regular\\"}],\\"icon_arrangement\\":\\"icon_vertical\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"font_color_icon\\":\\"#00b964\\"}}],\\"styling\\":{\\"border_left_width\\":\\"1\\",\\"border_left_color\\":\\"#f3f3f3\\",\\"border-type\\":\\"left\\",\\"padding_left\\":\\"30\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_left_width\\":\\"0\\",\\"border_left_color\\":\\"#f2f2f2_0.00\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border_top_width\\":\\"1\\",\\"border_top_color\\":\\"#f3f3f3\\",\\"border-type\\":\\"top\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_left\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"40\\"}}}],\\"col_tablet_landscape\\":\\"column3-2-3-1\\",\\"col_tablet\\":\\"column3-2-3-1\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false}}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":7,\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":7,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"},\\"breakpoint_tablet_landscape\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"7\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"7\\"}}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 340,
  'post_date' => '2020-07-10 04:30:38',
  'post_date_gmt' => '2020-07-10 04:30:38',
  'post_content' => '[give_receipt]',
  'post_title' => 'Donation Confirmation',
  'post_excerpt' => '',
  'post_name' => 'donation-confirmation',
  'post_modified' => '2020-07-10 04:30:38',
  'post_modified_gmt' => '2020-07-10 04:30:38',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/donation-confirmation/',
  'menu_order' => 0,
  'post_type' => 'page',
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 341,
  'post_date' => '2020-07-10 04:30:38',
  'post_date_gmt' => '2020-07-10 04:30:38',
  'post_content' => 'We&#039;re sorry, your donation failed to process. Please try again or contact site support.',
  'post_title' => 'Donation Failed',
  'post_excerpt' => '',
  'post_name' => 'donation-failed',
  'post_modified' => '2020-07-10 04:30:38',
  'post_modified_gmt' => '2020-07-10 04:30:38',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/donation-failed/',
  'menu_order' => 0,
  'post_type' => 'page',
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 342,
  'post_date' => '2020-07-10 04:30:38',
  'post_date_gmt' => '2020-07-10 04:30:38',
  'post_content' => '[donation_history]',
  'post_title' => 'Donation History',
  'post_excerpt' => '',
  'post_name' => 'donation-history',
  'post_modified' => '2020-07-10 04:30:38',
  'post_modified_gmt' => '2020-07-10 04:30:38',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/donation-history/',
  'menu_order' => 0,
  'post_type' => 'page',
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 642,
  'post_date' => '2021-09-27 02:34:31',
  'post_date_gmt' => '2021-09-27 02:34:31',
  'post_content' => '<!-- wp:give/donor-dashboard {"align":"wide"} /-->',
  'post_title' => 'Donor Dashboard',
  'post_excerpt' => '',
  'post_name' => 'donor-dashboard',
  'post_modified' => '2021-09-27 02:34:31',
  'post_modified_gmt' => '2021-09-27 02:34:31',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/donor-dashboard/',
  'menu_order' => 0,
  'post_type' => 'page',
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 8,
  'post_date' => '2020-03-12 12:55:35',
  'post_date_gmt' => '2020-03-12 12:55:35',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Fundraising for the people and causes you care about</h1>
<a href="https://themify.me/" >
 Start Donate
 </a>
<h2>About us</h2>
<h3>Founded in the 1500, this Foundation connects you to hundreds of organizations as allies to end poverty in the lives of children and their families. Providing communities all over the world with the quality life they deserve.</h3>
<p>Everything we do is designed to meet specific needs of the community and the individual families in need.  Together, as one, we rise to protect the most vulnerable and provide for those in desperate needs of basic necessities.</p>
<a href="https://themify.me/" >
 Read More
 <i><svg><use href="#tf-ti-arrow-right"></use></svg></i> </a>
<p>This foundation has a vision of creating a better world - partnering with global and local organizations to widen our reach in releasing more families and communities from poverty.</p>
<h2>Our Impact</h2> <p>Today, thousands of children and their families are discovering lives full of promises - making education, clean water, and opportunities easily accessible. With our global partnership, we have offered financial support to over 15 communities in 9 countries - all thanks to your donations and support.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/clean-water-icon-110x110.png" width="110" height="110" title="+3000 People provide with clean water" alt="+3000 People provide with clean water"> 
 
 
 
 
 <h3>
 +3000 People provide with clean water </h3>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/education-icon-110x110.png" width="110" height="110" title="+3000 children given access to education" alt="+3000 children given access to education"> 
 
 
 
 
 <h3>
 +3000 children given access to education </h3>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/school-icon-110x110.png" width="110" height="110" title="+100 schools built in this area." alt="+100 schools built in this area."> 
 
 
 
 
 <h3>
 +100 schools built in this area. </h3>
<h2>Our Impact</h2>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/donate-icon-94x98.png" width="94" height="98" title="Donate" alt="to find a cure"> 
 
 
 
 
 <h3>
 Donate </h3>
 
 
 to find a cure
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/sponsors-86x98.png" width="86" height="98" title="Sponsor" alt="a Participant"> 
 
 
 
 
 <h3>
 Sponsor </h3>
 
 
 a Participant
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/register-icon-107x98.png" width="107" height="98" title="Register" alt="for a join"> 
 
 
 
 
 <h3>
 Register </h3>
 
 
 for a join
<h2>Our Progress</h2> <h3>We continue to raise funds in the global movement of generosity to help communities and families survive the pandemic.</h3>
<h2>740+</h2> <h3>Homes Funded</h3> <p>Your generosity and our group of volunteers has allowed us to build over 740 houses in 15 communities. </p>
<h2>500+</h2> <h3>People Housed</h3> <p>Children and their families have been saved and taken off the streets to be housed.</p>
<h2>9</h2> <h3>Countries</h3> <p>Through global partnerships, we\'re able to provide communities with the quality life they deserve</p>
<h2>Our Progress</h2>
<h2>Projects through People</h2> <h3>Working hand-in-hand to make a better world for our future generations to come, from one person to another.</h3>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/sains-robot-360x235.jpg" width="360" height="235" title="Education support for Children within their community" alt="With your financial support, we can send hundreds of children to school allowing them access to more opportunities."> 
 
 
 
 
 <h3>
 Education support for Children within their community </h3>
 
 
 With your financial support, we can send hundreds of children to school allowing them access to more opportunities.
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/children-360x235.jpg" width="360" height="235" title="Give to your Sponsored Child and their Families" alt="Sometimes you want to go beyond the “basics” to give your sponsored family additional opportunity and support."> 
 
 
 
 
 <h3>
 Give to your Sponsored Child and their Families </h3>
 
 
 Sometimes you want to go beyond the “basics” to give your sponsored family additional opportunity and support.
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/people-360x235.jpg" width="360" height="235" title="Volunteer Opportunities! Enrich the lives of the community" alt="There are a number of ways you can volunteer with Foundation. Be a part of the change!"> 
 
 
 
 
 <h3>
 Volunteer Opportunities! Enrich the lives of the community </h3>
 
 
 There are a number of ways you can volunteer with Foundation. Be a part of the change!
<h3>Join a global movement</h3> <p>In the midst of the pandemic, hundreds of children and their families lost access to their basic needs. With your generosity, we can help these communities survive the pandemic. Your support will give them access to food, clean water, clothing and masks.</p>
[give_form id="343"]

<h2>Our Partners</h2> <h3>Our Partners in making the world a better place. </h3>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-a-105x46.jpg" width="105" height="46" title="client-logo-a" alt="client-logo-a">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-b-84x46.jpg" width="84" height="46" title="client-logo-b" alt="client-logo-b">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-c-114x46.jpg" width="114" height="46" title="client-logo-c" alt="client-logo-c">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-d-198x46.jpg" width="198" height="46" title="client-logo-d" alt="client-logo-d">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-e-135x46.jpg" width="135" height="46" title="client-logo-e" alt="client-logo-e">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-f-200x46.jpg" width="200" height="46" title="client-logo-f" alt="client-logo-f">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-g-82x46.jpg" width="82" height="46" title="client-logo-g" alt="client-logo-g">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-h-103x45.jpg" width="103" height="45" title="client-logo-h" alt="client-logo-h">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-i-142x46.jpg" width="142" height="46" title="client-logo-i" alt="client-logo-i">
<img loading="lazy" src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/client-logo-j-177x46.jpg" width="177" height="46" title="client-logo-j" alt="client-logo-j"><!--/themify_builder_static-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2020-11-11 21:59:08',
  'post_modified_gmt' => '2020-11-11 21:59:08',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?page_id=8',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    'mobile_menu_styles' => 'default',
    'header_wrap' => 'transparent',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"zvgn471\\",\\"cols\\":[{\\"element_id\\":\\"nwp7472\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"0nya724\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Fundraising for the people and causes you care about<\\\\/h1>\\",\\"padding_bottom\\":45,\\"padding_bottom_unit\\":\\"px\\",\\"breakpoint_mobile\\":{\\"h1_margin_bottom_unit\\":\\"px\\",\\"h1_margin_top_unit\\":\\"px\\",\\"t_shh1_blur_unit\\":\\"px\\",\\"t_shh1_vShadow_unit\\":\\"px\\",\\"t_shh1_hShadow_unit\\":\\"px\\",\\"letter_spacing_h1_unit\\":\\"px\\",\\"line_height_h1_unit\\":\\"px\\",\\"font_size_h1_unit\\":\\"px\\",\\"font_size_h1\\":\\"36\\",\\"font_gradient_color_h1-circle-radial\\":false,\\"font_gradient_color_h1-gradient-angle\\":\\"180\\",\\"font_gradient_color_h1-gradient-type\\":\\"linear\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"klnu814\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Start Donate\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"green\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"squared\\",\\"buttons_size\\":\\"normal\\",\\"checkbox_l_b_r_c_apply_all\\":\\"1\\",\\"l_b_r_c_left_unit\\":\\"px\\",\\"l_b_r_c_opp_left\\":false,\\"l_b_r_c_right_unit\\":\\"px\\",\\"l_b_r_c_bottom_unit\\":\\"px\\",\\"l_b_r_c_opp_bottom\\":false,\\"l_b_r_c_top_unit\\":\\"px\\",\\"l_b_r_c_top\\":\\"5\\",\\"checkbox_padding_link_apply_all\\":false,\\"padding_link_left_unit\\":\\"px\\",\\"padding_link_left\\":\\"25\\",\\"padding_link_opp_left\\":\\"1\\",\\"padding_link_bottom_unit\\":\\"px\\",\\"padding_link_bottom\\":\\"15\\",\\"padding_link_right_unit\\":\\"px\\",\\"padding_link_right\\":\\"25\\",\\"padding_link_opp_top\\":\\"1\\",\\"padding_link_top_unit\\":\\"px\\",\\"padding_link_top\\":\\"15\\",\\"b_p\\":\\"50,50\\",\\"b_r\\":\\"repeat\\",\\"button_background_color\\":\\"#00b964\\",\\"b_i-circle-radial\\":false,\\"b_i-gradient-angle\\":\\"180\\",\\"b_i-gradient-type\\":\\"linear\\",\\"b_i-type\\":\\"image\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_opp_left\\":false,\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_opp_bottom\\":false,\\"b_ra_top_unit\\":\\"px\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}]},{\\"element_id\\":\\"ew9l487\\",\\"grid_class\\":\\"col4-2\\"}],\\"col_tablet_landscape\\":\\"column3-2-3-1\\",\\"col_tablet\\":\\"column3-2-3-1\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"250\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"250\\",\\"background_position\\":\\"50,100\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/homepage-hero-banner.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"font_color\\":\\"#ffffff\\",\\"hide_anchor\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_bottom\\":\\"150\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"150\\"},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"15\\"}}},{\\"element_id\\":\\"xn35642\\",\\"cols\\":[{\\"element_id\\":\\"7lrg645\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ehqo167\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>About us<\\\\/h2>\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"letter_spacing_h2\\":\\"-6\\",\\"font_size_h2_unit\\":\\"em\\",\\"font_size_h2\\":\\"10\\",\\"font_color_h2\\":\\"#e5e5e5\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":-14,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"-4\\",\\"font_style_h2_regular\\":\\"normal\\",\\"font_family_h2_w\\":\\"900\\",\\"font_family_h2\\":\\"Lato\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"font_style_h2_regular\\":\\"normal\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"letter_spacing_h2\\":\\"-3\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"em\\",\\"font_size_h2\\":\\"4.5\\",\\"font_color_h2\\":\\"#e5e5e5\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"font_family_h2_w\\":\\"900\\",\\"font_family_h2\\":\\"Lato\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"-4\\"},\\"breakpoint_tablet\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"font_style_h2_regular\\":\\"normal\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"letter_spacing_h2\\":\\"-6\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"em\\",\\"font_size_h2\\":\\"6\\",\\"font_color_h2\\":\\"#e5e5e5\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"font_family_h2_w\\":\\"900\\",\\"font_family_h2\\":\\"Lato\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"0\\"},\\"breakpoint_tablet_landscape\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"font_style_h2_regular\\":\\"normal\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"letter_spacing_h2\\":\\"-6\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"em\\",\\"font_size_h2\\":\\"8\\",\\"font_color_h2\\":\\"#e5e5e5\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"font_family_h2_w\\":\\"900\\",\\"font_family_h2\\":\\"Lato\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"0\\"}}},{\\"element_id\\":\\"hyxq586\\",\\"cols\\":[{\\"element_id\\":\\"l20r592\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"2g08621\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Founded in the 1500, this Foundation connects you to hundreds of organizations as allies to end poverty in the lives of children and their families.  Providing communities all over the world with the quality life they deserve.<\\\\/h3>\\\\n\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_top\\":\\"5\\",\\"padding_right_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_right\\":\\"15\\",\\"padding_opp_top\\":false,\\"breakpoint_mobile\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"26\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"},\\"breakpoint_tablet\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"28\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}}]},{\\"element_id\\":\\"17r1594\\",\\"grid_class\\":\\"col3-1\\"}],\\"col_tablet_landscape\\":\\"column3-2-3-1\\",\\"col_tablet\\":\\"column-full\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"30\\",\\"margin_opp_top\\":false}},{\\"element_id\\":\\"9rdl343\\",\\"cols\\":[{\\"element_id\\":\\"nlz1344\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"q9o2934\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Everything we do is designed to meet specific needs of the community and the individual families in need.  Together, as one, we rise to protect the most vulnerable and provide for those in desperate needs of basic necessities.<\\\\/p>\\",\\"padding_bottom\\":20,\\"padding_bottom_unit\\":\\"px\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"jzpb629\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Read More\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_alignment\\":\\"right\\",\\"button_color_bg\\":\\"tb_default_color\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"squared\\",\\"buttons_size\\":\\"normal\\",\\"checkbox_l_b_r_c_apply_all\\":\\"1\\",\\"l_b_r_c_left_unit\\":\\"px\\",\\"l_b_r_c_opp_left\\":false,\\"l_b_r_c_right_unit\\":\\"px\\",\\"l_b_r_c_bottom_unit\\":\\"px\\",\\"l_b_r_c_opp_bottom\\":false,\\"l_b_r_c_top_unit\\":\\"px\\",\\"l_b_r_c_top\\":\\"5\\",\\"checkbox_padding_link_apply_all\\":false,\\"padding_link_left_unit\\":\\"px\\",\\"padding_link_left\\":\\"35\\",\\"padding_link_opp_left\\":\\"1\\",\\"padding_link_bottom_unit\\":\\"px\\",\\"padding_link_bottom\\":\\"15\\",\\"padding_link_right_unit\\":\\"px\\",\\"padding_link_right\\":\\"35\\",\\"padding_link_opp_top\\":\\"1\\",\\"padding_link_top_unit\\":\\"px\\",\\"padding_link_top\\":\\"15\\",\\"b_p\\":\\"50,50\\",\\"b_r\\":\\"repeat\\",\\"button_background_color\\":\\"#ffffff\\",\\"b_i-circle-radial\\":false,\\"b_i-gradient-angle\\":\\"180\\",\\"b_i-gradient-type\\":\\"linear\\",\\"b_i-type\\":\\"image\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_opp_left\\":false,\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_opp_bottom\\":false,\\"b_ra_top_unit\\":\\"px\\",\\"bic_b_p_h\\":\\"50,50\\",\\"bic_b_r_h\\":\\"repeat\\",\\"bic_b_i_h-circle-radial\\":false,\\"bic_b_i_h-gradient-angle\\":\\"180\\",\\"bic_b_i_h-gradient-type\\":\\"linear\\",\\"bic_b_i_h-type\\":\\"image\\",\\"bic_b_p\\":\\"50,50\\",\\"bic_b_r\\":\\"repeat\\",\\"bic_b_i-circle-radial\\":false,\\"bic_b_i-gradient-angle\\":\\"180\\",\\"bic_b_i-gradient-type\\":\\"linear\\",\\"bic_b_i-type\\":\\"image\\",\\"l_b_sh_inset\\":false,\\"l_b_sh_color\\":\\"#000000_0.05\\",\\"l_b_sh_spread_unit\\":\\"px\\",\\"l_b_sh_spread\\":\\"3\\",\\"l_b_sh_blur_unit\\":\\"px\\",\\"l_b_sh_blur\\":\\"10\\",\\"l_b_sh_vOffset_unit\\":\\"px\\",\\"l_b_sh_vOffset\\":\\"0\\",\\"l_b_sh_hOffset_unit\\":\\"px\\",\\"l_b_sh_hOffset\\":\\"0\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"}}}],\\"styling\\":{\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"},\\"breakpoint_tablet_landscape\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"}}},{\\"element_id\\":\\"8tm8116\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"sdaq118\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>This foundation has a vision of creating a better world - partnering with global and local organizations to widen our reach in releasing more families and communities from poverty.<\\\\/p>\\\\n\\"}}],\\"styling\\":{\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"},\\"breakpoint_tablet_landscape\\":{\\"padding_left\\":\\"0\\",\\"padding_left_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"}}}],\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column4-2\\"}]}],\\"styling\\":{\\"background_color\\":\\"#f3f3f3\\",\\"background_position\\":\\"0,0\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_top\\":0,\\"padding_opp_left\\":false,\\"padding_bottom\\":64,\\"padding_opp_top\\":false,\\"hide_anchor\\":false,\\"row_width\\":\\"fullwidth\\",\\"margin-bottom\\":-62,\\"margin-bottom_unit\\":\\"px\\",\\"padding_bottom_unit\\":\\"px\\",\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-bottom\\":\\"0\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\"}}},{\\"element_id\\":\\"7nhs721\\",\\"cols\\":[{\\"element_id\\":\\"ye9x723\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"r9x4159\\",\\"cols\\":[{\\"element_id\\":\\"dxes159\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"2mtb682\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Impact<\\\\/h2>\\\\n<p>Today, thousands of children and their families are discovering lives full of promises - making education, clean water, and opportunities easily accessible.  With our global partnership, we have offered financial support to over 15 communities in 9 countries - all thanks to your donations and support.<\\\\/p>\\\\n\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"}}}],\\"styling\\":{\\"margin-top_opp_top\\":false}},{\\"element_id\\":\\"4gwz160\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3t90179\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"+3000 People provide  with clean water\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/clean-water-icon-110x110.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_bottom\\":\\"40\\",\\"i_t_m_opp_top\\":false,\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_bottom\\":false,\\"b_ra_top\\":\\"5\\",\\"border-type\\":\\"top\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":20,\\"padding_right\\":\\"10\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":20,\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_color\\":\\"#629bfd\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"title_margin_opp_left\\":false,\\"title_margin_opp_top\\":false,\\"font_size_title_unit\\":\\"px\\",\\"font_size_title\\":\\"22\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.09\\",\\"b_sh_spread_unit\\":\\"px\\",\\"b_sh_spread\\":\\"5\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"10\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"0\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"0\\",\\"ht_auto_height\\":false,\\"width_image\\":\\"110\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"t_sh_t_blur_unit\\":\\"px\\",\\"t_sh_t_vShadow_unit\\":\\"px\\",\\"t_sh_t_hShadow_unit\\":\\"px\\",\\"letter_spacing_title_unit\\":\\"px\\",\\"line_height_title_unit\\":\\"px\\",\\"font_color_title\\":\\"#ffffff\\"}}]},{\\"element_id\\":\\"9399160\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"btzc660\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"+3000 children given access to education\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/education-icon-110x110.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_bottom\\":\\"40\\",\\"i_t_m_opp_top\\":false,\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_bottom\\":false,\\"b_ra_top\\":\\"5\\",\\"border-type\\":\\"top\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"20\\",\\"padding_right\\":\\"10\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"20\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_color\\":\\"#00b964\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"title_margin_opp_left\\":false,\\"title_margin_opp_top\\":false,\\"font_size_title_unit\\":\\"px\\",\\"font_size_title\\":\\"22\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"30\\",\\"margin_opp_top\\":false,\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.09\\",\\"b_sh_spread_unit\\":\\"px\\",\\"b_sh_spread\\":\\"5\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"10\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"0\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"0\\",\\"width_image\\":\\"110\\",\\"font_color_title\\":\\"#ffffff\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"4ly4149\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"+100  schools built in this area.\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/school-icon-110x110.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_bottom\\":\\"40\\",\\"i_t_m_opp_top\\":false,\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_bottom\\":false,\\"b_ra_top\\":\\"5\\",\\"border-type\\":\\"top\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"20\\",\\"padding_right\\":\\"10\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"20\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_color\\":\\"#3bdadc\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"title_margin_opp_left\\":false,\\"title_margin_opp_top\\":false,\\"font_size_title_unit\\":\\"px\\",\\"font_size_title\\":\\"22\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.09\\",\\"b_sh_spread_unit\\":\\"px\\",\\"b_sh_spread\\":\\"5\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"10\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"0\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"0\\",\\"width_image\\":\\"110\\",\\"custom_parallax_scroll_zindex\\":\\"3\\",\\"font_color_title\\":\\"#ffffff\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_tablet_landscape\\":\\"column3-1\\",\\"col_tablet\\":\\"column3-1\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"}}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"l051657\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Impact<\\\\/h2>\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"letter_spacing_h2\\":\\"-6\\",\\"font_size_h2_unit\\":\\"em\\",\\"font_size_h2\\":\\"10\\",\\"font_color_h2\\":\\"#f7f7f7\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":-14,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"font_style_h2_regular\\":\\"normal\\",\\"font_family_h2_w\\":\\"900\\",\\"font_family_h2\\":\\"Lato\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_bottom\\":\\"30\\",\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":-19,\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"font_style_h2_regular\\":\\"normal\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"letter_spacing_h2\\":\\"0\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"em\\",\\"font_size_h2\\":\\"3.5\\",\\"font_color_h2\\":\\"#e5e5e5\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"font_family_h2_w\\":\\"900\\",\\"font_family_h2\\":\\"Lato\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"margin_top\\":\\"20\\",\\"margin_bottom\\":\\"30\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"},\\"breakpoint_tablet\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"font_style_h2_regular\\":\\"normal\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"letter_spacing_h2\\":\\"-6\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"em\\",\\"font_size_h2\\":\\"5.6\\",\\"font_color_h2\\":\\"#f7f7f7\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"font_family_h2_w\\":\\"900\\",\\"font_family_h2\\":\\"Lato\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"-28\\",\\"margin_bottom\\":\\"30\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"},\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"breakpoint_tablet_landscape\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"font_style_h2_regular\\":\\"normal\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"letter_spacing_h2\\":\\"-6\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"em\\",\\"font_size_h2\\":\\"9\\",\\"font_color_h2\\":\\"#f7f7f7\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"font_family_h2_w\\":\\"900\\",\\"font_family_h2\\":\\"Lato\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"-19\\"}}}]}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"10\\",\\"padding_opp_top\\":false,\\"background_position\\":\\"0,100\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"hide_anchor\\":false,\\"margin-top_opp_top\\":false,\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"}}},{\\"element_id\\":\\"coze751\\",\\"cols\\":[{\\"element_id\\":\\"c3cx751\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"k5eg883\\",\\"mod_settings\\":{\\"caption_image\\":\\"to find a cure\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Donate\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/donate-icon-94x98.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-left\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_bottom\\":false,\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"global_styles\\":\\"tb_gs335e6\\",\\"height_image\\":\\"98\\",\\"width_image\\":\\"94\\"}}],\\"styling\\":{\\"breakpoint_mobile\\":{\\"padding_bottom\\":\\"30\\",\\"padding_bottom_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"}}},{\\"element_id\\":\\"oxq3589\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"327f590\\",\\"mod_settings\\":{\\"caption_image\\":\\"a Participant\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Sponsor\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/sponsors-86x98.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-left\\",\\"global_styles\\":\\"tb_gs335e6\\",\\"height_image\\":\\"98\\",\\"width_image\\":\\"86\\"}}],\\"styling\\":{\\"breakpoint_mobile\\":{\\"padding_bottom\\":\\"30\\",\\"padding_bottom_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"}}},{\\"element_id\\":\\"cvrz686\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"1n9j96\\",\\"mod_settings\\":{\\"caption_image\\":\\"for a join\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Register\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/register-icon-107x98.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-left\\",\\"global_styles\\":\\"tb_gs335e6\\",\\"height_image\\":\\"98\\",\\"width_image\\":\\"107\\"}}]}],\\"col_tablet_landscape\\":\\"column3-1\\",\\"col_tablet\\":\\"column3-1\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_top\\":152,\\"padding_opp_left\\":false,\\"padding_bottom\\":152,\\"padding_opp_top\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/involve-bg-banner.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_top_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":\\"-3\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"15\\"},\\"hide_anchor\\":false,\\"breakpoint_tablet\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":\\"-3\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"15\\"}}},{\\"element_id\\":\\"zhrz375\\",\\"cols\\":[{\\"element_id\\":\\"3etk376\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"jp1e235\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Progress<\\\\/h2>\\\\n<h3>We continue to raise funds in the global movement of generosity to help communities and families survive the pandemic.<\\\\/h3>\\\\n\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"90\\",\\"margin_opp_top\\":false,\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"24\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"50\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"28\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}}},{\\"element_id\\":\\"gcrq864\\",\\"cols\\":[{\\"element_id\\":\\"oolb865\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"cxvp334\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>740+<\\\\/h2>\\\\n<h3>Homes Funded<\\\\/h3>\\\\n<p>Your generosity and our group of volunteers has allowed us to build over 740 houses in 15 communities. <\\\\/p>\\",\\"font_color_h3\\":\\"#00b964\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"10\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"50\\",\\"font_color_h2\\":\\"#00b964\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"breakpoint_mobile\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_h3\\":\\"#00b964\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"10\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"40\\",\\"font_color_h2\\":\\"#00b964\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"},\\"breakpoint_tablet\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"28\\",\\"font_color_h3\\":\\"#00b964\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"10\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"40\\",\\"font_color_h2\\":\\"#00b964\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#dddddd\\",\\"border-type\\":\\"right\\",\\"padding_right_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_right\\":\\"5\\",\\"padding_opp_top\\":false,\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#dddddd\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"}}},{\\"element_id\\":\\"prlz342\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"zjc1344\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>500+<\\\\/h2>\\\\n<h3>People Housed<\\\\/h3>\\\\n<p>Children and their families have been saved and taken off the streets to be housed.<\\\\/p>\\",\\"font_color_h3\\":\\"#00b964\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"10\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"50\\",\\"font_color_h2\\":\\"#00b964\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"breakpoint_mobile\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_h3\\":\\"#00b964\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"10\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"40\\",\\"font_color_h2\\":\\"#00b964\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"},\\"breakpoint_tablet\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"28\\",\\"font_color_h3\\":\\"#00b964\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"10\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"40\\",\\"font_color_h2\\":\\"#00b964\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#dddddd\\",\\"border-type\\":\\"right\\",\\"padding_right_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_right\\":\\"5\\",\\"padding_opp_top\\":false,\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#dddddd\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"}}},{\\"element_id\\":\\"qlsm695\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"gi7i696\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>9<\\\\/h2>\\\\n<h3>Countries<\\\\/h3>\\\\n<p>Through global partnerships, we\\\'re able to provide communities with the quality life they deserve<\\\\/p>\\\\n\\",\\"border-type\\":\\"top\\",\\"font_color_h3\\":\\"#00b964\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"10\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"50\\",\\"font_color_h2\\":\\"#00b964\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"breakpoint_mobile\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_h3\\":\\"#00b964\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"10\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"40\\",\\"font_color_h2\\":\\"#00b964\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"},\\"breakpoint_tablet\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"28\\",\\"font_color_h3\\":\\"#00b964\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"10\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"40\\",\\"font_color_h2\\":\\"#00b964\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}}],\\"styling\\":{\\"border-type\\":\\"right\\",\\"padding_right_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_right\\":\\"5\\",\\"padding_opp_top\\":false,\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#dddddd\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#dddddd\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"}}}],\\"col_tablet_landscape\\":\\"column3-1\\",\\"col_tablet\\":\\"column3-1\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"}}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"vfh4496\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Progress<\\\\/h2>\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"letter_spacing_h2\\":\\"-6\\",\\"font_size_h2_unit\\":\\"em\\",\\"font_size_h2\\":\\"10\\",\\"font_color_h2\\":\\"#f7f7f7\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":-14,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"font_style_h2_regular\\":\\"normal\\",\\"font_family_h2_w\\":\\"900\\",\\"font_family_h2\\":\\"Lato\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"-4\\",\\"padding_top\\":19,\\"padding_top_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"em\\",\\"line_height_h2\\":\\"1\\",\\"margin_bottom\\":\\"30\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"font_style_h2_regular\\":\\"normal\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"letter_spacing_h2\\":\\"0\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"em\\",\\"font_size_h2\\":\\"3\\",\\"font_color_h2\\":\\"#e5e5e5\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"font_family_h2_w\\":\\"900\\",\\"font_family_h2\\":\\"Lato\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"margin_top\\":\\"20\\",\\"margin_bottom\\":\\"30\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"20\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"line_height_h2\\":\\"1\\"},\\"breakpoint_tablet\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_bottom\\":\\"0\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"font_style_h2_regular\\":\\"normal\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"letter_spacing_h2\\":\\"-6\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"em\\",\\"font_size_h2\\":\\"5.6\\",\\"font_color_h2\\":\\"#f7f7f7\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"font_family_h2_w\\":\\"900\\",\\"font_family_h2\\":\\"Lato\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"0\\",\\"margin_bottom\\":\\"0\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"},\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"breakpoint_tablet_landscape\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"0\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"0\\"}}}],\\"styling\\":{\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"},\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\"}}}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"0\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"7\\",\\"background_position\\":\\"0,100\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"15\\"},\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"hide_anchor\\":false,\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"2\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"},\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\"}},{\\"element_id\\":\\"65ja839\\",\\"cols\\":[{\\"element_id\\":\\"qb36841\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"picj426\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Projects through People<\\\\/h2>\\\\n<h3>Working hand-in-hand to make a better world for our future generations to come, from one person to another.<\\\\/h3>\\\\n\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"90\\",\\"margin_opp_top\\":false,\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"24\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"50\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"28\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}}},{\\"element_id\\":\\"ggru743\\",\\"cols\\":[{\\"element_id\\":\\"2a9x744\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"y3o2826\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/sains-robot-360x235.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"caption_image\\":\\"With your financial support, we can send hundreds of children to school allowing them access to more opportunities.\\",\\"title_image\\":\\"Education support for Children within their community\\",\\"width_image\\":\\"360\\",\\"c_p_left\\":\\"30\\",\\"c_p_opp_left\\":\\"1\\",\\"c_p_bottom\\":\\"20\\",\\"c_p_right\\":\\"30\\",\\"c_p_opp_top\\":\\"1\\",\\"c_p_top\\":\\"20\\",\\"i_t_p_opp_left\\":false,\\"i_t_p_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_bottom\\":false,\\"i_t_r_c_opp_left\\":false,\\"i_t_r_c_right\\":\\"10\\",\\"i_t_r_c_opp_bottom\\":false,\\"i_t_r_c_top\\":\\"10\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"title_margin_opp_left\\":false,\\"title_margin_opp_top\\":false,\\"font_color_title\\":\\"#00b964\\"}}],\\"styling\\":{\\"background_color\\":\\"#ffffff\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_bottom\\":false,\\"b_ra_left\\":\\"10\\",\\"b_ra_right\\":\\"10\\",\\"b_ra_bottom\\":\\"10\\",\\"b_ra_top\\":\\"10\\",\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-bottom\\":\\"30\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\"},\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.03\\",\\"b_sh_spread_unit\\":\\"px\\",\\"b_sh_spread\\":\\"5\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"10\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"0\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"0\\"}},{\\"element_id\\":\\"s50r934\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"75ii935\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/children-360x235.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"caption_image\\":\\"Sometimes you want to go beyond the “basics” to give your sponsored family additional opportunity and support.\\",\\"title_image\\":\\"Give to your Sponsored Child and their Families\\",\\"width_image\\":\\"360\\",\\"c_p_left\\":\\"30\\",\\"c_p_opp_left\\":\\"1\\",\\"c_p_bottom\\":\\"20\\",\\"c_p_right\\":\\"30\\",\\"c_p_opp_top\\":\\"1\\",\\"c_p_top\\":\\"20\\",\\"i_t_p_opp_left\\":false,\\"i_t_p_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"i_t_r_c_right\\":\\"10\\",\\"i_t_r_c_top\\":\\"10\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_bottom\\":false,\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"font_color_title\\":\\"#00b964\\"}}],\\"styling\\":{\\"background_color\\":\\"#ffffff\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_bottom\\":false,\\"b_ra_left\\":\\"10\\",\\"b_ra_right\\":\\"10\\",\\"b_ra_bottom\\":\\"10\\",\\"b_ra_top\\":\\"10\\",\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-bottom\\":\\"30\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\"},\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.03\\",\\"b_sh_spread_unit\\":\\"px\\",\\"b_sh_spread\\":\\"5\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"10\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"0\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"0\\"}},{\\"element_id\\":\\"lmvx837\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"oj9r837\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/people-360x235.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"caption_image\\":\\"There are a number of ways you can volunteer with Foundation.  Be a part of the change!\\",\\"title_image\\":\\"Volunteer Opportunities! Enrich the lives of the community\\",\\"width_image\\":\\"360\\",\\"c_p_left\\":\\"30\\",\\"c_p_opp_left\\":\\"1\\",\\"c_p_bottom\\":\\"20\\",\\"c_p_right\\":\\"30\\",\\"c_p_opp_top\\":\\"1\\",\\"c_p_top\\":\\"20\\",\\"i_t_p_opp_left\\":false,\\"i_t_p_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"i_t_r_c_right\\":\\"10\\",\\"i_t_r_c_top\\":\\"10\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_bottom\\":false,\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"font_color_title\\":\\"#00b964\\"}}],\\"styling\\":{\\"background_color\\":\\"#ffffff\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"b_ra_left\\":\\"10\\",\\"b_ra_opp_left\\":false,\\"b_ra_right\\":\\"10\\",\\"b_ra_bottom\\":\\"10\\",\\"b_ra_opp_bottom\\":false,\\"r_c_opp_left\\":false,\\"r_c_opp_bottom\\":false,\\"b_ra_top\\":\\"10\\",\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-bottom\\":\\"30\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\"},\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.03\\",\\"b_sh_spread_unit\\":\\"px\\",\\"b_sh_spread\\":\\"5\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"10\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"0\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"0\\"}}],\\"col_tablet_landscape\\":\\"column3-1\\",\\"col_tablet\\":\\"column3-1\\",\\"col_mobile\\":\\"column-full\\"}]}],\\"styling\\":{\\"background_color\\":\\"#f3f3f3\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_top\\":130,\\"hide_anchor\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"100\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"15\\"},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"}}},{\\"element_id\\":\\"kj56742\\",\\"cols\\":[{\\"element_id\\":\\"egpy744\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"p2uo476\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Join a global movement<\\\\/h3>\\\\n<p>In the midst of the pandemic, hundreds of children and their families lost access to their basic needs.  With your generosity, we can help these communities survive the pandemic.  Your support will give them access to food, clean water, clothing and masks.<\\\\/p>\\\\n\\",\\"font_color\\":\\"#ffffff\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"}}}],\\"styling\\":{\\"breakpoint_tablet\\":{\\"padding_bottom\\":24,\\"padding_bottom_unit\\":\\"px\\"}}},{\\"element_id\\":\\"n29z651\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"plain-text\\",\\"element_id\\":\\"ow8b736\\",\\"mod_settings\\":{\\"plain_text\\":\\"[give_form id=\\\\\\"343\\\\\\"]\\\\n\\\\n<style>\\\\n.give-form-wrap:after{\\\\n\\\\tcontent:\\\\\\"\\\\\\";\\\\n\\\\tclear:both;\\\\n\\\\tdisplay:block\\\\n}\\\\n[id*=give-form] .give-form-title{\\\\n\\\\tfont-size:1.7em;\\\\n\\\\tletter-spacing:0.015em;\\\\n\\\\tmax-width:73%;\\\\n\\\\tmargin:auto;\\\\n\\\\tpadding-top:45px\\\\n}\\\\n.give-goal-progress{\\\\n\\\\tmax-width:73%;\\\\n\\\\tmargin:0 auto 30px\\\\n}\\\\n.give-goal-progress .raised{\\\\n\\\\tfont-style:italic;\\\\n\\\\tmargin-bottom:5px\\\\n}\\\\n.give-goal-progress .income,\\\\n.give-goal-progress .goal-text{\\\\n\\\\tfont-size:85%;\\\\n\\\\tletter-spacing:-0.02em\\\\n}\\\\n.give-progress-bar{\\\\n\\\\tbackground-color:#cef5e3;\\\\n\\\\tborder-radius:0;\\\\n\\\\theight:10px;\\\\n}\\\\n.give-progress-bar>span{\\\\n\\\\tborder-radius:0\\\\n}\\\\nform[id*=give-form]{\\\\n\\\\tbackground-color:#f3f3f3;\\\\n\\\\tpadding-top:20px;\\\\n\\\\tpadding-bottom:20px\\\\n}\\\\nform[id*=give-form] .give-donation-amount{\\\\n\\\\tborder-bottom:1px solid #ddd;\\\\n\\\\tmax-width:73%;\\\\n\\\\tmargin:0 auto 35px\\\\n}\\\\nform[id*=give-form] .give-donation-amount .give-currency-symbol.give-currency-position-before{\\\\n\\\\tborder:none;\\\\n\\\\tbackground-color:transparent;\\\\n\\\\tpadding:0;\\\\n}\\\\nform[id*=give-form] .give-donation-amount #give-amount{\\\\n\\\\tborder:none;\\\\n\\\\tbackground-color:transparent;\\\\n\\\\tpadding-left:3px\\\\n}\\\\nform[id*=give-form] #give-donation-level-radio-list{\\\\n\\\\tdisplay:flex;\\\\n\\\\tflex-wrap:wrap;\\\\n\\\\tmax-width:73%;\\\\n\\\\tmargin:0 auto 15px\\\\n}\\\\nform[id*=give-form] #give-donation-level-radio-list li{\\\\n\\\\tdisplay:flex;\\\\n\\\\talign-items:center;\\\\n\\\\tmargin-right:10px;\\\\n}\\\\nform[id*=give-form] #give-donation-level-radio-list li:last-child{\\\\n\\\\tdisplay:none\\\\n}\\\\n[id*=give-form].give-display-modal .give-btn{\\\\n\\\\tdisplay:block;\\\\n\\\\twidth:100%;\\\\n\\\\tmax-width:73%;\\\\n\\\\tmargin:60px auto;\\\\n\\\\ttext-transform:none;\\\\n\\\\tbackground-color:#20a166;\\\\n\\\\tcolor:#fff;\\\\n\\\\tfont-weight:normal;\\\\n\\\\tfont-size:24px;\\\\n\\\\tletter-spacing:-0.01em;\\\\n\\\\tpadding:19px;\\\\n\\\\tborder:none;\\\\n\\\\tborder-radius:5px;\\\\n\\\\tfloat:left;\\\\n\\\\tposition:relative;\\\\n\\\\tleft:50%;\\\\n\\\\ttransform:translateX(-50%);\\\\n\\\\toutline:none;\\\\n}\\\\n<\\\\/style>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_bottom\\":false,\\"b_ra_top\\":\\"5\\",\\"border-type\\":\\"top\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_color\\":\\"#ffffff\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\"}},{\\"mod_name\\":\\"plain-text\\",\\"element_id\\":\\"utef151\\"}],\\"styling\\":{\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_bottom\\":false,\\"b_ra_top\\":\\"8\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"3\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"3\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"3\\",\\"padding_right\\":\\"3\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column-full\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_top\\":130,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"100\\",\\"padding_opp_top\\":false,\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/bg-donation-row.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_top_unit\\":\\"px\\",\\"hide_anchor\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"15\\"},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"15\\"},\\"row_anchor\\":\\"donate\\"}},{\\"element_id\\":\\"oi38989\\",\\"cols\\":[{\\"element_id\\":\\"1hue990\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"cl06455\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Partners<\\\\/h2>\\\\n<h3>Our Partners in making the world a better place. <\\\\/h3>\\\\n\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":10,\\"margin_opp_top\\":false,\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"24\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"50\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"28\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"10\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"},\\"margin_bottom_unit\\":\\"px\\"}},{\\"element_id\\":\\"g4h3538\\",\\"cols\\":[{\\"element_id\\":\\"taoj542\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"vyme916\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-a-105x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"width_image\\":\\"105\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"}}},{\\"element_id\\":\\"1pzm553\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"47ba554\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-b-84x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"84\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"}}},{\\"element_id\\":\\"22iw894\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"2me5894\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-c-114x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"114\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"}}},{\\"element_id\\":\\"k7x9967\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ez2q967\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-d-198x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"198\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"}}},{\\"element_id\\":\\"ybr2704\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ct7y704\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-e-135x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"135\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"},\\"breakpoint_tablet_landscape\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_top_style\\":\\"solid\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column5-1\\",\\"col_tablet\\":\\"column5-1\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"none\\",\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"none\\",\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"bottom\\"}}},{\\"element_id\\":\\"5nfz796\\",\\"cols\\":[{\\"element_id\\":\\"pa3w415\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"dscl415\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-f-200x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"200\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"none\\",\\"border-type\\":\\"top\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"}}},{\\"element_id\\":\\"wxqy926\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"j18k927\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-g-82x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"82\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"none\\",\\"border-type\\":\\"top\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"}}},{\\"element_id\\":\\"enz3642\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"8u8w644\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-h-103x45.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"103\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"none\\",\\"border-type\\":\\"top\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"}}},{\\"element_id\\":\\"98n2999\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"jy7k999\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-i-142x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"142\\"}}],\\"styling\\":{\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"none\\",\\"border-type\\":\\"top\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"}}},{\\"element_id\\":\\"znjg815\\",\\"grid_class\\":\\"col5-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"9e6z815\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/client-logo-j-177x46.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"177\\"}}],\\"styling\\":{\\"border-type\\":\\"right\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"none\\",\\"border-type\\":\\"top\\"},\\"breakpoint_tablet\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"breakpoint_tablet_landscape\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#e5e5e5\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_opp_left\\":false,\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_opp_bottom\\":false,\\"b_ra_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"none\\",\\"border_top_style\\":\\"solid\\"}}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column5-1\\",\\"col_tablet\\":\\"column5-1\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"top\\"},\\"breakpoint_tablet\\":{\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_opp_left\\":false,\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_opp_bottom\\":false,\\"b_ra_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"top\\"}}}],\\"styling\\":{\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"}}}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_bottom\\":9,\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":9,\\"hide_anchor\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"15\\"},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"},\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"breakpoint_tablet_landscape\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"9\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"9\\"}}}]',
    'themify_used_global_styles' => 
    array (
      0 => 'tb_gs335e6',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 182,
  'post_date' => '2020-05-29 13:16:38',
  'post_date_gmt' => '2020-05-29 13:16:38',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>News</h1>

<h2>Search</h2><form method="get" id="searchform" action="https://themify.me/demo/themes/ultra-foundation/">
 
 <input type="text" name="s" id="s" title="Search" placeholder="Search" value="" />
 </form>
<h2>Latest Posts</h2><ul><li><a aria-hidden="true" href="https://themify.me/demo/themes/ultra-foundation/2020/05/30/happiness-for-them/"><img src="https://themify.me/demo/themes/ultra-foundation/files/2020/05/orphan-kids-86x86.jpg" width="86" height="86" title="orphan-kids" alt="orphan-kids" srcset="https://themify.me/demo/themes/ultra-foundation/files/2020/05/orphan-kids-86x86.jpg 86w, https://themify.me/demo/themes/ultra-foundation/files/2020/05/orphan-kids-150x150.jpg 150w" sizes="(max-width: 86px) 100vw, 86px" /></a><a href="https://themify.me/demo/themes/ultra-foundation/2020/05/30/happiness-for-them/">Happiness for them</a> <br /><small>May 30, 2020</small> <br /></li><li><a aria-hidden="true" href="https://themify.me/demo/themes/ultra-foundation/2020/05/30/book-for-kids/"><img src="https://themify.me/demo/themes/ultra-foundation/files/2020/05/book-for-kids-86x86.jpg" width="86" height="86" title="book-for-kids" alt="book-for-kids" srcset="https://themify.me/demo/themes/ultra-foundation/files/2020/05/book-for-kids-86x86.jpg 86w, https://themify.me/demo/themes/ultra-foundation/files/2020/05/book-for-kids-150x150.jpg 150w" sizes="(max-width: 86px) 100vw, 86px" /></a><a href="https://themify.me/demo/themes/ultra-foundation/2020/05/30/book-for-kids/">Book for kids</a> <br /><small>May 30, 2020</small> <br /></li><li><a aria-hidden="true" href="https://themify.me/demo/themes/ultra-foundation/2020/05/30/they-need-us/"><img src="https://themify.me/demo/themes/ultra-foundation/files/2020/05/happy-kids-86x86.jpg" width="86" height="86" title="happy-kids" alt="happy-kids" srcset="https://themify.me/demo/themes/ultra-foundation/files/2020/05/happy-kids-86x86.jpg 86w, https://themify.me/demo/themes/ultra-foundation/files/2020/05/happy-kids-150x150.jpg 150w" sizes="(max-width: 86px) 100vw, 86px" /></a><a href="https://themify.me/demo/themes/ultra-foundation/2020/05/30/they-need-us/">They need us</a> <br /><small>May 30, 2020</small> <br /></li></ul><!--/themify_builder_static-->',
  'post_title' => 'News',
  'post_excerpt' => '',
  'post_name' => 'news',
  'post_modified' => '2020-07-14 14:52:08',
  'post_modified_gmt' => '2020-07-14 14:52:08',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?page_id=182',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"xr8z398\\",\\"cols\\":[{\\"element_id\\":\\"wvi0400\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"bsmg900\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>News<\\\\/h1>\\",\\"font_size_h1_unit\\":\\"px\\",\\"font_size_h1\\":\\"34\\",\\"font_color_h1\\":\\"#ffffff\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6.5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"6.5\\",\\"text_align\\":\\"center\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/05\\\\/news-bg.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"hide_anchor\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"},\\"breakpoint_tablet_landscape\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"}}},{\\"element_id\\":\\"r4a9657\\",\\"cols\\":[{\\"element_id\\":\\"3k0c657\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"amky426\\",\\"cols\\":[{\\"element_id\\":\\"d8o1426\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"post\\",\\"element_id\\":\\"down577\\",\\"mod_settings\\":{\\"layout_post\\":\\"grid2\\",\\"post_per_page_post\\":\\"6\\",\\"display_post\\":\\"excerpt\\",\\"hide_page_nav_post\\":\\"no\\",\\"post_type_post\\":\\"post\\",\\"hide_post_meta_post\\":\\"no\\",\\"hide_post_date_post\\":\\"no\\",\\"unlink_post_title_post\\":\\"no\\",\\"hide_post_title_post\\":\\"no\\",\\"unlink_feat_img_post\\":\\"no\\",\\"auto_fullwidth_post\\":false,\\"hide_feat_img_post\\":\\"no\\",\\"orderby_post\\":\\"date\\",\\"order_post\\":\\"desc\\",\\"post_filter\\":\\"no\\",\\"category_post\\":\\"0|single\\",\\"term_type\\":\\"category\\",\\"type_query_post\\":\\"category\\",\\"disable_masonry\\":\\"no\\",\\"m_f_i_left\\":\\"-25\\",\\"m_f_i_opp_left\\":\\"1\\",\\"m_f_i_right\\":\\"-25\\",\\"m_f_i_opp_top\\":false,\\"border-type\\":\\"all\\",\\"padding_left\\":\\"25\\",\\"padding_opp_left\\":\\"1\\",\\"padding_right\\":\\"25\\",\\"padding_opp_top\\":false,\\"m_pg_c_opp_left\\":false,\\"m_pg_c_opp_top\\":false,\\"p_pg_c_opp_left\\":false,\\"p_pg_c_opp_top\\":false,\\"general_border-type\\":\\"top\\",\\"sticky_post\\":\\"no\\",\\"f_i_r_c_opp_left\\":false,\\"f_i_r_c_right\\":\\"8\\",\\"f_i_r_c_opp_bottom\\":false,\\"f_i_r_c_top\\":\\"08\\",\\"sh_cn_inset\\":false,\\"sh_cn_color\\":\\"#000000_0.05\\",\\"sh_cn_spread_unit\\":\\"px\\",\\"sh_cn_spread\\":\\"5\\",\\"sh_cn_blur_unit\\":\\"px\\",\\"sh_cn_blur\\":\\"10\\",\\"sh_cn_vOffset_unit\\":\\"px\\",\\"sh_cn_vOffset\\":\\"0\\",\\"sh_cn_hOffset_unit\\":\\"px\\",\\"sh_cn_hOffset\\":\\"0\\",\\"r_c_cn_left\\":\\"8\\",\\"r_c_cn_opp_left\\":false,\\"r_c_cn_right\\":\\"8\\",\\"r_c_cn_bottom\\":\\"8\\",\\"r_c_cn_opp_bottom\\":false,\\"r_c_cn_top\\":\\"8\\",\\"background_color\\":\\"#ffffff\\",\\"article_margin_bottom_unit\\":\\"px\\",\\"article_margin_bottom\\":\\"30\\"}}]},{\\"element_id\\":\\"mirs427\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"widget\\",\\"element_id\\":\\"wufq350\\",\\"mod_settings\\":{\\"instance_widget\\":{\\"title\\":\\"Search\\",\\"widget-id\\":\\"1590758363\\"},\\"class_widget\\":\\"WP_Widget_Search\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"40\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"}},{\\"mod_name\\":\\"widget\\",\\"element_id\\":\\"18ky491\\",\\"mod_settings\\":{\\"instance_widget\\":{\\"title\\":\\"Latest Posts\\",\\"category\\":\\"0\\",\\"show_count\\":\\"3\\",\\"show_date\\":\\"on\\",\\"show_thumb\\":\\"on\\",\\"display\\":\\"none\\",\\"thumb_width\\":\\"86\\",\\"thumb_height\\":\\"86\\",\\"excerpt_length\\":\\"0\\",\\"read_more_text\\":\\"Read more\\",\\"orderby\\":\\"date\\",\\"order\\":\\"DESC\\",\\"widget-id\\":\\"1590844857\\"},\\"class_widget\\":\\"Themify_Feature_Posts\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"40\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"}}]}],\\"col_tablet_landscape\\":\\"column3-2-3-1\\",\\"col_tablet\\":\\"column3-2-3-1\\"}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"hide_anchor\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"},\\"breakpoint_tablet_landscape\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"7\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"7\\"}}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 271,
  'post_date' => '2020-05-30 10:14:28',
  'post_date_gmt' => '2020-05-30 10:14:28',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Project</h1>
<!--/themify_builder_static-->',
  'post_title' => 'Portfolio',
  'post_excerpt' => '',
  'post_name' => 'portfolio',
  'post_modified' => '2020-07-15 03:26:16',
  'post_modified_gmt' => '2020-07-15 03:26:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?page_id=271',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"c8ad254\\",\\"cols\\":[{\\"element_id\\":\\"gwdp255\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"h70n962\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Project<\\\\/h1>\\",\\"font_color_h1\\":\\"#ffffff\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"6\\",\\"text_align\\":\\"center\\",\\"background_color\\":\\"#000000\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/05\\\\/project-bg.jpg\\"}},{\\"element_id\\":\\"6igi436\\",\\"cols\\":[{\\"element_id\\":\\"xjjg438\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"portfolio\\",\\"element_id\\":\\"u9pp719\\",\\"mod_settings\\":{\\"post_per_page_portfolio\\":\\"9\\",\\"hide_page_nav_portfolio\\":\\"no\\",\\"display_portfolio\\":\\"excerpt\\",\\"hide_post_meta_portfolio\\":\\"yes\\",\\"hide_post_date_portfolio\\":\\"yes\\",\\"unlink_post_title_portfolio\\":\\"no\\",\\"hide_post_title_portfolio\\":\\"no\\",\\"unlink_feat_img_portfolio\\":\\"no\\",\\"auto_fullwidth_portfolio\\":false,\\"hide_feat_img_portfolio\\":\\"no\\",\\"orderby_portfolio\\":\\"date\\",\\"order_portfolio\\":\\"desc\\",\\"disable_masonry\\":\\"no\\",\\"post_filter\\":\\"no\\",\\"layout_portfolio\\":\\"grid3\\",\\"category_portfolio\\":\\"0|single\\",\\"term_type\\":\\"category\\",\\"border_top_width\\":\\"1\\",\\"border_top_color\\":\\"#f3f3f3\\",\\"border-type\\":\\"all\\",\\"text_align\\":\\"left\\",\\"m_f_i_left\\":\\"-25\\",\\"m_f_i_opp_left\\":\\"1\\",\\"m_f_i_right\\":\\"-25\\",\\"m_f_i_opp_top\\":false,\\"padding_left\\":\\"25\\",\\"padding_opp_left\\":\\"1\\",\\"padding_right\\":\\"25\\",\\"padding_opp_top\\":false,\\"font_color_title_hover\\":\\"#000000\\",\\"font_size_title_unit\\":\\"em\\",\\"font_size_title\\":\\"1.1\\",\\"font_color_title\\":\\"#00b964\\",\\"letter_spacing_title_unit\\":\\"px\\",\\"letter_spacing_title\\":\\"0\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 520,
  'post_date' => '2020-07-15 11:40:50',
  'post_date_gmt' => '2020-07-15 11:40:50',
  'post_content' => '<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Project',
  'post_excerpt' => '',
  'post_name' => 'project',
  'post_modified' => '2020-07-15 11:40:52',
  'post_modified_gmt' => '2020-07-15 11:40:52',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?page_id=520',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    'mobile_menu_styles' => 'default',
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 33,
  'post_date' => '2020-03-12 16:16:43',
  'post_date_gmt' => '2020-03-12 16:16:43',
  'post_content' => '<!--themify_builder_static--><img src="https://themify.me/demo/themes/ultra-foundation/files/2020/03/donate-cure.png" title="Donate" alt="to find a cure" /> <h3> Donate </h3> to find a cure<!--/themify_builder_static-->',
  'post_title' => 'Rounded Box Icon',
  'post_excerpt' => '',
  'post_name' => 'tb_gs335e6',
  'post_modified' => '2020-03-12 16:30:07',
  'post_modified_gmt' => '2020-03-12 16:30:07',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/tglobal-style/rounded-box-icon/',
  'menu_order' => 0,
  'post_type' => 'tglobal_style',
  'meta_input' => 
  array (
    'themify_global_style_type' => 'image',
    'hide_page_title' => 'yes',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_wp_old_slug' => 'rounded-box-icon',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"row5e6a606b8224a\\",\\"cols\\":[{\\"element_id\\":\\"col5e6a606b8224a\\",\\"modules\\":[{\\"element_id\\":\\"mod5e6a606b8224a\\",\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"caption_image\\":\\"to find a cure\\",\\"image_zoom_icon\\":\\"false\\",\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Donate\\",\\"auto_fullwidth\\":\\"false\\",\\"appearance_image\\":\\"false\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-foundation\\\\/files\\\\/2020\\\\/03\\\\/donate-cure.png\\",\\"caption_on_overlay\\":\\"false\\",\\"style_image\\":\\"image-left\\",\\"title_margin_opp_left\\":\\"false\\",\\"title_margin_opp_top\\":\\"false\\",\\"title_margin_top\\":\\"20\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":\\"false\\",\\"b_ra_opp_bottom\\":\\"false\\",\\"b_ra_top\\":\\"8\\",\\"border_top_width\\":\\"1\\",\\"border_top_color\\":\\"#dddddd\\",\\"border-type\\":\\"all\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_left\\":\\"8\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"4\\",\\"padding_right\\":\\"8\\",\\"padding_opp_top\\":\\"false\\",\\"padding_top\\":\\"7\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_color\\":\\"#ffffff\\",\\"background_image-circle-radial\\":\\"false\\",\\"background_image-type\\":\\"image\\",\\"checkbox_padding_apply_all\\":\\"false\\"}}]}]}]',
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 343,
  'post_date' => '2020-07-10 04:34:13',
  'post_date_gmt' => '2020-07-10 04:34:13',
  'post_content' => '',
  'post_title' => 'END POVERTY IN THE MIDST OF A PANDEMIC',
  'post_excerpt' => '',
  'post_name' => 'donation',
  'post_modified' => '2020-08-23 16:17:02',
  'post_modified_gmt' => '2020-08-23 16:17:02',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?post_type=give_forms&#038;p=343',
  'menu_order' => 0,
  'post_type' => 'give_forms',
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 286,
  'post_date' => '2020-05-30 10:56:01',
  'post_date_gmt' => '2020-05-30 10:56:01',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Vitae dicta sunt',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'vitae-dicta-sunt',
  'post_modified' => '2020-05-30 10:56:01',
  'post_modified_gmt' => '2020-05-30 10:56:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?post_type=portfolio&#038;p=286',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'May 30, 2020',
    'project_client' => 'Themify',
    'project_services' => 'Services',
    'project_launch' => 'https://themify.me/',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"4nyy26\\",\\"cols\\":[{\\"element_id\\":\\"u3wa27\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'services, uncategorized',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/volunteer-time.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 285,
  'post_date' => '2020-05-30 10:54:44',
  'post_date_gmt' => '2020-05-30 10:54:44',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Quasi architecto beatae',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'quasi-architecto-beatae',
  'post_modified' => '2020-05-30 10:55:06',
  'post_modified_gmt' => '2020-05-30 10:55:06',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?post_type=portfolio&#038;p=285',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'May 30, 2020',
    'project_client' => 'Themify',
    'project_services' => 'Services',
    'project_launch' => 'https://themify.me/',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"gynj882\\",\\"cols\\":[{\\"element_id\\":\\"6bok883\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'services',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/volunteer-time.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 284,
  'post_date' => '2020-05-30 10:24:28',
  'post_date_gmt' => '2020-05-30 10:24:28',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Consequuntur magni dolores',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'consequuntur-magni-dolores',
  'post_modified' => '2020-05-30 10:24:28',
  'post_modified_gmt' => '2020-05-30 10:24:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?post_type=portfolio&#038;p=284',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'May 30, 2020',
    'project_client' => 'Themify',
    'project_services' => 'Services',
    'project_launch' => 'https://themify.me/',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"53ar530\\",\\"cols\\":[{\\"element_id\\":\\"uqqu531\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'services',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/volunteer-time.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 283,
  'post_date' => '2020-05-30 10:23:15',
  'post_date_gmt' => '2020-05-30 10:23:15',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Aut odit aut fugit',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'aut-odit-aut-fugit',
  'post_modified' => '2020-05-30 10:23:15',
  'post_modified_gmt' => '2020-05-30 10:23:15',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?post_type=portfolio&#038;p=283',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'May 30, 2020',
    'project_client' => 'Themify',
    'project_services' => 'Services',
    'project_launch' => 'https://themify.me/',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"1yq5580\\",\\"cols\\":[{\\"element_id\\":\\"iwkn581\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'services, uncategorized',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/volunteer-time.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 282,
  'post_date' => '2020-05-30 10:22:06',
  'post_date_gmt' => '2020-05-30 10:22:06',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Dicta sunt explicabo',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'dicta-sunt-explicabo',
  'post_modified' => '2020-05-30 10:22:06',
  'post_modified_gmt' => '2020-05-30 10:22:06',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?post_type=portfolio&#038;p=282',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'May 30, 2020',
    'project_client' => 'Themify',
    'project_services' => 'Services',
    'project_launch' => 'https://themify.me/',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"czne294\\",\\"cols\\":[{\\"element_id\\":\\"p13t295\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'services, uncategorized',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/volunteer-time.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 272,
  'post_date' => '2020-05-30 10:12:25',
  'post_date_gmt' => '2020-05-30 10:12:25',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

&nbsp;

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

&nbsp;

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Neque porro quisquam',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'neque-porro-quisquam',
  'post_modified' => '2020-05-30 10:12:25',
  'post_modified_gmt' => '2020-05-30 10:12:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?post_type=portfolio&#038;p=272',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'May 30, 2020',
    'project_client' => 'Themify',
    'project_services' => 'Services',
    'project_launch' => 'https://themify.me/',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"toik896\\",\\"cols\\":[{\\"element_id\\":\\"ekqe897\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'services',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/volunteer-time.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 270,
  'post_date' => '2020-05-30 10:11:27',
  'post_date_gmt' => '2020-05-30 10:11:27',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Unde omnis iste',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'unde-omnis-iste',
  'post_modified' => '2020-05-30 10:11:27',
  'post_modified_gmt' => '2020-05-30 10:11:27',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?post_type=portfolio&#038;p=270',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'May 30, 2020',
    'project_client' => 'Themify',
    'project_services' => 'Services',
    'project_launch' => 'https://themify.me/',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"nzuf593\\",\\"cols\\":[{\\"element_id\\":\\"scsc594\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'services',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/volunteer-time.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 268,
  'post_date' => '2020-05-30 10:08:59',
  'post_date_gmt' => '2020-05-30 10:08:59',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Voluptate velit esse',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'voluptate-velit-esse',
  'post_modified' => '2020-05-30 10:09:57',
  'post_modified_gmt' => '2020-05-30 10:09:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?post_type=portfolio&#038;p=268',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'May 30, 2020',
    'project_client' => 'Themify',
    'project_services' => 'Services',
    'project_launch' => 'https://themify.me/',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"kimm335\\",\\"cols\\":[{\\"element_id\\":\\"r3ce337\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'services',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/volunteer-time.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 267,
  'post_date' => '2020-05-30 10:07:41',
  'post_date_gmt' => '2020-05-30 10:07:41',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Aliquip ex ea commodo',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'aliquip-ex-ea-commodo',
  'post_modified' => '2020-05-30 10:10:31',
  'post_modified_gmt' => '2020-05-30 10:10:31',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?post_type=portfolio&#038;p=267',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'May 30, 2020',
    'project_client' => 'Themify',
    'project_services' => 'Services',
    'project_launch' => 'https://themify.me/',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"vrmh2\\",\\"cols\\":[{\\"element_id\\":\\"snj95\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'services',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/volunteer-time.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 265,
  'post_date' => '2020-05-30 05:03:32',
  'post_date_gmt' => '2020-05-30 05:03:32',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Duis aute irure',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'duis-aute-irure',
  'post_modified' => '2020-05-30 05:03:55',
  'post_modified_gmt' => '2020-05-30 05:03:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?post_type=portfolio&#038;p=265',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'May 30, 2020',
    'project_client' => 'Themify',
    'project_services' => 'Services',
    'project_launch' => 'https://themify.me/',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"15t1908\\",\\"cols\\":[{\\"element_id\\":\\"efkd909\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'services',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/volunteer-time.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 264,
  'post_date' => '2020-05-30 05:00:47',
  'post_date_gmt' => '2020-05-30 05:00:47',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam.',
  'post_title' => 'Sed ut perspiciatis',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  'post_name' => 'sed-ut-perspiciatis',
  'post_modified' => '2020-05-30 05:00:47',
  'post_modified_gmt' => '2020-05-30 05:00:47',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?post_type=portfolio&#038;p=264',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'May 30, 2020',
    'project_client' => 'Laboris',
    'project_services' => 'Services',
    'project_launch' => 'https://themify.me/',
    'mobile_menu_styles' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"mr6r518\\",\\"cols\\":[{\\"element_id\\":\\"e721520\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'services',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-foundation/files/2020/05/volunteer-time.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 75,
  'post_date' => '2020-03-16 08:11:56',
  'post_date_gmt' => '2020-03-16 08:11:56',
  'post_content' => '',
  'post_title' => 'Career',
  'post_excerpt' => '',
  'post_name' => 'career',
  'post_modified' => '2020-03-16 08:11:56',
  'post_modified_gmt' => '2020-03-16 08:11:56',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=75',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '75',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => 'https://themify.me/',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'footer-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 76,
  'post_date' => '2020-03-16 08:11:56',
  'post_date_gmt' => '2020-03-16 08:11:56',
  'post_content' => '',
  'post_title' => 'Term and Condition',
  'post_excerpt' => '',
  'post_name' => 'term-and-condition',
  'post_modified' => '2020-03-16 08:11:56',
  'post_modified_gmt' => '2020-03-16 08:11:56',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=76',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '76',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => 'https://themify.me/',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'footer-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 77,
  'post_date' => '2020-03-16 08:11:56',
  'post_date_gmt' => '2020-03-16 08:11:56',
  'post_content' => '',
  'post_title' => 'Privacy',
  'post_excerpt' => '',
  'post_name' => 'privacy',
  'post_modified' => '2020-03-16 08:11:56',
  'post_modified_gmt' => '2020-03-16 08:11:56',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=77',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '77',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => 'https://themify.me/',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'footer-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 74,
  'post_date' => '2020-03-16 08:10:53',
  'post_date_gmt' => '2020-03-16 08:10:53',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '74',
  'post_modified' => '2020-08-25 04:57:14',
  'post_modified_gmt' => '2020-08-25 04:57:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=74',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '8',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 176,
  'post_date' => '2020-05-29 12:59:07',
  'post_date_gmt' => '2020-05-29 12:59:07',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '176',
  'post_modified' => '2020-08-25 04:57:14',
  'post_modified_gmt' => '2020-08-25 04:57:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=176',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '84',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 224,
  'post_date' => '2020-05-29 14:00:23',
  'post_date_gmt' => '2020-05-29 14:00:23',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '224',
  'post_modified' => '2020-08-25 04:57:14',
  'post_modified_gmt' => '2020-08-25 04:57:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=224',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '182',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 223,
  'post_date' => '2020-05-29 14:00:24',
  'post_date_gmt' => '2020-05-29 14:00:24',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '223',
  'post_modified' => '2020-08-25 04:57:14',
  'post_modified_gmt' => '2020-08-25 04:57:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=223',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '192',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 306,
  'post_date' => '2020-05-30 12:46:27',
  'post_date_gmt' => '2020-05-30 12:46:27',
  'post_content' => '',
  'post_title' => 'Donate',
  'post_excerpt' => '',
  'post_name' => 'donate',
  'post_modified' => '2020-08-25 04:57:14',
  'post_modified_gmt' => '2020-08-25 04:57:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-foundation/?p=306',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '306',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => '#donate',
    '_themify_highlight_link' => '1',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_search" );
$widgets[1002] = array (
  'title' => 'Search',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_themify-feature-posts" );
$widgets[1003] = array (
  'title' => 'Latest Posts',
  'category' => '0',
  'show_count' => '3',
  'show_date' => 'on',
  'show_thumb' => 'on',
  'display' => 'none',
  'thumb_width' => '86',
  'thumb_height' => '86',
  'excerpt_length' => '0',
  'read_more_text' => 'Read more',
  'orderby' => 'date',
  'order' => 'DESC',
);
update_option( "widget_themify-feature-posts", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1004] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1005] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1006] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1007] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_nav_menu" );
$widgets[1008] = array (
  'title' => 'Navigation',
  'nav_menu' => Themify_Import_Helper::get_term_id_by_slug( "main-navigation", "nav_menu" ),
);
update_option( "widget_nav_menu", $widgets );

$widgets = get_option( "widget_nav_menu" );
$widgets[1009] = array (
  'title' => 'Info',
  'nav_menu' => Themify_Import_Helper::get_term_id_by_slug( "footer-menu", "nav_menu" ),
);
update_option( "widget_nav_menu", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1010] = array (
  'title' => 'Head Office',
  'text' => '2091 Mission St, San Francisco, CA 94110

(23) 123-4556

<a href="mailto:sample@example.com">hello@foundation.com</a>',
  'filter' => true,
  'visual' => true,
);
update_option( "widget_text", $widgets );



$sidebars_widgets = array (
  'sidebar-main' => 
  array (
    0 => 'search-1002',
    1 => 'themify-feature-posts-1003',
  ),
  'sidebar-alt' => 
  array (
    0 => 'archives-1004',
    1 => 'categories-1005',
    2 => 'meta-1006',
  ),
  'footer-social-widget' => 
  array (
    0 => 'themify-social-links-1007',
  ),
  'footer-widget-1' => 
  array (
    0 => 'nav_menu-1008',
  ),
  'footer-widget-2' => 
  array (
    0 => 'nav_menu-1009',
  ),
  'footer-widget-3' => 
  array (
    0 => 'text-1010',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-webfonts_list' => 'recommended',
  'setting-customizer_responsive_design_tablet_landscape' => '1280',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '480',
  'setting-mobile_menu_trigger_point' => '900',
  'setting-header_design' => 'header-horizontal',
  'setting-exclude_site_tagline' => 'on',
  'setting-exclude_search_form' => 'on',
  'setting_search_form' => 'live_search',
  'setting-header_widgets' => 'headerwidget-3col',
  'setting-footer_design' => 'footer-left-col',
  'setting-use_float_back' => 'on',
  'setting-footer_widgets' => 'footerwidget-3col',
  'setting-footer_widget_position' => 'top',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'on',
  'setting-color_animation_speed' => '5',
  'setting-relationship_taxonomy' => 'category',
  'setting-relationship_taxonomy_entries' => '3',
  'setting-relationship_taxonomy_display_content' => 'none',
  'setting-single_slider_autoplay' => 'off',
  'setting-single_slider_speed' => 'normal',
  'setting-single_slider_effect' => 'slide',
  'setting-single_slider_height' => 'auto',
  'setting-more_posts' => 'infinite',
  'setting-entries_nav' => 'numbered',
  'setting-footer_text_left' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard ',
  'setting-footer_text_left_hide' => 'hide',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-lazy-blur' => '25',
  'setting-cache-live' => '10080',
  'setting-webp-quality' => '5',
  'setting-default_layout' => 'sidebar1',
  'setting-default_post_layout' => 'list-post',
  'setting-post_filter' => 'no',
  'setting-disable_masonry' => 'yes',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar1',
  'setting-default_page_post_layout_type' => 'classic',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-search-result_layout_display' => 'content',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar1',
  'setting-custom_post_give_forms_archive' => 'sidebar1',
  'setting-custom_post_give_forms_archive_content_width' => 'default_width',
  'setting-custom_post_give_forms_single' => 'sidebar1',
  'setting-custom_post_give_forms_single_content_width' => 'default_width',
  'setting-default_portfolio_index_layout' => 'sidebar-none',
  'setting-default_portfolio_index_post_layout' => 'grid3',
  'setting-portfolio_post_filter' => 'yes',
  'setting-portfolio_disable_masonry' => 'yes',
  'setting-portfolio_gutter' => 'gutter',
  'setting-default_portfolio_index_display' => 'none',
  'setting-default_portfolio_index_post_meta_category' => 'yes',
  'setting-default_portfolio_index_unlink_post_image' => 'yes',
  'setting-default_portfolio_single_layout' => 'sidebar-none',
  'setting-default_portfolio_single_portfolio_layout_type' => 'fullwidth',
  'setting-default_portfolio_single_unlink_post_image' => 'yes',
  'themify_portfolio_slug' => 'project',
  'themify_portfolio_category_slug' => 'portfolio-category',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/foundation/wp-content/themes/themify-ultra/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/foundation/wp-content/themes/themify-ultra/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'YouTube',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/foundation/wp-content/themes/themify-ultra/themify/img/social/youtube.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'Pinterest',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/foundation/wp-content/themes/themify-ultra/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Facebook',
  'setting-link_link_themify-link-5' => 'https://www.facebook.com/themify',
  'setting-link_ficon_themify-link-5' => 'ti-facebook',
  'setting-link_ficolor_themify-link-5' => 'rgba(235, 235, 236, 1)',
  'setting-link_type_themify-link-4' => 'font-icon',
  'setting-link_title_themify-link-4' => 'Twitter',
  'setting-link_link_themify-link-4' => 'https://www.twitter.com/themify',
  'setting-link_ficon_themify-link-4' => 'fa-twitter',
  'setting-link_ficolor_themify-link-4' => 'rgba(235, 235, 236, 1)',
  'setting-link_type_themify-link-7' => 'font-icon',
  'setting-link_title_themify-link-7' => 'Instagram',
  'setting-link_link_themify-link-7' => 'https://www.instagram.com/themify/',
  'setting-link_ficon_themify-link-7' => 'ti-instagram',
  'setting-link_ficolor_themify-link-7' => 'rgba(235, 235, 236, 1)',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'YouTube',
  'setting-link_link_themify-link-6' => 'https://www.youtube.com/user/themifyme',
  'setting-link_ficon_themify-link-6' => 'ti-youtube',
  'setting-link_ficolor_themify-link-6' => 'rgba(235, 235, 236, 1)',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-5":"themify-link-5","themify-link-4":"themify-link-4","themify-link-7":"themify-link-7","themify-link-6":"themify-link-6"}',
  'setting-link_field_hash' => '8',
  'setting-twitter_settings_cache' => '10',
  'setting-recaptcha_version' => 'v2',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_gallery_lightbox' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'skin' => 'foundation',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'custom_css_post_id' => -1,
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
